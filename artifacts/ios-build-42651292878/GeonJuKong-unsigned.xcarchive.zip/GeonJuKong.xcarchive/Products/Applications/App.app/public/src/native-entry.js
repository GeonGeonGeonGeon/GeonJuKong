var __defProp = Object.defineProperty;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// node_modules/@capacitor/core/dist/index.js
var ExceptionCode, CapacitorException, getPlatformId, createCapacitor, initCapacitorGlobal, Capacitor, registerPlugin, WebPlugin, encode, decode, CapacitorCookiesPluginWeb, CapacitorCookies, readBlobAsBase64, normalizeHttpHeaders, buildUrlParams, buildRequestInit, CapacitorHttpPluginWeb, CapacitorHttp;
var init_dist = __esm({
  "node_modules/@capacitor/core/dist/index.js"() {
    (function(ExceptionCode2) {
      ExceptionCode2["Unimplemented"] = "UNIMPLEMENTED";
      ExceptionCode2["Unavailable"] = "UNAVAILABLE";
    })(ExceptionCode || (ExceptionCode = {}));
    CapacitorException = class extends Error {
      constructor(message, code, data) {
        super(message);
        this.message = message;
        this.code = code;
        this.data = data;
      }
    };
    getPlatformId = (win) => {
      var _a, _b;
      if (win === null || win === void 0 ? void 0 : win.androidBridge) {
        return "android";
      } else if ((_b = (_a = win === null || win === void 0 ? void 0 : win.webkit) === null || _a === void 0 ? void 0 : _a.messageHandlers) === null || _b === void 0 ? void 0 : _b.bridge) {
        return "ios";
      } else {
        return "web";
      }
    };
    createCapacitor = (win) => {
      const capCustomPlatform = win.CapacitorCustomPlatform || null;
      const cap = win.Capacitor || {};
      const Plugins = cap.Plugins = cap.Plugins || {};
      const getPlatform = () => {
        return capCustomPlatform !== null ? capCustomPlatform.name : getPlatformId(win);
      };
      const isNativePlatform = () => getPlatform() !== "web";
      const isPluginAvailable = (pluginName) => {
        const plugin = registeredPlugins.get(pluginName);
        if (plugin === null || plugin === void 0 ? void 0 : plugin.platforms.has(getPlatform())) {
          return true;
        }
        if (getPluginHeader(pluginName)) {
          return true;
        }
        return false;
      };
      const getPluginHeader = (pluginName) => {
        var _a;
        return (_a = cap.PluginHeaders) === null || _a === void 0 ? void 0 : _a.find((h) => h.name === pluginName);
      };
      const handleError = (err) => win.console.error(err);
      const registeredPlugins = /* @__PURE__ */ new Map();
      const registerPlugin2 = (pluginName, jsImplementations = {}) => {
        const registeredPlugin = registeredPlugins.get(pluginName);
        if (registeredPlugin) {
          console.warn(`Capacitor plugin "${pluginName}" already registered. Cannot register plugins twice.`);
          return registeredPlugin.proxy;
        }
        const platform = getPlatform();
        const pluginHeader = getPluginHeader(pluginName);
        let jsImplementation;
        const loadPluginImplementation = async () => {
          if (!jsImplementation && platform in jsImplementations) {
            jsImplementation = typeof jsImplementations[platform] === "function" ? jsImplementation = await jsImplementations[platform]() : jsImplementation = jsImplementations[platform];
          } else if (capCustomPlatform !== null && !jsImplementation && "web" in jsImplementations) {
            jsImplementation = typeof jsImplementations["web"] === "function" ? jsImplementation = await jsImplementations["web"]() : jsImplementation = jsImplementations["web"];
          }
          return jsImplementation;
        };
        const createPluginMethod = (impl, prop) => {
          var _a, _b;
          if (pluginHeader) {
            const methodHeader = pluginHeader === null || pluginHeader === void 0 ? void 0 : pluginHeader.methods.find((m) => prop === m.name);
            if (methodHeader) {
              if (methodHeader.rtype === "promise") {
                return (options) => cap.nativePromise(pluginName, prop.toString(), options);
              } else {
                return (options, callback) => cap.nativeCallback(pluginName, prop.toString(), options, callback);
              }
            } else if (impl) {
              return (_a = impl[prop]) === null || _a === void 0 ? void 0 : _a.bind(impl);
            }
          } else if (impl) {
            return (_b = impl[prop]) === null || _b === void 0 ? void 0 : _b.bind(impl);
          } else {
            throw new CapacitorException(`"${pluginName}" plugin is not implemented on ${platform}`, ExceptionCode.Unimplemented);
          }
        };
        const createPluginMethodWrapper = (prop) => {
          let remove;
          const wrapper = (...args) => {
            const p = loadPluginImplementation().then((impl) => {
              const fn = createPluginMethod(impl, prop);
              if (fn) {
                const p2 = fn(...args);
                remove = p2 === null || p2 === void 0 ? void 0 : p2.remove;
                return p2;
              } else {
                throw new CapacitorException(`"${pluginName}.${prop}()" is not implemented on ${platform}`, ExceptionCode.Unimplemented);
              }
            });
            if (prop === "addListener") {
              p.remove = async () => remove();
            }
            return p;
          };
          wrapper.toString = () => `${prop.toString()}() { [capacitor code] }`;
          Object.defineProperty(wrapper, "name", {
            value: prop,
            writable: false,
            configurable: false
          });
          return wrapper;
        };
        const addListener = createPluginMethodWrapper("addListener");
        const removeListener = createPluginMethodWrapper("removeListener");
        const addListenerNative = (eventName, callback) => {
          const call = addListener({ eventName }, callback);
          const remove = async () => {
            const callbackId = await call;
            removeListener({
              eventName,
              callbackId
            }, callback);
          };
          const p = new Promise((resolve2) => call.then(() => resolve2({ remove })));
          p.remove = async () => {
            console.warn(`Using addListener() without 'await' is deprecated.`);
            await remove();
          };
          return p;
        };
        const proxy = new Proxy({}, {
          get(_, prop) {
            switch (prop) {
              // https://github.com/facebook/react/issues/20030
              case "$$typeof":
                return void 0;
              case "toJSON":
                return () => ({});
              case "addListener":
                return pluginHeader ? addListenerNative : addListener;
              case "removeListener":
                return removeListener;
              default:
                return createPluginMethodWrapper(prop);
            }
          }
        });
        Plugins[pluginName] = proxy;
        registeredPlugins.set(pluginName, {
          name: pluginName,
          proxy,
          platforms: /* @__PURE__ */ new Set([...Object.keys(jsImplementations), ...pluginHeader ? [platform] : []])
        });
        return proxy;
      };
      if (!cap.convertFileSrc) {
        cap.convertFileSrc = (filePath) => filePath;
      }
      cap.getPlatform = getPlatform;
      cap.handleError = handleError;
      cap.isNativePlatform = isNativePlatform;
      cap.isPluginAvailable = isPluginAvailable;
      cap.registerPlugin = registerPlugin2;
      cap.Exception = CapacitorException;
      cap.DEBUG = !!cap.DEBUG;
      cap.isLoggingEnabled = !!cap.isLoggingEnabled;
      return cap;
    };
    initCapacitorGlobal = (win) => win.Capacitor = createCapacitor(win);
    Capacitor = /* @__PURE__ */ initCapacitorGlobal(typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : typeof global !== "undefined" ? global : {});
    registerPlugin = Capacitor.registerPlugin;
    WebPlugin = class {
      constructor() {
        this.listeners = {};
        this.retainedEventArguments = {};
        this.windowListeners = {};
      }
      addListener(eventName, listenerFunc) {
        let firstListener = false;
        const listeners = this.listeners[eventName];
        if (!listeners) {
          this.listeners[eventName] = [];
          firstListener = true;
        }
        this.listeners[eventName].push(listenerFunc);
        const windowListener = this.windowListeners[eventName];
        if (windowListener && !windowListener.registered) {
          this.addWindowListener(windowListener);
        }
        if (firstListener) {
          this.sendRetainedArgumentsForEvent(eventName);
        }
        const remove = async () => this.removeListener(eventName, listenerFunc);
        const p = Promise.resolve({ remove });
        return p;
      }
      async removeAllListeners() {
        this.listeners = {};
        for (const listener in this.windowListeners) {
          this.removeWindowListener(this.windowListeners[listener]);
        }
        this.windowListeners = {};
      }
      notifyListeners(eventName, data, retainUntilConsumed) {
        const listeners = this.listeners[eventName];
        if (!listeners) {
          if (retainUntilConsumed) {
            let args = this.retainedEventArguments[eventName];
            if (!args) {
              args = [];
            }
            args.push(data);
            this.retainedEventArguments[eventName] = args;
          }
          return;
        }
        listeners.forEach((listener) => listener(data));
      }
      hasListeners(eventName) {
        var _a;
        return !!((_a = this.listeners[eventName]) === null || _a === void 0 ? void 0 : _a.length);
      }
      registerWindowListener(windowEventName, pluginEventName) {
        this.windowListeners[pluginEventName] = {
          registered: false,
          windowEventName,
          pluginEventName,
          handler: (event) => {
            this.notifyListeners(pluginEventName, event);
          }
        };
      }
      unimplemented(msg = "not implemented") {
        return new Capacitor.Exception(msg, ExceptionCode.Unimplemented);
      }
      unavailable(msg = "not available") {
        return new Capacitor.Exception(msg, ExceptionCode.Unavailable);
      }
      async removeListener(eventName, listenerFunc) {
        const listeners = this.listeners[eventName];
        if (!listeners) {
          return;
        }
        const index = listeners.indexOf(listenerFunc);
        this.listeners[eventName].splice(index, 1);
        if (!this.listeners[eventName].length) {
          this.removeWindowListener(this.windowListeners[eventName]);
        }
      }
      addWindowListener(handle) {
        window.addEventListener(handle.windowEventName, handle.handler);
        handle.registered = true;
      }
      removeWindowListener(handle) {
        if (!handle) {
          return;
        }
        window.removeEventListener(handle.windowEventName, handle.handler);
        handle.registered = false;
      }
      sendRetainedArgumentsForEvent(eventName) {
        const args = this.retainedEventArguments[eventName];
        if (!args) {
          return;
        }
        delete this.retainedEventArguments[eventName];
        args.forEach((arg) => {
          this.notifyListeners(eventName, arg);
        });
      }
    };
    encode = (str) => encodeURIComponent(str).replace(/%(2[346B]|5E|60|7C)/g, decodeURIComponent).replace(/[()]/g, escape);
    decode = (str) => str.replace(/(%[\dA-F]{2})+/gi, decodeURIComponent);
    CapacitorCookiesPluginWeb = class extends WebPlugin {
      async getCookies() {
        const cookies = document.cookie;
        const cookieMap = {};
        cookies.split(";").forEach((cookie) => {
          if (cookie.length <= 0)
            return;
          let [key, value] = cookie.replace(/=/, "CAP_COOKIE").split("CAP_COOKIE");
          key = decode(key).trim();
          value = decode(value).trim();
          cookieMap[key] = value;
        });
        return cookieMap;
      }
      async setCookie(options) {
        try {
          const encodedKey = encode(options.key);
          const encodedValue = encode(options.value);
          const expires2 = options.expires ? `; expires=${options.expires.replace("expires=", "")}` : "";
          const path = (options.path || "/").replace("path=", "");
          const domain = options.url != null && options.url.length > 0 ? `domain=${options.url}` : "";
          document.cookie = `${encodedKey}=${encodedValue || ""}${expires2}; path=${path}; ${domain};`;
        } catch (error) {
          return Promise.reject(error);
        }
      }
      async deleteCookie(options) {
        try {
          document.cookie = `${options.key}=; Max-Age=0`;
        } catch (error) {
          return Promise.reject(error);
        }
      }
      async clearCookies() {
        try {
          const cookies = document.cookie.split(";") || [];
          for (const cookie of cookies) {
            document.cookie = cookie.replace(/^ +/, "").replace(/=.*/, `=;expires=${(/* @__PURE__ */ new Date()).toUTCString()};path=/`);
          }
        } catch (error) {
          return Promise.reject(error);
        }
      }
      async clearAllCookies() {
        try {
          await this.clearCookies();
        } catch (error) {
          return Promise.reject(error);
        }
      }
    };
    CapacitorCookies = registerPlugin("CapacitorCookies", {
      web: () => new CapacitorCookiesPluginWeb()
    });
    readBlobAsBase64 = async (blob) => new Promise((resolve2, reject) => {
      const reader = new FileReader();
      reader.onload = () => {
        const base64String = reader.result;
        resolve2(base64String.indexOf(",") >= 0 ? base64String.split(",")[1] : base64String);
      };
      reader.onerror = (error) => reject(error);
      reader.readAsDataURL(blob);
    });
    normalizeHttpHeaders = (headers = {}) => {
      const originalKeys = Object.keys(headers);
      const loweredKeys = Object.keys(headers).map((k) => k.toLocaleLowerCase());
      const normalized = loweredKeys.reduce((acc, key, index) => {
        acc[key] = headers[originalKeys[index]];
        return acc;
      }, {});
      return normalized;
    };
    buildUrlParams = (params, shouldEncode = true) => {
      if (!params)
        return null;
      const output = Object.entries(params).reduce((accumulator, entry) => {
        const [key, value] = entry;
        let encodedValue;
        let item;
        if (Array.isArray(value)) {
          item = "";
          value.forEach((str) => {
            encodedValue = shouldEncode ? encodeURIComponent(str) : str;
            item += `${key}=${encodedValue}&`;
          });
          item.slice(0, -1);
        } else {
          encodedValue = shouldEncode ? encodeURIComponent(value) : value;
          item = `${key}=${encodedValue}`;
        }
        return `${accumulator}&${item}`;
      }, "");
      return output.substr(1);
    };
    buildRequestInit = (options, extra = {}) => {
      const output = Object.assign({ method: options.method || "GET", headers: options.headers }, extra);
      const headers = normalizeHttpHeaders(options.headers);
      const type = headers["content-type"] || "";
      if (typeof options.data === "string") {
        output.body = options.data;
      } else if (type.includes("application/x-www-form-urlencoded")) {
        const params = new URLSearchParams();
        for (const [key, value] of Object.entries(options.data || {})) {
          params.set(key, value);
        }
        output.body = params.toString();
      } else if (type.includes("multipart/form-data") || options.data instanceof FormData) {
        const form = new FormData();
        if (options.data instanceof FormData) {
          options.data.forEach((value, key) => {
            form.append(key, value);
          });
        } else {
          for (const key of Object.keys(options.data)) {
            form.append(key, options.data[key]);
          }
        }
        output.body = form;
        const headers2 = new Headers(output.headers);
        headers2.delete("content-type");
        output.headers = headers2;
      } else if (type.includes("application/json") || typeof options.data === "object") {
        output.body = JSON.stringify(options.data);
      }
      return output;
    };
    CapacitorHttpPluginWeb = class extends WebPlugin {
      /**
       * Perform an Http request given a set of options
       * @param options Options to build the HTTP request
       */
      async request(options) {
        const requestInit = buildRequestInit(options, options.webFetchExtra);
        const urlParams = buildUrlParams(options.params, options.shouldEncodeUrlParams);
        const url = urlParams ? `${options.url}?${urlParams}` : options.url;
        const response = await fetch(url, requestInit);
        const contentType = response.headers.get("content-type") || "";
        let { responseType = "text" } = response.ok ? options : {};
        if (contentType.includes("application/json")) {
          responseType = "json";
        }
        let data;
        let blob;
        switch (responseType) {
          case "arraybuffer":
          case "blob":
            blob = await response.blob();
            data = await readBlobAsBase64(blob);
            break;
          case "json":
            data = await response.json();
            break;
          case "document":
          case "text":
          default:
            data = await response.text();
        }
        const headers = {};
        response.headers.forEach((value, key) => {
          headers[key] = value;
        });
        return {
          data,
          headers,
          status: response.status,
          url: response.url
        };
      }
      /**
       * Perform an Http GET request given a set of options
       * @param options Options to build the HTTP request
       */
      async get(options) {
        return this.request(Object.assign(Object.assign({}, options), { method: "GET" }));
      }
      /**
       * Perform an Http POST request given a set of options
       * @param options Options to build the HTTP request
       */
      async post(options) {
        return this.request(Object.assign(Object.assign({}, options), { method: "POST" }));
      }
      /**
       * Perform an Http PUT request given a set of options
       * @param options Options to build the HTTP request
       */
      async put(options) {
        return this.request(Object.assign(Object.assign({}, options), { method: "PUT" }));
      }
      /**
       * Perform an Http PATCH request given a set of options
       * @param options Options to build the HTTP request
       */
      async patch(options) {
        return this.request(Object.assign(Object.assign({}, options), { method: "PATCH" }));
      }
      /**
       * Perform an Http DELETE request given a set of options
       * @param options Options to build the HTTP request
       */
      async delete(options) {
        return this.request(Object.assign(Object.assign({}, options), { method: "DELETE" }));
      }
    };
    CapacitorHttp = registerPlugin("CapacitorHttp", {
      web: () => new CapacitorHttpPluginWeb()
    });
  }
});

// node_modules/@capacitor/app/dist/esm/web.js
var web_exports = {};
__export(web_exports, {
  AppWeb: () => AppWeb
});
var AppWeb;
var init_web = __esm({
  "node_modules/@capacitor/app/dist/esm/web.js"() {
    init_dist();
    AppWeb = class extends WebPlugin {
      constructor() {
        super();
        this.handleVisibilityChange = () => {
          const data = {
            isActive: document.hidden !== true
          };
          this.notifyListeners("appStateChange", data);
          if (document.hidden) {
            this.notifyListeners("pause", null);
          } else {
            this.notifyListeners("resume", null);
          }
        };
        document.addEventListener("visibilitychange", this.handleVisibilityChange, false);
      }
      exitApp() {
        throw this.unimplemented("Not implemented on web.");
      }
      async getInfo() {
        throw this.unimplemented("Not implemented on web.");
      }
      async getLaunchUrl() {
        return { url: "" };
      }
      async getState() {
        return { isActive: document.hidden !== true };
      }
      async minimizeApp() {
        throw this.unimplemented("Not implemented on web.");
      }
      async toggleBackButtonHandler() {
        throw this.unimplemented("Not implemented on web.");
      }
    };
  }
});

// node_modules/@capacitor/browser/dist/esm/web.js
var web_exports2 = {};
__export(web_exports2, {
  Browser: () => Browser,
  BrowserWeb: () => BrowserWeb
});
var BrowserWeb, Browser;
var init_web2 = __esm({
  "node_modules/@capacitor/browser/dist/esm/web.js"() {
    init_dist();
    BrowserWeb = class extends WebPlugin {
      constructor() {
        super();
        this._lastWindow = null;
      }
      async open(options) {
        this._lastWindow = window.open(options.url, options.windowName || "_blank");
      }
      async close() {
        return new Promise((resolve2, reject) => {
          if (this._lastWindow != null) {
            this._lastWindow.close();
            this._lastWindow = null;
            resolve2();
          } else {
            reject("No active window to close!");
          }
        });
      }
    };
    Browser = new BrowserWeb();
  }
});

// node_modules/@capacitor/filesystem/dist/esm/definitions.js
var Directory, Encoding;
var init_definitions = __esm({
  "node_modules/@capacitor/filesystem/dist/esm/definitions.js"() {
    (function(Directory2) {
      Directory2["Documents"] = "DOCUMENTS";
      Directory2["Data"] = "DATA";
      Directory2["Library"] = "LIBRARY";
      Directory2["Cache"] = "CACHE";
      Directory2["External"] = "EXTERNAL";
      Directory2["ExternalStorage"] = "EXTERNAL_STORAGE";
      Directory2["ExternalCache"] = "EXTERNAL_CACHE";
      Directory2["LibraryNoCloud"] = "LIBRARY_NO_CLOUD";
      Directory2["Temporary"] = "TEMPORARY";
    })(Directory || (Directory = {}));
    (function(Encoding2) {
      Encoding2["UTF8"] = "utf8";
      Encoding2["ASCII"] = "ascii";
      Encoding2["UTF16"] = "utf16";
    })(Encoding || (Encoding = {}));
  }
});

// node_modules/@capacitor/filesystem/dist/esm/web.js
var web_exports3 = {};
__export(web_exports3, {
  FilesystemWeb: () => FilesystemWeb
});
function resolve(path) {
  const posix = path.split("/").filter((item) => item !== ".");
  const newPosix = [];
  posix.forEach((item) => {
    if (item === ".." && newPosix.length > 0 && newPosix[newPosix.length - 1] !== "..") {
      newPosix.pop();
    } else {
      newPosix.push(item);
    }
  });
  return newPosix.join("/");
}
function isPathParent(parent, children) {
  parent = resolve(parent);
  children = resolve(children);
  const pathsA = parent.split("/");
  const pathsB = children.split("/");
  return parent !== children && pathsA.every((value, index) => value === pathsB[index]);
}
var FilesystemWeb;
var init_web3 = __esm({
  "node_modules/@capacitor/filesystem/dist/esm/web.js"() {
    init_dist();
    init_definitions();
    FilesystemWeb = class _FilesystemWeb extends WebPlugin {
      constructor() {
        super(...arguments);
        this.DB_VERSION = 1;
        this.DB_NAME = "Disc";
        this._writeCmds = ["add", "put", "delete"];
        this.downloadFile = async (options) => {
          var _a, _b;
          const requestInit = buildRequestInit(options, options.webFetchExtra);
          const response = await fetch(options.url, requestInit);
          let blob;
          if (!options.progress)
            blob = await response.blob();
          else if (!(response === null || response === void 0 ? void 0 : response.body))
            blob = new Blob();
          else {
            const reader = response.body.getReader();
            let bytes = 0;
            const chunks = [];
            const contentType = response.headers.get("content-type");
            const contentLength = parseInt(response.headers.get("content-length") || "0", 10);
            while (true) {
              const { done, value } = await reader.read();
              if (done)
                break;
              chunks.push(value);
              bytes += (value === null || value === void 0 ? void 0 : value.length) || 0;
              const status = {
                url: options.url,
                bytes,
                contentLength
              };
              this.notifyListeners("progress", status);
            }
            const allChunks = new Uint8Array(bytes);
            let position = 0;
            for (const chunk of chunks) {
              if (typeof chunk === "undefined")
                continue;
              allChunks.set(chunk, position);
              position += chunk.length;
            }
            blob = new Blob([allChunks.buffer], { type: contentType || void 0 });
          }
          const result = await this.writeFile({
            path: options.path,
            directory: (_a = options.directory) !== null && _a !== void 0 ? _a : void 0,
            recursive: (_b = options.recursive) !== null && _b !== void 0 ? _b : false,
            data: blob
          });
          return { path: result.uri, blob };
        };
      }
      readFileInChunks(_options, _callback) {
        throw this.unavailable("Method not implemented.");
      }
      async initDb() {
        if (this._db !== void 0) {
          return this._db;
        }
        if (!("indexedDB" in window)) {
          throw this.unavailable("This browser doesn't support IndexedDB");
        }
        return new Promise((resolve2, reject) => {
          const request = indexedDB.open(this.DB_NAME, this.DB_VERSION);
          request.onupgradeneeded = _FilesystemWeb.doUpgrade;
          request.onsuccess = () => {
            this._db = request.result;
            resolve2(request.result);
          };
          request.onerror = () => reject(request.error);
          request.onblocked = () => {
            console.warn("db blocked");
          };
        });
      }
      static doUpgrade(event) {
        const eventTarget2 = event.target;
        const db2 = eventTarget2.result;
        switch (event.oldVersion) {
          case 0:
          case 1:
          default: {
            if (db2.objectStoreNames.contains("FileStorage")) {
              db2.deleteObjectStore("FileStorage");
            }
            const store = db2.createObjectStore("FileStorage", { keyPath: "path" });
            store.createIndex("by_folder", "folder");
          }
        }
      }
      async dbRequest(cmd, args) {
        const readFlag = this._writeCmds.indexOf(cmd) !== -1 ? "readwrite" : "readonly";
        return this.initDb().then((conn) => {
          return new Promise((resolve2, reject) => {
            const tx = conn.transaction(["FileStorage"], readFlag);
            const store = tx.objectStore("FileStorage");
            const req = store[cmd](...args);
            req.onsuccess = () => resolve2(req.result);
            req.onerror = () => reject(req.error);
          });
        });
      }
      async dbIndexRequest(indexName, cmd, args) {
        const readFlag = this._writeCmds.indexOf(cmd) !== -1 ? "readwrite" : "readonly";
        return this.initDb().then((conn) => {
          return new Promise((resolve2, reject) => {
            const tx = conn.transaction(["FileStorage"], readFlag);
            const store = tx.objectStore("FileStorage");
            const index = store.index(indexName);
            const req = index[cmd](...args);
            req.onsuccess = () => resolve2(req.result);
            req.onerror = () => reject(req.error);
          });
        });
      }
      getPath(directory, uriPath) {
        const cleanedUriPath = uriPath !== void 0 ? uriPath.replace(/^[/]+|[/]+$/g, "") : "";
        let fsPath = "";
        if (directory !== void 0)
          fsPath += "/" + directory;
        if (uriPath !== "")
          fsPath += "/" + cleanedUriPath;
        return fsPath;
      }
      async clear() {
        const conn = await this.initDb();
        const tx = conn.transaction(["FileStorage"], "readwrite");
        const store = tx.objectStore("FileStorage");
        store.clear();
      }
      /**
       * Read a file from disk
       * @param options options for the file read
       * @return a promise that resolves with the read file data result
       */
      async readFile(options) {
        const path = this.getPath(options.directory, options.path);
        const entry = await this.dbRequest("get", [path]);
        if (entry === void 0)
          throw Error("File does not exist.");
        return { data: entry.content ? entry.content : "" };
      }
      /**
       * Write a file to disk in the specified location on device
       * @param options options for the file write
       * @return a promise that resolves with the file write result
       */
      async writeFile(options) {
        const path = this.getPath(options.directory, options.path);
        let data = options.data;
        const encoding = options.encoding;
        const doRecursive = options.recursive;
        const occupiedEntry = await this.dbRequest("get", [path]);
        if (occupiedEntry && occupiedEntry.type === "directory")
          throw Error("The supplied path is a directory.");
        const parentPath = path.substr(0, path.lastIndexOf("/"));
        const parentEntry = await this.dbRequest("get", [parentPath]);
        if (parentEntry === void 0) {
          const subDirIndex = parentPath.indexOf("/", 1);
          if (subDirIndex !== -1) {
            const parentArgPath = parentPath.substr(subDirIndex);
            await this.mkdir({
              path: parentArgPath,
              directory: options.directory,
              recursive: doRecursive
            });
          }
        }
        if (!encoding && !(data instanceof Blob)) {
          data = data.indexOf(",") >= 0 ? data.split(",")[1] : data;
          if (!this.isBase64String(data))
            throw Error("The supplied data is not valid base64 content.");
        }
        const now2 = Date.now();
        const pathObj = {
          path,
          folder: parentPath,
          type: "file",
          size: data instanceof Blob ? data.size : data.length,
          ctime: now2,
          mtime: now2,
          content: data
        };
        await this.dbRequest("put", [pathObj]);
        return {
          uri: pathObj.path
        };
      }
      /**
       * Append to a file on disk in the specified location on device
       * @param options options for the file append
       * @return a promise that resolves with the file write result
       */
      async appendFile(options) {
        const path = this.getPath(options.directory, options.path);
        let data = options.data;
        const encoding = options.encoding;
        const parentPath = path.substr(0, path.lastIndexOf("/"));
        const now2 = Date.now();
        let ctime = now2;
        const occupiedEntry = await this.dbRequest("get", [path]);
        if (occupiedEntry && occupiedEntry.type === "directory")
          throw Error("The supplied path is a directory.");
        const parentEntry = await this.dbRequest("get", [parentPath]);
        if (parentEntry === void 0) {
          const subDirIndex = parentPath.indexOf("/", 1);
          if (subDirIndex !== -1) {
            const parentArgPath = parentPath.substr(subDirIndex);
            await this.mkdir({
              path: parentArgPath,
              directory: options.directory,
              recursive: true
            });
          }
        }
        if (!encoding && !this.isBase64String(data))
          throw Error("The supplied data is not valid base64 content.");
        if (occupiedEntry !== void 0) {
          if (occupiedEntry.content instanceof Blob) {
            throw Error("The occupied entry contains a Blob object which cannot be appended to.");
          }
          if (occupiedEntry.content !== void 0 && !encoding) {
            data = btoa(atob(occupiedEntry.content) + atob(data));
          } else {
            data = occupiedEntry.content + data;
          }
          ctime = occupiedEntry.ctime;
        }
        const pathObj = {
          path,
          folder: parentPath,
          type: "file",
          size: data.length,
          ctime,
          mtime: now2,
          content: data
        };
        await this.dbRequest("put", [pathObj]);
      }
      /**
       * Delete a file from disk
       * @param options options for the file delete
       * @return a promise that resolves with the deleted file data result
       */
      async deleteFile(options) {
        const path = this.getPath(options.directory, options.path);
        const entry = await this.dbRequest("get", [path]);
        if (entry === void 0)
          throw Error("File does not exist.");
        const entries = await this.dbIndexRequest("by_folder", "getAllKeys", [IDBKeyRange.only(path)]);
        if (entries.length !== 0)
          throw Error("Folder is not empty.");
        await this.dbRequest("delete", [path]);
      }
      /**
       * Create a directory.
       * @param options options for the mkdir
       * @return a promise that resolves with the mkdir result
       */
      async mkdir(options) {
        const path = this.getPath(options.directory, options.path);
        const doRecursive = options.recursive;
        const parentPath = path.substr(0, path.lastIndexOf("/"));
        const depth = (path.match(/\//g) || []).length;
        const parentEntry = await this.dbRequest("get", [parentPath]);
        const occupiedEntry = await this.dbRequest("get", [path]);
        if (depth === 1)
          throw Error("Cannot create Root directory");
        if (occupiedEntry !== void 0)
          throw Error("Current directory does already exist.");
        if (!doRecursive && depth !== 2 && parentEntry === void 0)
          throw Error("Parent directory must exist");
        if (doRecursive && depth !== 2 && parentEntry === void 0) {
          const parentArgPath = parentPath.substr(parentPath.indexOf("/", 1));
          await this.mkdir({
            path: parentArgPath,
            directory: options.directory,
            recursive: doRecursive
          });
        }
        const now2 = Date.now();
        const pathObj = {
          path,
          folder: parentPath,
          type: "directory",
          size: 0,
          ctime: now2,
          mtime: now2
        };
        await this.dbRequest("put", [pathObj]);
      }
      /**
       * Remove a directory
       * @param options the options for the directory remove
       */
      async rmdir(options) {
        const { path, directory, recursive } = options;
        const fullPath = this.getPath(directory, path);
        const entry = await this.dbRequest("get", [fullPath]);
        if (entry === void 0)
          throw Error("Folder does not exist.");
        if (entry.type !== "directory")
          throw Error("Requested path is not a directory");
        const readDirResult = await this.readdir({ path, directory });
        if (readDirResult.files.length !== 0 && !recursive)
          throw Error("Folder is not empty");
        for (const entry2 of readDirResult.files) {
          const entryPath = `${path}/${entry2.name}`;
          const entryObj = await this.stat({ path: entryPath, directory });
          if (entryObj.type === "file") {
            await this.deleteFile({ path: entryPath, directory });
          } else {
            await this.rmdir({ path: entryPath, directory, recursive });
          }
        }
        await this.dbRequest("delete", [fullPath]);
      }
      /**
       * Return a list of files from the directory (not recursive)
       * @param options the options for the readdir operation
       * @return a promise that resolves with the readdir directory listing result
       */
      async readdir(options) {
        const path = this.getPath(options.directory, options.path);
        const entry = await this.dbRequest("get", [path]);
        if (options.path !== "" && entry === void 0)
          throw Error("Folder does not exist.");
        const entries = await this.dbIndexRequest("by_folder", "getAllKeys", [IDBKeyRange.only(path)]);
        const files = await Promise.all(entries.map(async (e) => {
          let subEntry = await this.dbRequest("get", [e]);
          if (subEntry === void 0) {
            subEntry = await this.dbRequest("get", [e + "/"]);
          }
          return {
            name: e.substring(path.length + 1),
            type: subEntry.type,
            size: subEntry.size,
            ctime: subEntry.ctime,
            mtime: subEntry.mtime,
            uri: subEntry.path
          };
        }));
        return { files };
      }
      /**
       * Return full File URI for a path and directory
       * @param options the options for the stat operation
       * @return a promise that resolves with the file stat result
       */
      async getUri(options) {
        const path = this.getPath(options.directory, options.path);
        let entry = await this.dbRequest("get", [path]);
        if (entry === void 0) {
          entry = await this.dbRequest("get", [path + "/"]);
        }
        return {
          uri: (entry === null || entry === void 0 ? void 0 : entry.path) || path
        };
      }
      /**
       * Return data about a file
       * @param options the options for the stat operation
       * @return a promise that resolves with the file stat result
       */
      async stat(options) {
        const path = this.getPath(options.directory, options.path);
        let entry = await this.dbRequest("get", [path]);
        if (entry === void 0) {
          entry = await this.dbRequest("get", [path + "/"]);
        }
        if (entry === void 0)
          throw Error("Entry does not exist.");
        return {
          name: entry.path.substring(path.length + 1),
          type: entry.type,
          size: entry.size,
          ctime: entry.ctime,
          mtime: entry.mtime,
          uri: entry.path
        };
      }
      /**
       * Rename a file or directory
       * @param options the options for the rename operation
       * @return a promise that resolves with the rename result
       */
      async rename(options) {
        await this._copy(options, true);
        return;
      }
      /**
       * Copy a file or directory
       * @param options the options for the copy operation
       * @return a promise that resolves with the copy result
       */
      async copy(options) {
        return this._copy(options, false);
      }
      async requestPermissions() {
        return { publicStorage: "granted" };
      }
      async checkPermissions() {
        return { publicStorage: "granted" };
      }
      /**
       * Function that can perform a copy or a rename
       * @param options the options for the rename operation
       * @param doRename whether to perform a rename or copy operation
       * @return a promise that resolves with the result
       */
      async _copy(options, doRename = false) {
        let { toDirectory } = options;
        const { to, from, directory: fromDirectory } = options;
        if (!to || !from) {
          throw Error("Both to and from must be provided");
        }
        if (!toDirectory) {
          toDirectory = fromDirectory;
        }
        const fromPath = this.getPath(fromDirectory, from);
        const toPath = this.getPath(toDirectory, to);
        if (fromPath === toPath) {
          return {
            uri: toPath
          };
        }
        if (isPathParent(fromPath, toPath)) {
          throw Error("To path cannot contain the from path");
        }
        let toObj;
        try {
          toObj = await this.stat({
            path: to,
            directory: toDirectory
          });
        } catch (e) {
          const toPathComponents = to.split("/");
          toPathComponents.pop();
          const toPath2 = toPathComponents.join("/");
          if (toPathComponents.length > 0) {
            const toParentDirectory = await this.stat({
              path: toPath2,
              directory: toDirectory
            });
            if (toParentDirectory.type !== "directory") {
              throw new Error("Parent directory of the to path is a file");
            }
          }
        }
        if (toObj && toObj.type === "directory") {
          throw new Error("Cannot overwrite a directory with a file");
        }
        const fromObj = await this.stat({
          path: from,
          directory: fromDirectory
        });
        const updateTime = async (path, ctime2, mtime) => {
          const fullPath = this.getPath(toDirectory, path);
          const entry = await this.dbRequest("get", [fullPath]);
          entry.ctime = ctime2;
          entry.mtime = mtime;
          await this.dbRequest("put", [entry]);
        };
        const ctime = fromObj.ctime ? fromObj.ctime : Date.now();
        switch (fromObj.type) {
          // The "from" object is a file
          case "file": {
            const file = await this.readFile({
              path: from,
              directory: fromDirectory
            });
            if (doRename) {
              await this.deleteFile({
                path: from,
                directory: fromDirectory
              });
            }
            let encoding;
            if (!(file.data instanceof Blob) && !this.isBase64String(file.data)) {
              encoding = Encoding.UTF8;
            }
            const writeResult = await this.writeFile({
              path: to,
              directory: toDirectory,
              data: file.data,
              encoding
            });
            if (doRename) {
              await updateTime(to, ctime, fromObj.mtime);
            }
            return writeResult;
          }
          case "directory": {
            if (toObj) {
              throw Error("Cannot move a directory over an existing object");
            }
            try {
              await this.mkdir({
                path: to,
                directory: toDirectory,
                recursive: false
              });
              if (doRename) {
                await updateTime(to, ctime, fromObj.mtime);
              }
            } catch (e) {
            }
            const contents = (await this.readdir({
              path: from,
              directory: fromDirectory
            })).files;
            for (const filename of contents) {
              await this._copy({
                from: `${from}/${filename.name}`,
                to: `${to}/${filename.name}`,
                directory: fromDirectory,
                toDirectory
              }, doRename);
            }
            if (doRename) {
              await this.rmdir({
                path: from,
                directory: fromDirectory
              });
            }
          }
        }
        return {
          uri: toPath
        };
      }
      isBase64String(str) {
        try {
          return btoa(atob(str)) == str;
        } catch (err) {
          return false;
        }
      }
    };
    FilesystemWeb._debug = true;
  }
});

// node_modules/@capacitor/share/dist/esm/web.js
var web_exports4 = {};
__export(web_exports4, {
  ShareWeb: () => ShareWeb
});
var ShareWeb;
var init_web4 = __esm({
  "node_modules/@capacitor/share/dist/esm/web.js"() {
    init_dist();
    ShareWeb = class extends WebPlugin {
      async canShare() {
        if (typeof navigator === "undefined" || !navigator.share) {
          return { value: false };
        } else {
          return { value: true };
        }
      }
      async share(options) {
        if (typeof navigator === "undefined" || !navigator.share) {
          throw this.unavailable("Share API not available in this browser");
        }
        await navigator.share({
          title: options.title,
          text: options.text,
          url: options.url
        });
        return {};
      }
    };
  }
});

// src/core.js
function dateKey(date = /* @__PURE__ */ new Date()) {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
}
function monthGrid(year, month) {
  const first = new Date(year, month, 1);
  const start2 = new Date(year, month, 1 - first.getDay());
  return Array.from({ length: 42 }, (_, i) => {
    const d = new Date(start2);
    d.setDate(start2.getDate() + i);
    return { key: dateKey(d), day: d.getDate(), current: d.getMonth() === month };
  });
}
function validateRecord(kind, data) {
  if (!kinds.includes(kind)) throw new Error("지원하지 않는 기록입니다.");
  const field = ["event", "post"].includes(kind) ? "title" : "text";
  if (!String(data[field] || "").trim()) throw new Error(field === "title" ? "제목을 적어 주세요." : "내용을 적어 주세요.");
  if (String(data[field]).length > (field === "title" ? 120 : 1e4)) throw new Error("내용이 너무 깁니다.");
  if (["event", "post"].includes(kind) && (!/^\d{4}-\d{2}-\d{2}$/.test(data.date || "") || dateKey(/* @__PURE__ */ new Date(`${data.date}T12:00:00`)) !== data.date)) throw new Error("올바른 날짜를 선택해 주세요.");
  if (kind === "event" && data.time && !/^([01]\d|2[0-3]):[0-5]\d$/.test(data.time)) throw new Error("올바른 시간을 선택해 주세요.");
  if (kind === "event" && data.target !== void 0 && !["shared", "member-1", "member-2"].includes(data.target)) throw new Error("일정 대상을 다시 선택해 주세요.");
  if (kind === "event" && data.endDate) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(data.endDate) || dateKey(/* @__PURE__ */ new Date(`${data.endDate}T12:00:00`)) !== data.endDate || data.endDate < data.date) throw new Error("종료 날짜를 확인해 주세요.");
    if (data.time && data.endTime && /* @__PURE__ */ new Date(`${data.endDate}T${data.endTime}:00`) <= /* @__PURE__ */ new Date(`${data.date}T${data.time}:00`)) throw new Error("종료 시간은 시작 시간보다 뒤여야 합니다.");
  }
  if (kind === "comment" && !data.postId) throw new Error("게시글을 찾을 수 없습니다.");
  if (kind === "comment" && data.replyTo !== void 0 && data.replyTo !== null && (typeof data.replyTo !== "string" || !data.replyTo.trim() || data.replyTo === data.postId)) throw new Error("올바른 답글 대상을 선택해 주세요.");
  return data;
}
function nextDay(key) {
  const d = /* @__PURE__ */ new Date(`${key}T12:00:00`);
  d.setDate(d.getDate() + 1);
  return dateKey(d);
}
function eventOnDate(row, key) {
  const data = row.data;
  if (data.date > key) return false;
  if (data.end?.date) return key < data.end.date;
  if (data.end?.dateTime) {
    const finish = new Date(data.end.dateTime);
    return /* @__PURE__ */ new Date(`${key}T00:00:00`) < finish;
  }
  return key <= (data.endDate || data.date);
}
function googleEvent(item) {
  const start2 = item.start?.dateTime || item.start?.date;
  if (!start2 || item.status === "cancelled") return null;
  const d = item.start.dateTime ? new Date(start2) : null;
  const target = item.extendedProperties?.shared?.geonjukongTarget;
  return { id: item.id, kind: "event", author_id: item.creator?.email || "", created_at: item.created, data: { title: item.summary || "(제목 없음)", text: item.description || "", date: d ? dateKey(d) : start2, time: d ? `${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}` : "", end: item.end, target: ["member-1", "member-2"].includes(target) ? target : "shared", google: true } };
}
function safeFileType(file) {
  const type = file.type.toLowerCase();
  const image = /^image\/(jpeg|png|webp|gif|heic|heif|avif)$/;
  if (!image.test(type) && !/^video\/(mp4|quicktime|webm|3gpp|x-m4v)$/.test(type)) throw new Error("사진 또는 동영상 파일만 올릴 수 있습니다.");
  if (file.size === 0) throw new Error("빈 파일은 올릴 수 없습니다.");
  return type;
}
function sortRecords(rows, order = "newest") {
  const direction = order === "oldest" ? 1 : -1;
  return [...rows].sort((a, b) => (order === "date" ? String(b.data.date).localeCompare(String(a.data.date)) : 0) || direction * ((Date.parse(a.created_at) || 0) - (Date.parse(b.created_at) || 0) || String(a.id).localeCompare(String(b.id))));
}
function daysBetween(from, to) {
  return Math.round((Date.parse(`${to}T00:00:00Z`) - Date.parse(`${from}T00:00:00Z`)) / 864e5);
}
function validDate(value) {
  return /^\d{4}-\d{2}-\d{2}$/.test(value || "") && dateKey(/* @__PURE__ */ new Date(`${value}T12:00:00`)) === value;
}
function annualDate(year, source) {
  const candidate = `${year}${source.slice(4)}`;
  return validDate(candidate) ? candidate : `${year}-02-28`;
}
function coupleEvents(year, settings2 = {}) {
  const rows = [];
  const add = (id, title, date) => {
    if (Number(date.slice(0, 4)) === year) rows.push({ id: `couple-${id}-${year}`, kind: "event", author_id: "", data: { title, date, time: "", automatic: true } });
  };
  for (const [index, birthday] of (settings2.birthdays || []).entries()) {
    if (validDate(birthday.date) && year >= Number(birthday.date.slice(0, 4))) add(`birthday-${birthday.id || index}`, `${birthday.name || "짝꿍"} 생일`, annualDate(year, birthday.date));
  }
  if (validDate(settings2.startDate)) {
    for (const count of [100, 200, 300]) {
      const date = /* @__PURE__ */ new Date(`${settings2.startDate}T12:00:00`);
      date.setDate(date.getDate() + count - 1);
      add(`day-${count}`, `${count}일 기념일`, dateKey(date));
    }
    const years = year - Number(settings2.startDate.slice(0, 4));
    if (years > 0) add(`anniversary-${years}`, `${years}주년`, annualDate(year, settings2.startDate));
  }
  return rows.sort((a, b) => a.data.date.localeCompare(b.data.date) || a.id.localeCompare(b.id));
}
function coupleDaySummary(settings2 = {}, today2 = dateKey()) {
  const elapsed = validDate(settings2.startDate) ? daysBetween(settings2.startDate, today2) : null;
  const year = Number(today2.slice(0, 4));
  const upcoming = [...coupleEvents(year, settings2), ...coupleEvents(year + 1, settings2)].find((row) => row.data.date >= today2);
  return { elapsed, label: elapsed === null ? "" : elapsed >= 0 ? `D+${elapsed}` : `D-${-elapsed}`, upcoming: upcoming ? { ...upcoming, remaining: daysBetween(today2, upcoming.data.date), label: upcoming.data.date === today2 ? "D-Day" : `D-${daysBetween(today2, upcoming.data.date)}` } : null };
}
function koreaHolidays(year) {
  if (!HOLIDAY_YEARS.includes(year)) return [];
  const fixed = [["01-01", "신정"], ["03-01", "삼일절"], ["05-05", "어린이날"], ["06-06", "현충일"], ["08-15", "광복절"], ["10-03", "개천절"], ["10-09", "한글날"], ["12-25", "성탄절"]];
  if (year >= 2026) fixed.push(["05-01", "노동절"], ["07-17", "제헌절"]);
  const special = {
    2023: [["01-21", "설날 연휴"], ["01-22", "설날"], ["01-23", "설날 연휴"], ["01-24", "대체공휴일 (설날)"], ["05-27", "부처님오신날"], ["05-29", "대체공휴일 (부처님오신날)"], ["09-28", "추석 연휴"], ["09-29", "추석"], ["09-30", "추석 연휴"], ["10-02", "임시공휴일"]],
    2024: [["02-09", "설날 연휴"], ["02-10", "설날"], ["02-11", "설날 연휴"], ["02-12", "대체공휴일 (설날)"], ["04-10", "국회의원선거"], ["05-06", "대체공휴일 (어린이날)"], ["05-15", "부처님오신날"], ["09-16", "추석 연휴"], ["09-17", "추석"], ["09-18", "추석 연휴"], ["10-01", "임시공휴일 (국군의 날)"]],
    2025: [["01-27", "임시공휴일"], ["01-28", "설날 연휴"], ["01-29", "설날"], ["01-30", "설날 연휴"], ["03-03", "대체공휴일 (삼일절)"], ["05-05", "부처님오신날"], ["05-06", "대체공휴일 (부처님오신날)"], ["06-03", "대통령선거"], ["10-05", "추석 연휴"], ["10-06", "추석"], ["10-07", "추석 연휴"], ["10-08", "대체공휴일 (추석)"]],
    2026: [["02-16", "설날 연휴"], ["02-17", "설날"], ["02-18", "설날 연휴"], ["03-02", "대체공휴일 (삼일절)"], ["05-24", "부처님오신날"], ["05-25", "대체공휴일 (부처님오신날)"], ["06-03", "전국동시지방선거"], ["08-17", "대체공휴일 (광복절)"], ["09-24", "추석 연휴"], ["09-25", "추석"], ["09-26", "추석 연휴"], ["10-05", "대체공휴일 (개천절)"]],
    2027: [["02-06", "설날 연휴"], ["02-07", "설날"], ["02-08", "설날 연휴"], ["02-09", "대체공휴일 (설날)"], ["05-03", "대체공휴일 (노동절)"], ["05-13", "부처님오신날"], ["07-19", "대체공휴일 (제헌절)"], ["08-16", "대체공휴일 (광복절)"], ["09-14", "추석 연휴"], ["09-15", "추석"], ["09-16", "추석 연휴"], ["10-04", "대체공휴일 (개천절)"], ["10-11", "대체공휴일 (한글날)"], ["12-27", "대체공휴일 (성탄절)"]],
    2028: [["01-26", "설날 연휴"], ["01-27", "설날"], ["01-28", "설날 연휴"], ["04-12", "국회의원선거"], ["05-02", "부처님오신날"], ["10-02", "추석 연휴"], ["10-03", "추석"], ["10-04", "추석 연휴"], ["10-05", "대체공휴일 (추석)"]]
  }[year];
  return [...fixed, ...special].map(([date, title]) => ({ date: `${year}-${date}`, title })).sort((a, b) => a.date.localeCompare(b.date));
}
var kinds, escapeHtml, HOLIDAY_YEARS;
var init_core = __esm({
  "src/core.js"() {
    kinds = ["event", "post", "comment", "message"];
    escapeHtml = (v = "") => String(v).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
    HOLIDAY_YEARS = [2023, 2024, 2025, 2026, 2027, 2028];
  }
});

// src/media.js
async function createThumbnail(file) {
  if (/^video\//i.test(file.type)) return videoThumbnail(file);
  if (!/^image\/(jpeg|png|webp|gif|avif)$/i.test(file.type)) return null;
  let bitmap;
  try {
    bitmap = await createImageBitmap(file);
    const scale = Math.min(1, 640 / Math.max(bitmap.width, bitmap.height));
    const canvas = document.createElement("canvas");
    canvas.width = Math.max(1, Math.round(bitmap.width * scale));
    canvas.height = Math.max(1, Math.round(bitmap.height * scale));
    const context = canvas.getContext("2d");
    if (!context) return null;
    context.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
    const blob = await new Promise((resolve2) => canvas.toBlob(resolve2, "image/webp", 0.72));
    if (!blob || blob.size >= file.size) return null;
    return new File([blob], `${file.name.replace(/\.[^.]+$/, "")}.preview.${blob.type === "image/webp" ? "webp" : "png"}`, { type: blob.type, lastModified: file.lastModified });
  } catch {
    return null;
  } finally {
    bitmap?.close();
  }
}
async function videoThumbnail(file) {
  let video, url, timer;
  try {
    video = document.createElement("video");
    if (typeof video.load !== "function") return null;
    video.muted = true;
    video.playsInline = true;
    video.preload = "auto";
    url = URL.createObjectURL(file);
    const frame = new Promise((resolve2) => {
      let seeking = false;
      video.onerror = () => resolve2(null);
      video.onloadeddata = () => {
        video.onloadeddata = null;
        if (Number.isFinite(video.duration) && video.duration > 0.2) {
          seeking = true;
          video.currentTime = Math.min(0.1, video.duration / 2);
        } else resolve2(video);
      };
      video.onseeked = () => {
        if (seeking) resolve2(video);
      };
      timer = setTimeout(() => resolve2(null), 8e3);
      video.src = url;
    });
    if (!await frame || !video.videoWidth || !video.videoHeight) return null;
    const scale = Math.min(1, 640 / Math.max(video.videoWidth, video.videoHeight));
    const canvas = document.createElement("canvas");
    canvas.width = Math.max(1, Math.round(video.videoWidth * scale));
    canvas.height = Math.max(1, Math.round(video.videoHeight * scale));
    const context = canvas.getContext("2d");
    if (!context) return null;
    context.drawImage(video, 0, 0, canvas.width, canvas.height);
    const blob = await new Promise((resolve2) => canvas.toBlob(resolve2, "image/webp", 0.72));
    if (!blob || blob.size >= file.size) return null;
    return new File([blob], `${file.name.replace(/\.[^.]+$/, "")}.preview.${blob.type === "image/webp" ? "webp" : "png"}`, { type: blob.type, lastModified: file.lastModified });
  } catch {
    return null;
  } finally {
    clearTimeout(timer);
    if (video) {
      video.onloadeddata = video.onseeked = video.onerror = null;
      video.removeAttribute?.("src");
      video.load?.();
    }
    if (url) URL.revokeObjectURL(url);
  }
}
function recordPreviewDownload(bytes, milliseconds) {
  measurements.downloads++;
  measurements.bytes += bytes;
  measurements.milliseconds += milliseconds;
}
function recordPreviewCacheHit() {
  measurements.cacheHits++;
}
function previewMeasurements() {
  return { ...measurements };
}
var previewFile, measurements;
var init_media = __esm({
  "src/media.js"() {
    previewFile = (file) => file?.thumbnail || file;
    measurements = { downloads: 0, bytes: 0, milliseconds: 0, cacheHits: 0 };
  }
});

// src/storage.js
async function db() {
  if (database) return database;
  database = await new Promise((resolve2, reject) => {
    const request = indexedDB.open(DB, 1);
    request.onupgradeneeded = () => {
      request.result.createObjectStore("records", { keyPath: "id" });
      request.result.createObjectStore("files", { keyPath: "id" });
    };
    request.onsuccess = () => resolve2(request.result);
    request.onerror = () => reject(request.error);
  });
  return database;
}
async function transaction(store, mode, action) {
  const database2 = await db();
  return new Promise((resolve2, reject) => {
    const tx = database2.transaction(store, mode);
    const request = action(tx.objectStore(store));
    tx.oncomplete = () => resolve2(request.result);
    tx.onerror = () => reject(tx.error);
    tx.onabort = () => reject(tx.error || new Error("저장하지 못했습니다."));
  });
}
var DB, database, local;
var init_storage = __esm({
  "src/storage.js"() {
    DB = "geonjukong-local-v1";
    local = {
      list: () => transaction("records", "readonly", (s2) => s2.getAll()),
      put: (row) => transaction("records", "readwrite", (s2) => s2.put(row)),
      async putIfVersion(row, version) {
        const database2 = await db();
        return new Promise((resolve2, reject) => {
          const tx = database2.transaction("records", "readwrite");
          const store = tx.objectStore("records");
          const request = store.get(row.id);
          let saved = false;
          request.onsuccess = () => {
            const current = request.result;
            if (current && (current.updated_at || current.created_at) === version) {
              store.put(row);
              saved = true;
            }
          };
          tx.oncomplete = () => resolve2(saved);
          tx.onerror = () => reject(tx.error);
          tx.onabort = () => reject(tx.error || new Error("저장하지 못했습니다."));
        });
      },
      remove: (id) => transaction("records", "readwrite", (s2) => s2.delete(id)),
      file: (id) => transaction("files", "readonly", (s2) => s2.get(id)),
      putFile: (id, blob) => transaction("files", "readwrite", (s2) => s2.put({ id, blob })),
      removeFile: (id) => transaction("files", "readwrite", (s2) => s2.delete(id)),
      async clear() {
        await transaction("records", "readwrite", (s2) => s2.clear());
        await transaction("files", "readwrite", (s2) => s2.clear());
      }
    };
  }
});

// src/bucket-list.js
function validateBucketItem(data) {
  const title = String(data.title || "").trim();
  const notes = String(data.notes || "").trim();
  const completed_on = data.completed_on || null;
  if (!title || title.length > 120) throw new Error("목표를 1~120자로 입력해 주세요.");
  if (notes.length > 2e3) throw new Error("메모는 2,000자 이내로 적어 주세요.");
  if (completed_on && (!/^\d{4}-\d{2}-\d{2}$/.test(completed_on) || dateKey(/* @__PURE__ */ new Date(`${completed_on}T12:00:00`)) !== completed_on)) throw new Error("올바른 달성 날짜를 선택해 주세요.");
  return { title, notes, completed_on };
}
function createBucketList({ state: state2, repository: repository2, local: local2, dialog: dialog2, closeDialog: closeDialog2, render: render2, toast: toast2 }) {
  let saving = false, loadSequence = 0;
  const items = () => state2.bucketItems || [];
  const find = (id) => items().find((row) => row.id === id);
  const version = (row) => row?.updated_at || row?.created_at || "";
  const conflict = "다른 기기에서 목표가 변경되었어요. 목록을 새로 불러온 뒤 다시 시도해 주세요.";
  async function load2() {
    const mode = state2.mode, user = state2.user, sequence = ++loadSequence;
    const rows = mode === "demo" ? (await local2.list()).filter((row) => row.kind === "bucket").map((row) => ({ ...row, ...row.data })) : await repository2.bucketItems();
    if (state2.mode === mode && state2.user === user && sequence === loadSequence) state2.bucketItems = rows;
    return rows;
  }
  async function refreshAfterChange(mode, user, message) {
    if (state2.mode !== mode || state2.user !== user) return;
    render2();
    toast2(message);
    try {
      await load2();
      if (state2.mode === mode && state2.user === user) render2();
    } catch {
      if (state2.mode === mode && state2.user === user) toast2("변경은 저장했어요. 최신 목록을 불러오지 못했으니 잠시 후 새로고침해 주세요.");
    }
  }
  function view() {
    const rows = [...items()].sort((a, b) => Boolean(a.completed_on) - Boolean(b.completed_on) || String(b.created_at).localeCompare(String(a.created_at)) || a.id.localeCompare(b.id));
    const completed2 = rows.filter((row) => row.completed_on).length;
    return `<div class="page-heading"><div><p class="eyebrow">OUR BUCKET LIST</p><h1>버킷리스트</h1><p class="subtitle">함께 이루고 싶은 목표를 하나씩 채워 가요.</p></div><button type="button" class="primary" data-action="bucket-new">+ 목표 추가</button></div><section class="card bucket-list" aria-label="우리의 버킷리스트"><div class="bucket-progress"><strong>달성 ${completed2} / ${rows.length}</strong><span>체크하면 달성 날짜가 기록돼요.</span></div>${rows.length ? `<ul class="bucket-items">${rows.map((row) => `<li class="bucket-item ${row.completed_on ? "completed" : ""}"><button type="button" class="bucket-check" role="checkbox" aria-checked="${Boolean(row.completed_on)}" aria-label="${escapeHtml(row.title)} ${row.completed_on ? "달성 취소" : "달성하기"}" data-action="bucket-toggle" data-id="${escapeHtml(row.id)}">${row.completed_on ? "✓" : ""}</button><div class="bucket-copy"><strong>${escapeHtml(row.title)}</strong>${row.notes ? `<p>${escapeHtml(row.notes)}</p>` : ""}${row.completed_on ? `<button type="button" class="text-button bucket-date" data-action="bucket-edit" data-id="${escapeHtml(row.id)}">✓ ${escapeHtml(row.completed_on)} 달성 · 날짜 수정</button>` : '<span class="bucket-pending">함께 도전 중</span>'}</div><div class="bucket-tools"><button type="button" class="text-button" data-action="bucket-edit" data-id="${escapeHtml(row.id)}" aria-label="${escapeHtml(row.title)} 수정">수정</button><button type="button" class="text-button danger" data-action="bucket-delete" data-id="${escapeHtml(row.id)}" aria-label="${escapeHtml(row.title)} 삭제">삭제</button></div></li>`).join("")}</ul>` : '<div class="empty"><h3>함께 이루고 싶은 일이 있나요?</h3><p>여행, 작은 습관, 꼭 해 보고 싶은 일을 목표로 남겨 주세요.</p><button type="button" class="secondary" data-action="bucket-new">첫 목표 추가</button></div>'}</section>`;
  }
  function openEditor2(row) {
    dialog2(row ? "목표 수정" : "새 목표", `<form id="bucket-form" data-id="${escapeHtml(row?.id || "")}" data-version="${escapeHtml(version(row))}"><label>목표<input name="title" value="${escapeHtml(row?.title || "")}" maxlength="120" placeholder="함께 이루고 싶은 일" required></label><label>메모<textarea name="notes" rows="3" maxlength="2000" placeholder="어떻게 이루고 싶은지 적어 주세요.">${escapeHtml(row?.notes || "")}</textarea></label><label class="bucket-completed-field"><input type="checkbox" name="completed" ${row?.completed_on ? "checked" : ""}> 달성했어요</label><label>달성 날짜<input type="date" name="completedOn" value="${escapeHtml(row?.completed_on || dateKey())}" required></label><p class="setting-hint">달성했어요에 체크하면 선택한 날짜가 기록돼요. 체크를 해제하면 달성을 취소해요.</p><p class="form-error" role="alert"></p><div class="modal-actions"><button type="button" class="secondary" data-action="close">취소</button><button type="submit" class="primary">저장</button></div></form>`);
  }
  async function save(data, row, expectedVersion = version(row)) {
    data = validateBucketItem(data);
    if (state2.mode === "live") return repository2.saveBucketItem(state2.user, data, row?.id, expectedVersion || void 0);
    const timestamp = new Date(Math.max(Date.now(), row ? Date.parse(version(row)) + 1 : 0)).toISOString();
    const record = { id: row?.id || crypto.randomUUID(), kind: "bucket", author_id: row?.author_id || state2.user, data, created_at: row?.created_at || timestamp, updated_at: timestamp };
    if (row) {
      if (!await local2.putIfVersion(record, expectedVersion)) throw new Error(conflict);
    } else await local2.put(record);
    return { ...record, ...data };
  }
  async function action(action2, button) {
    if (!action2?.startsWith("bucket-")) return false;
    if (saving) return true;
    if (action2 === "bucket-new") {
      openEditor2();
      return true;
    }
    const row = find(button.dataset.id);
    if (!row) throw new Error("목표를 찾을 수 없어요. 목록을 새로 불러와 주세요.");
    if (action2 === "bucket-edit") {
      openEditor2(row);
      return true;
    }
    if (action2 === "bucket-delete") {
      dialog2("목표 삭제", `<p class="bucket-delete-message">${escapeHtml(row.title)} 목표를 삭제할까요?</p><div class="modal-actions"><button type="button" class="secondary" data-action="close">취소</button><button type="button" class="primary" data-action="bucket-confirm-delete" data-id="${escapeHtml(row.id)}" data-version="${escapeHtml(version(row))}">삭제</button></div>`);
      return true;
    }
    if (!["bucket-toggle", "bucket-confirm-delete"].includes(action2)) return false;
    const mode = state2.mode, user = state2.user;
    saving = true;
    button.disabled = true;
    try {
      if (action2 === "bucket-toggle") {
        const saved = await save({ title: row.title, notes: row.notes, completed_on: row.completed_on ? null : dateKey() }, row);
        if (state2.mode !== mode || state2.user !== user) return true;
        loadSequence++;
        state2.bucketItems = [...items().filter((item) => item.id !== row.id), saved];
      } else {
        if (mode === "live") await repository2.removeBucketItem(row.id, button.dataset.version || version(row));
        else {
          const current = (await local2.list()).find((item) => item.id === row.id && item.kind === "bucket");
          if (!current || version(current) !== button.dataset.version) throw new Error(conflict);
          await local2.remove(row.id);
        }
        if (state2.mode !== mode || state2.user !== user) return true;
        loadSequence++;
        state2.bucketItems = items().filter((item) => item.id !== row.id);
        if (button.isConnected !== false) closeDialog2();
      }
      await refreshAfterChange(mode, user, action2 === "bucket-confirm-delete" ? "목표를 삭제했어요." : row.completed_on ? "달성을 취소했어요." : "목표를 달성했어요!");
      return true;
    } finally {
      saving = false;
      button.disabled = false;
    }
  }
  async function submit(form) {
    if (form.id !== "bucket-form") return false;
    if (saving) return true;
    const mode = state2.mode, user = state2.user;
    saving = true;
    const submitButton = form.querySelector('[type="submit"]');
    if (submitButton) submitButton.disabled = true;
    try {
      const values = new FormData(form);
      const row = form.dataset.id ? find(form.dataset.id) : void 0;
      if (form.dataset.id && !row) throw new Error("목표를 찾을 수 없어요. 목록을 새로 불러와 주세요.");
      const completed_on = values.has("completed") ? values.get("completedOn") : null;
      if (values.has("completed") && !completed_on) throw new Error("달성 날짜를 선택해 주세요.");
      const saved = await save({ title: values.get("title"), notes: values.get("notes"), completed_on }, row, form.dataset.version);
      if (state2.mode !== mode || state2.user !== user) return true;
      loadSequence++;
      state2.bucketItems = [...items().filter((item) => item.id !== saved.id), saved];
      if (form.isConnected !== false) closeDialog2();
      await refreshAfterChange(mode, user, "목표를 저장했어요.");
      return true;
    } finally {
      saving = false;
      if (submitButton) submitButton.disabled = false;
    }
  }
  return { render: view, load: load2, action, submit };
}
var init_bucket_list = __esm({
  "src/bucket-list.js"() {
    init_core();
  }
});

// src/profiles.js
function validateProfile(data) {
  const profile = { name: String(data.name || "").trim(), bio: String(data.bio || "").trim(), status: String(data.status || "").trim(), photo: String(data.photo || "") };
  if (profile.name.length > 30) throw new Error("이름은 30자까지 입력해 주세요.");
  if (profile.bio.length > 1e3) throw new Error("자기소개는 1,000자까지 입력해 주세요.");
  if (profile.status.length > 100) throw new Error("상태메시지는 100자까지 입력해 주세요.");
  if (profile.photo && (!/^data:image\/(jpeg|png|webp);base64,[A-Za-z0-9+/]+=*$/.test(profile.photo) || profile.photo.length > MAX_PHOTO_LENGTH)) throw new Error("프로필 사진을 다시 선택해 주세요.");
  return profile;
}
async function createProfilePhoto(file) {
  if (!/^image\/(jpeg|png|webp|gif|heic|heif|avif)$/i.test(file.type || "")) throw new Error("프로필 사진은 이미지 파일을 선택해 주세요.");
  if (!file.size || file.size > 15 * 1024 * 1024) throw new Error("프로필 사진은 15MB 이하의 파일을 선택해 주세요.");
  const url = URL.createObjectURL(file);
  try {
    const image = new Image();
    await new Promise((resolve2, reject) => {
      image.onload = resolve2;
      image.onerror = () => reject(new Error("사진을 읽을 수 없어요. JPEG 또는 PNG 사진으로 다시 선택해 주세요."));
      image.src = url;
    });
    const edge = Math.min(image.naturalWidth, image.naturalHeight);
    if (!edge) throw new Error("사진의 크기를 확인할 수 없어요. 다른 사진을 선택해 주세요.");
    const canvas = document.createElement("canvas");
    canvas.width = canvas.height = Math.min(384, edge);
    const context = canvas.getContext("2d");
    if (!context) throw new Error("이 기기에서 사진을 처리할 수 없어요.");
    context.drawImage(image, (image.naturalWidth - edge) / 2, (image.naturalHeight - edge) / 2, edge, edge, 0, 0, canvas.width, canvas.height);
    let photo = canvas.toDataURL("image/webp", 0.82);
    if (photo.length > MAX_PHOTO_LENGTH) photo = canvas.toDataURL("image/jpeg", 0.65);
    validateProfile({ photo });
    return photo;
  } finally {
    URL.revokeObjectURL(url);
  }
}
function createProfiles({ state: state2, repository: repository2, dialog: dialog2, closeDialog: closeDialog2, render: render2, toast: toast2, currentEmail = () => "" }) {
  let draftPhoto = "", selection = 0, loadSequence = 0, processing = false, saving = false;
  const rows = () => state2.profiles || [];
  function demoProfiles() {
    try {
      const saved = JSON.parse(localStorage.getItem(DEMO_KEY) || "[]");
      return Array.isArray(saved) ? saved.filter((row) => row && typeof row.user_id === "string" && row.data && typeof row.data === "object") : [];
    } catch {
      return [];
    }
  }
  function resolveId(id) {
    if (id !== "other") return id;
    if (state2.mode === "demo") return state2.user === "demo-me" ? "demo-partner" : "demo-me";
    return rows().find((row) => row.user_id !== state2.user)?.user_id || "other";
  }
  function profileOf(id) {
    return rows().find((row) => row.user_id === resolveId(id));
  }
  function nameOf2(id) {
    id = resolveId(id);
    const row = profileOf(id);
    if (row?.data?.name) return row.data.name;
    if (state2.mode === "demo") return demoNames[id] || "짝꿍";
    const email = row?.email || (id === state2.user ? currentEmail() : "");
    const member = state2.members.find((item) => item.email === email);
    if (member) return member.display_name || (id === state2.user ? "나" : "짝꿍");
    if (id === "other") return state2.members.find((item) => item.email !== currentEmail())?.display_name || "짝꿍";
    return id === state2.user ? "나" : "짝꿍";
  }
  function avatar2(id, small = false) {
    id = resolveId(id);
    const row = profileOf(id), name = nameOf2(id), photo = row?.data?.photo;
    return `<span class="avatar profile-avatar ${id === state2.user ? "me" : "partner"} ${small ? "small" : ""}" role="button" tabindex="0" data-action="profile-open" data-id="${escapeHtml(id)}" aria-label="${escapeHtml(name)} 프로필 보기">${photo ? `<img src="${escapeHtml(photo)}" alt="">` : escapeHtml(name.slice(0, 1))}</span>`;
  }
  function open(id) {
    id = resolveId(id);
    const data = profileOf(id)?.data || {}, name = nameOf2(id);
    dialog2(`${escapeHtml(name)}의 프로필`, `<section class="profile-detail"><div class="profile-photo">${data.photo ? `<img src="${escapeHtml(data.photo)}" alt="${escapeHtml(name)} 프로필 사진">` : `<span aria-hidden="true">${escapeHtml(name.slice(0, 1))}</span>`}</div><h3>${escapeHtml(name)}</h3><p class="profile-status">${escapeHtml(data.status || "아직 상태메시지가 없어요.")}</p><div class="profile-bio"><h4>자기소개</h4><p>${escapeHtml(data.bio || "아직 자기소개가 없어요.")}</p></div>${id === state2.user ? '<button type="button" class="secondary" data-action="profile-edit">내 프로필 수정</button>' : ""}</section>`);
  }
  function edit() {
    const data = profileOf(state2.user)?.data || {};
    selection++;
    processing = false;
    draftPhoto = data.photo || "";
    dialog2("내 프로필 수정", `<form id="profile-form"><div class="profile-edit-photo" id="profile-photo-preview">${draftPhoto ? `<img src="${escapeHtml(draftPhoto)}" alt="선택한 프로필 사진">` : "<span>사진 없음</span>"}</div><label class="file-input">프로필 사진 선택<input id="profile-photo" type="file" accept="image/jpeg,image/png,image/webp,image/gif,image/heic,image/heif,image/avif"></label><button type="button" class="text-button" data-action="profile-remove-photo">프로필 사진 지우기</button><label>이름<input name="name" maxlength="30" value="${escapeHtml(data.name || "")}" placeholder="상대에게 보일 이름"></label><label>상태메시지<input name="status" maxlength="100" value="${escapeHtml(data.status || "")}" placeholder="요즘 나의 한마디"></label><label>자기소개<textarea name="bio" rows="5" maxlength="1000" placeholder="나를 소개해 주세요">${escapeHtml(data.bio || "")}</textarea></label><p class="setting-hint">이름과 프로필은 우리 두 사람에게 보여요.</p><p class="form-error" role="alert"></p><div class="modal-actions"><button type="button" class="secondary" data-action="close">취소</button><button type="submit" class="primary">프로필 저장</button></div></form>`);
  }
  async function load2() {
    const mode = state2.mode, user = state2.user, sequence = ++loadSequence;
    const profiles2 = mode === "live" ? await repository2.profiles() : demoProfiles();
    if (state2.mode === mode && state2.user === user && sequence === loadSequence) state2.profiles = profiles2;
    return profiles2;
  }
  async function action(action2, button) {
    if (action2 === "profile-open") {
      open(button.dataset.id);
      return true;
    }
    if (action2 === "profile-edit") {
      edit();
      return true;
    }
    if (action2 === "profile-remove-photo") {
      selection++;
      processing = false;
      draftPhoto = "";
      const form = document.querySelector("#profile-form");
      if (form) {
        form.querySelector("#profile-photo-preview").innerHTML = "<span>사진 없음</span>";
        form.querySelector("#profile-photo").value = "";
        form.querySelector(".form-error").textContent = "";
        form.querySelector('[type="submit"]').disabled = false;
      }
      return true;
    }
    return false;
  }
  async function change(event) {
    if (event.target.id !== "profile-photo") return false;
    const input = event.target, form = input.form, file = input.files?.[0];
    if (!file) return true;
    const version = ++selection, user = state2.user;
    const error = form.querySelector(".form-error"), submit2 = form.querySelector('[type="submit"]');
    error.textContent = "";
    submit2.disabled = true;
    processing = true;
    try {
      const photo = await createProfilePhoto(file);
      if (version !== selection || user !== state2.user || !form.isConnected) return true;
      draftPhoto = photo;
      form.querySelector("#profile-photo-preview").innerHTML = `<img src="${escapeHtml(photo)}" alt="선택한 프로필 사진">`;
    } catch (failure) {
      if (version === selection && form.isConnected) error.textContent = failure.message;
    } finally {
      if (version === selection) {
        processing = false;
        if (form.isConnected) submit2.disabled = false;
      }
    }
    return true;
  }
  async function submit(form) {
    if (form.id !== "profile-form") return false;
    if (processing || saving) return true;
    const error = form.querySelector(".form-error"), button = form.querySelector('[type="submit"]');
    error.textContent = "";
    button.disabled = true;
    saving = true;
    const mode = state2.mode, user = state2.user;
    try {
      const data = validateProfile({ name: form.elements.name.value, status: form.elements.status.value, bio: form.elements.bio.value, photo: draftPhoto });
      let row;
      if (mode === "live") {
        const saved = await repository2.saveProfile(user, data);
        row = Array.isArray(saved) ? saved[0] : saved;
        if (!row) throw new Error("프로필을 저장하지 못했어요. 다시 시도해 주세요.");
      } else {
        row = { user_id: user, data, updated_at: (/* @__PURE__ */ new Date()).toISOString() };
        const saved = demoProfiles().filter((item) => item.user_id !== user);
        localStorage.setItem(DEMO_KEY, JSON.stringify([...saved, row]));
      }
      if (mode === state2.mode && user === state2.user) {
        loadSequence++;
        state2.profiles = [...rows().filter((item) => item.user_id !== user), row];
        if (form.isConnected) closeDialog2();
        render2();
        toast2("프로필을 저장했어요.");
      }
    } catch (failure) {
      if (form.isConnected) error.textContent = failure.message;
    } finally {
      saving = false;
      if (form.isConnected) button.disabled = false;
    }
    return true;
  }
  return { load: load2, avatar: avatar2, nameOf: nameOf2, open, action, change, submit };
}
var DEMO_KEY, MAX_PHOTO_LENGTH, demoNames;
var init_profiles = __esm({
  "src/profiles.js"() {
    init_core();
    DEMO_KEY = "geonjukong-demo-profiles";
    MAX_PHOTO_LENGTH = 18e4;
    demoNames = { "demo-me": "나", "demo-partner": "짝꿍" };
  }
});

// src/platform.js
function isAuthCallback(value) {
  try {
    const url = new URL(value);
    return url.protocol === "com.geonjukong.couple:" && url.hostname === "auth" && url.pathname === "/callback" && !url.username && !url.password;
  } catch {
    return false;
  }
}
var NATIVE_CALLBACK, native;
var init_platform = __esm({
  "src/platform.js"() {
    NATIVE_CALLBACK = "com.geonjukong.couple://auth/callback";
    native = {
      async setBadge(hasUnread) {
        if (this.active) return window.GEONJUKONG_NATIVE.setBadge?.(hasUnread);
        if (hasUnread) await navigator.setAppBadge?.();
        else await navigator.clearAppBadge?.();
      },
      get canPickMedia() {
        return this.active && typeof window.GEONJUKONG_NATIVE.pickMedia === "function";
      },
      async pickMedia() {
        return window.GEONJUKONG_NATIVE.pickMedia();
      },
      async onBack(handler) {
        return this.active ? window.GEONJUKONG_NATIVE.onBack?.(handler) : void 0;
      },
      async exit() {
        if (this.active) await window.GEONJUKONG_NATIVE.exit();
      },
      get active() {
        return Boolean(window.GEONJUKONG_NATIVE?.active);
      },
      async open(url) {
        if (!this.active) throw new Error("설치형 앱에서만 사용할 수 있습니다.");
        await window.GEONJUKONG_NATIVE.open(url);
      },
      async closeBrowser() {
        if (this.active) await window.GEONJUKONG_NATIVE.closeBrowser();
      },
      async saveFile(blob, name) {
        if (!this.active) throw new Error("설치형 앱에서만 사용할 수 있습니다.");
        await window.GEONJUKONG_NATIVE.saveFile(blob, name);
      },
      async listen(handler) {
        return this.active ? window.GEONJUKONG_NATIVE.listen(handler) : void 0;
      }
    };
  }
});

// src/backend.js
function setSession(value) {
  session = value;
  if (value) localStorage.setItem(SESSION_KEY, JSON.stringify(value));
  else localStorage.removeItem(SESSION_KEY);
}
async function authRequest(path, body, generation2 = sessionGeneration) {
  const response = await fetch(`${config.supabaseUrl}/auth/v1/${path}`, { method: "POST", headers: { apikey: config.supabaseAnonKey, "Content-Type": "application/json" }, body: JSON.stringify(body) });
  const data = await response.json();
  if (!response.ok) {
    const error = new Error(data.msg || data.error_description || "로그인에 실패했습니다.");
    error.status = response.status;
    throw error;
  }
  if (generation2 !== sessionGeneration) throw new Error("로그인 세션이 종료되었습니다.");
  if (data.provider_token) providerToken = data.provider_token;
  const { provider_token, provider_refresh_token, ...appSession } = data;
  setSession({ ...appSession, expires_at: Date.now() + data.expires_in * 1e3 });
  if (provider_refresh_token) {
    try {
      await googleRequest({ action: "store", refresh_token: provider_refresh_token });
      googleWarning = "";
    } catch {
      googleWarning = "Google 지속 연결을 저장하지 못했습니다. google-auth 서버 배포와 네트워크를 확인한 뒤 다시 연결해 주세요.";
    }
  }
  return data;
}
async function accessToken() {
  if (!session) throw new Error("로그인이 필요합니다.");
  if (session.expires_at < Date.now() + 6e4) {
    if (!refreshPending) {
      const generation2 = sessionGeneration;
      refreshPending = authRequest("token?grant_type=refresh_token", { refresh_token: session.refresh_token }, generation2).catch((error) => {
        if (generation2 === sessionGeneration && (error.status === 400 || error.status === 401)) setSession(null);
        throw error;
      }).finally(() => {
        refreshPending = null;
      });
    }
    await refreshPending;
  }
  return session.access_token;
}
async function googleRequest(body) {
  const response = await fetch(`${config.supabaseUrl}/functions/v1/google-auth`, { method: "POST", headers: { apikey: config.supabaseAnonKey, Authorization: `Bearer ${await accessToken()}`, "Content-Type": "application/json" }, body: JSON.stringify(body) });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || "Google 지속 연결 서버를 확인한 뒤 다시 연결해 주세요.");
  return data;
}
async function rest(path, options = {}) {
  const response = await fetch(`${config.supabaseUrl}/rest/v1/${path}`, { ...options, headers: { apikey: config.supabaseAnonKey, Authorization: `Bearer ${await accessToken()}`, "Content-Type": "application/json", Prefer: "return=representation", ...options.headers } });
  if (!response.ok) {
    const error = await response.json().catch(() => ({}));
    throw new Error(error.message || "공유 서버에 연결하지 못했습니다.");
  }
  return response.status === 204 ? null : response.json();
}
var config, SESSION_KEY, configured, session, refreshPending, providerToken, googleWarning, sessionGeneration, auth, repository;
var init_backend = __esm({
  "src/backend.js"() {
    init_storage();
    init_core();
    init_bucket_list();
    init_profiles();
    init_platform();
    config = window.APP_CONFIG;
    SESSION_KEY = "geonjukong-auth";
    configured = Boolean(config.supabaseUrl && config.supabaseAnonKey);
    try {
      session = JSON.parse(localStorage.getItem(SESSION_KEY) || "null");
    } catch {
      session = null;
    }
    googleWarning = "";
    sessionGeneration = 0;
    auth = {
      get googleWarning() {
        return googleWarning;
      },
      async googleToken() {
        return googleRequest({ action: "token" });
      },
      get user() {
        return session?.user || null;
      },
      takeProviderToken() {
        const value = providerToken;
        providerToken = void 0;
        return value;
      },
      async callback(callbackUrl) {
        if (callbackUrl && !isAuthCallback(callbackUrl)) throw new Error("허용되지 않은 앱 로그인 주소입니다.");
        const url = new URL(callbackUrl || location.href);
        const error = url.searchParams.get("error_description");
        if (error) {
          history.replaceState(null, "", location.pathname);
          throw new Error(error);
        }
        const code = url.searchParams.get("code");
        if (!code) return;
        const storage = native.active ? localStorage : sessionStorage;
        const verifier = storage.getItem("geonjukong-pkce");
        history.replaceState(null, "", location.pathname);
        if (!verifier) throw new Error("로그인을 시작한 브라우저에서 다시 시도해 주세요.");
        await authRequest("token?grant_type=pkce", { auth_code: code, code_verifier: verifier });
        storage.removeItem("geonjukong-pkce");
        await native.closeBrowser();
      },
      async login() {
        if (!configured) throw new Error("먼저 config.js에 Supabase 공개 설정을 입력해 주세요.");
        const bytes = crypto.getRandomValues(new Uint8Array(32));
        const verifier = Array.from(bytes, (b) => b.toString(16).padStart(2, "0")).join("");
        (native.active ? localStorage : sessionStorage).setItem("geonjukong-pkce", verifier);
        const digest = new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(verifier)));
        const challenge = btoa(String.fromCharCode(...digest)).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
        const url = new URL(`${config.supabaseUrl}/auth/v1/authorize`);
        url.search = new URLSearchParams({ provider: "google", redirect_to: native.active ? NATIVE_CALLBACK : `${location.origin}${location.pathname}`, code_challenge: challenge, code_challenge_method: "s256" });
        url.searchParams.set("access_type", "offline");
        url.searchParams.set("scopes", "openid email profile https://www.googleapis.com/auth/calendar.events https://www.googleapis.com/auth/drive.file https://www.googleapis.com/auth/drive.readonly https://www.googleapis.com/auth/user.birthday.read");
        url.searchParams.set("prompt", "consent");
        if (native.active) {
          await native.open(url.toString());
        } else location.assign(url);
      },
      async logout() {
        const access2 = session?.access_token;
        sessionGeneration++;
        providerToken = void 0;
        googleWarning = "";
        setSession(null);
        if (!access2) return { remote: true };
        try {
          const response = await fetch(`${config.supabaseUrl}/auth/v1/logout`, { method: "POST", headers: { apikey: config.supabaseAnonKey, Authorization: `Bearer ${access2}` } });
          return { remote: response.ok };
        } catch {
          return { remote: false };
        }
      }
    };
    repository = {
      async bucketItems() {
        return rest("bucket_items?select=*&order=created_at.asc,id.asc");
      },
      async saveBucketItem(userId, data, id, expectedVersion) {
        data = validateBucketItem(data);
        const filter = id ? `bucket_items?id=eq.${encodeURIComponent(id)}${expectedVersion ? `&updated_at=eq.${encodeURIComponent(expectedVersion)}` : ""}` : "bucket_items";
        const rows = await rest(filter, { method: id ? "PATCH" : "POST", body: JSON.stringify(id ? data : { ...data, author_id: userId }) });
        if (!rows?.length) throw new Error("목표가 변경되었거나 삭제되었어요. 목록을 새로고침하고 다시 시도해 주세요.");
        return rows[0];
      },
      async removeBucketItem(id, expectedVersion) {
        const rows = await rest(`bucket_items?id=eq.${encodeURIComponent(id)}${expectedVersion ? `&updated_at=eq.${encodeURIComponent(expectedVersion)}` : ""}`, { method: "DELETE" });
        if (!rows?.length) throw new Error("목표가 변경되었거나 삭제되었어요. 목록을 새로고침하고 다시 시도해 주세요.");
      },
      async profiles() {
        return rest("member_profiles?select=user_id,email,data,updated_at");
      },
      async saveProfile(userId, data) {
        data = validateProfile(data);
        const rows = await rest("member_profiles?on_conflict=user_id", { method: "POST", headers: { Prefer: "resolution=merge-duplicates,return=representation" }, body: JSON.stringify({ user_id: userId, data }) });
        if (!rows?.length) throw new Error("프로필을 저장하지 못했어요. 다시 시도해 주세요.");
        return rows[0];
      },
      async updateHomePhoto(selection) {
        try {
          return await rest("rpc/update_home_photo", { method: "POST", body: JSON.stringify({ selection }) });
        } catch (error) {
          const validPhotos = Array.isArray(selection) && selection.every((item) => item.file?.id && item.file.name && item.file.source === "drive" && item.file.type?.startsWith("image/"));
          if (error.message === "올바른 사진을 선택해 주세요." && validPhotos) {
            throw new Error("홈 사진 저장 형식이 서버와 맞지 않아요. 서버의 홈 사진 업데이트를 적용한 뒤 다시 저장해 주세요.", { cause: error });
          }
          throw error;
        }
      },
      async coupleSettings() {
        const rows = await rest("couple_settings?id=eq.1&select=data");
        return rows[0]?.data || {};
      },
      async createCoupleSettings(data) {
        return rest("couple_settings?on_conflict=id", { method: "POST", headers: { Prefer: "resolution=ignore-duplicates,return=representation" }, body: JSON.stringify({ id: 1, data }) });
      },
      async updateCoupleDate(field, date) {
        return rest("rpc/update_couple_date", { method: "POST", body: JSON.stringify({ field, date_value: date }) });
      },
      async saveCoupleSettings(data) {
        return rest("couple_settings?on_conflict=id", { method: "POST", headers: { Prefer: "resolution=merge-duplicates,return=representation" }, body: JSON.stringify({ id: 1, data }) });
      },
      async notificationReads() {
        return rest("notification_reads?select=record_id,read_at");
      },
      async markNotificationRead(userId, recordId) {
        return rest("notification_reads?on_conflict=user_id,record_id", { method: "POST", headers: { Prefer: "resolution=merge-duplicates,return=representation" }, body: JSON.stringify({ user_id: userId, record_id: recordId, read_at: (/* @__PURE__ */ new Date()).toISOString() }) });
      },
      async markNotificationsRead(userId, recordIds) {
        return rest("notification_reads?on_conflict=user_id,record_id", { method: "POST", headers: { Prefer: "resolution=merge-duplicates,return=minimal" }, body: JSON.stringify(recordIds.map((record_id) => ({ user_id: userId, record_id, read_at: (/* @__PURE__ */ new Date()).toISOString() }))) });
      },
      async saveCalendarNotice(userId, notice) {
        return rest("records?on_conflict=id", { method: "POST", headers: { Prefer: "resolution=ignore-duplicates,return=representation" }, body: JSON.stringify({ id: notice.id, author_id: userId, kind: "event_notice", data: { text: notice.title, title: notice.title, date: notice.date, eventId: notice.eventId } }) });
      },
      async members() {
        return rest("members?select=slot,email,display_name");
      },
      async list() {
        const all = [];
        let offset = 0;
        while (true) {
          const page = await rest(`records?select=*&order=created_at.asc,id.asc&limit=500&offset=${offset}`);
          all.push(...page);
          if (page.length < 500) return all;
          offset += 500;
        }
      },
      async save(mode, userId, kind, data, existingId, expectedVersion) {
        validateRecord(kind, data);
        const guardedUpdate = Boolean(existingId && kind === "post" && data.space === "board");
        const conflict = "다른 곳에서 게시글이 수정되었거나 삭제되었어요. 작성한 내용을 복사한 뒤 게시글을 다시 열어 확인해 주세요.";
        if (guardedUpdate && !expectedVersion) throw new Error(conflict);
        if (mode === "demo") {
          const records2 = await local.list();
          const old = existingId ? records2.find((r) => r.id === existingId) : null;
          if (old && (old.kind !== kind || old.data.space !== data.space)) throw new Error("기록의 종류나 공간은 바꿀 수 없습니다.");
          if (kind === "comment") {
            if (!records2.some((row3) => row3.id === data.postId && row3.kind === "post")) throw new Error("댓글을 작성할 기록이 없습니다.");
            if (old && (old.data.postId !== data.postId || old.data.replyTo !== data.replyTo)) throw new Error("답글 대상을 바꿀 수 없습니다.");
            if (!old && data.replyTo && !records2.some((row3) => row3.id === data.replyTo && row3.kind === "comment" && row3.data.postId === data.postId && !row3.data.replyTo)) throw new Error("같은 기록의 댓글에만 답글을 작성할 수 있습니다.");
          }
          if (existingId && (!old || old.author_id !== userId && kind !== "event" && !(old.kind === "post" && old.data.space === "board" && data.space === "board"))) throw new Error("작성자만 수정할 수 있습니다.");
          const updated = guardedUpdate ? new Date(Math.max(Date.now(), Date.parse(old.updated_at || old.created_at) + 1)).toISOString() : (/* @__PURE__ */ new Date()).toISOString();
          const row2 = { id: existingId || crypto.randomUUID(), kind, author_id: old?.author_id || userId, data, created_at: old?.created_at || (/* @__PURE__ */ new Date()).toISOString(), updated_at: updated };
          if (guardedUpdate) {
            if (!await local.putIfVersion(row2, expectedVersion)) throw new Error(conflict);
          } else await local.put(row2);
          return row2;
        }
        const row = existingId ? { data } : { kind, data, author_id: userId, parent_id: kind === "comment" ? data.postId : null };
        const filter = existingId ? `records?id=eq.${encodeURIComponent(existingId)}${guardedUpdate ? `&updated_at=eq.${encodeURIComponent(expectedVersion)}` : ""}` : "records";
        const rows = await rest(filter, { method: existingId ? "PATCH" : "POST", body: JSON.stringify(row) });
        if (!rows?.length) {
          if (guardedUpdate) {
            const visible = await rest(`records?id=eq.${encodeURIComponent(existingId)}&select=updated_at&limit=1`);
            if (visible[0]?.updated_at === expectedVersion) throw new Error("이 게시글을 수정할 권한이 없어요. 공유 공간 설정을 확인해 주세요.");
            throw new Error(conflict);
          }
          throw new Error("작성자만 수정할 수 있습니다.");
        }
        return rows[0];
      },
      async remove(mode, userId, row) {
        if (row.author_id !== userId && row.kind !== "event") throw new Error("작성자만 삭제할 수 있습니다.");
        if (mode === "demo") {
          await local.remove(row.id);
          for (const r of await local.list()) if (r.kind === "comment" && r.data.postId === row.id) await local.remove(r.id);
        } else {
          const rows = await rest(`records?id=eq.${encodeURIComponent(row.id)}`, { method: "DELETE" });
          if (!rows?.length) throw new Error("삭제할 수 없는 기록입니다.");
        }
      },
      async readAt() {
        return rest("message_reads?select=*");
      },
      async markRead(userId) {
        return rest("message_reads?on_conflict=user_id", { method: "POST", headers: { Prefer: "resolution=merge-duplicates,return=representation" }, body: JSON.stringify({ user_id: userId, last_read_at: (/* @__PURE__ */ new Date()).toISOString() }) });
      },
      async subscribe(userId, subscription) {
        return rest("push_subscriptions?on_conflict=endpoint", { method: "POST", headers: { Prefer: "resolution=merge-duplicates,return=representation" }, body: JSON.stringify({ user_id: userId, endpoint: subscription.endpoint, subscription }) });
      },
      async unsubscribe(endpoint) {
        return rest(`push_subscriptions?endpoint=eq.${encodeURIComponent(endpoint)}`, { method: "DELETE" });
      },
      async notify(recordId) {
        if (!config.vapidPublicKey) return;
        const response = await fetch(`${config.supabaseUrl}/functions/v1/notify`, { method: "POST", headers: { apikey: config.supabaseAnonKey, Authorization: `Bearer ${await accessToken()}`, "Content-Type": "application/json" }, body: JSON.stringify({ recordId }) });
        if (!response.ok) throw new Error("알림 서버에서 전송을 완료하지 못했습니다.");
      }
    };
  }
});

// src/google.js
function script(src) {
  if (!scripts.has(src)) scripts.set(src, new Promise((resolve2, reject) => {
    const el = document.createElement("script");
    el.src = src;
    el.onload = resolve2;
    el.onerror = () => {
      scripts.delete(src);
      reject(new Error("Google 연결 스크립트를 불러오지 못했습니다."));
    };
    document.head.append(el);
  }));
  return scripts.get(src);
}
async function access(force = false) {
  if (!force && token && expires > Date.now()) return token;
  if (!tokenProvider) throw new Error("설정에서 Google을 연결해 주세요.");
  if (!refreshPending2) {
    const current = generation;
    refreshPending2 = Promise.resolve().then(() => tokenProvider(force)).then((result) => {
      if (current !== generation) throw new Error("Google 연결이 종료되었습니다.");
      if (!result.access_token || !(Number(result.expires_in) > 0)) throw new Error("Google을 다시 연결해 주세요.");
      token = result.access_token;
      expires = Date.now() + Math.max(0, Number(result.expires_in) - 30) * 1e3;
      return token;
    }).finally(() => {
      refreshPending2 = void 0;
    });
  }
  return refreshPending2;
}
async function authorizedFetch(url, options = {}) {
  let response = await fetch(url, { ...options, headers: { ...options.headers, Authorization: `Bearer ${await access()}` } });
  if (response.status === 401) {
    token = "";
    expires = 0;
    if (tokenProvider) response = await fetch(url, { ...options, headers: { ...options.headers, Authorization: `Bearer ${await access(true)}` } });
    if (response.status === 401) {
      token = "";
      expires = 0;
    }
  }
  return response;
}
async function api(url, options = {}) {
  const response = await authorizedFetch(url, options);
  if (!response.ok) {
    const data = await response.json().catch(() => ({}));
    if (response.status === 401) {
      token = "";
      expires = 0;
    }
    throw new Error(data.error?.message || `Google 요청 실패 (${response.status})`);
  }
  return response.status === 204 ? null : response.json();
}
var config2, token, expires, tokenProvider, refreshPending2, generation, uploads, scripts, eventPath, google;
var init_google = __esm({
  "src/google.js"() {
    init_core();
    init_platform();
    config2 = window.APP_CONFIG;
    token = "";
    expires = 0;
    generation = 0;
    uploads = /* @__PURE__ */ new Map();
    scripts = /* @__PURE__ */ new Map();
    eventPath = () => {
      if (!config2.calendarId) throw new Error("config.js에 공유 캘린더 ID를 입력해 주세요.");
      return `https://www.googleapis.com/calendar/v3/calendars/${encodeURIComponent(config2.calendarId)}/events`;
    };
    google = {
      setTokenProvider(provider) {
        tokenProvider = provider;
      },
      async birthday() {
        let person;
        try {
          person = await api("https://people.googleapis.com/v1/people/me?personFields=birthdays&sources=READ_SOURCE_TYPE_PROFILE");
        } catch (error) {
          throw new Error(`Google 생일을 가져오지 못했어요. 설정에서 Google을 다시 연결하고 생일 권한을 허용해 주세요. (${error.message})`);
        }
        const entries = person.birthdays || [];
        const date = (entries.find((item) => item.metadata?.primary && item.date) || entries.find((item) => item.date))?.date;
        if (!date?.year || !date.month || !date.day) throw new Error("Google 계정에서 연도까지 포함된 생일을 찾지 못했어요. Google 계정의 생일을 확인해 주세요.");
        const value = `${String(date.year).padStart(4, "0")}-${String(date.month).padStart(2, "0")}-${String(date.day).padStart(2, "0")}`;
        const parsed = /* @__PURE__ */ new Date(`${value}T12:00:00Z`);
        if (!/^\d{4}-\d{2}-\d{2}$/.test(value) || !Number.isFinite(parsed.getTime()) || parsed.toISOString().slice(0, 10) !== value) throw new Error("Google 계정의 생일이 올바르지 않아요.");
        return value;
      },
      async restore() {
        await access();
        return true;
      },
      get connected() {
        return Boolean(token && (expires > Date.now() || tokenProvider));
      },
      async prepare() {
        if (!native.active && config2.googleClientId) await script("https://accounts.google.com/gsi/client");
      },
      async acceptNativeToken(value, email) {
        const response = await fetch("https://openidconnect.googleapis.com/v1/userinfo", { headers: { Authorization: `Bearer ${value}` } });
        const identity = await response.json();
        if (!response.ok || !identity.email_verified || identity.email?.toLowerCase() !== email.toLowerCase()) throw new Error("Google 계정 확인에 실패했습니다. 다시 연결해 주세요.");
        token = value;
        expires = Date.now() + 50 * 60 * 1e3;
      },
      async connect(email) {
        if (!config2.googleClientId) throw new Error("config.js에 Google OAuth 클라이언트 ID를 입력해 주세요.");
        if (!window.google?.accounts) throw new Error("Google 연결을 준비 중입니다. 잠시 후 다시 눌러 주세요.");
        return new Promise((resolve2, reject) => {
          const client = window.google.accounts.oauth2.initTokenClient({
            client_id: config2.googleClientId,
            scope: "openid email https://www.googleapis.com/auth/calendar.events https://www.googleapis.com/auth/drive.file https://www.googleapis.com/auth/drive.readonly",
            hint: email,
            callback: async (result) => {
              if (result.error) return reject(new Error("Google 접근 동의를 완료하지 못했습니다."));
              if (!window.google.accounts.oauth2.hasGrantedAllScopes(result, "https://www.googleapis.com/auth/calendar.events", "https://www.googleapis.com/auth/drive.file", "https://www.googleapis.com/auth/drive.readonly")) return reject(new Error("캘린더와 Drive 접근에 모두 동의해 주세요."));
              try {
                const response = await fetch("https://openidconnect.googleapis.com/v1/userinfo", { headers: { Authorization: `Bearer ${result.access_token}` } });
                const identity = await response.json();
                if (!response.ok || identity.email?.toLowerCase() !== email.toLowerCase() || !identity.email_verified) throw new Error("앱에 로그인한 것과 같은 Google 계정을 선택해 주세요.");
                token = result.access_token;
                expires = Date.now() + (Number(result.expires_in) - 30) * 1e3;
                resolve2();
              } catch (error) {
                reject(error);
              }
            },
            error_callback: () => reject(new Error("Google 연결 창이 닫혔습니다. 다시 시도해 주세요."))
          });
          client.requestAccessToken({ prompt: "select_account" });
        });
      },
      disconnect() {
        generation++;
        token = "";
        expires = 0;
        uploads.clear();
      },
      async events(year, month) {
        const min = new Date(year, month, -7);
        const max = new Date(year, month + 1, 14);
        const params = new URLSearchParams({ timeMin: min.toISOString(), timeMax: max.toISOString(), singleEvents: "true", orderBy: "startTime", maxResults: "250" });
        const all = [];
        let next;
        do {
          if (next) params.set("pageToken", next);
          const result = await api(`${eventPath()}?${params}`);
          all.push(...(result.items || []).map(googleEvent).filter(Boolean));
          next = result.nextPageToken;
        } while (next);
        return all;
      },
      async upcomingEvents(today2 = dateKey()) {
        const min = /* @__PURE__ */ new Date(`${today2}T00:00:00`);
        const params = new URLSearchParams({ timeMin: min.toISOString(), singleEvents: "true", orderBy: "startTime", maxResults: "250" });
        const all = [];
        let next;
        do {
          if (next) params.set("pageToken", next);
          const result = await api(`${eventPath()}?${params}`);
          all.push(...(result.items || []).map(googleEvent).filter((row) => row && row.data.date >= today2));
          next = result.nextPageToken;
        } while (next && all.length < 3);
        return all.slice(0, 3);
      },
      async event(id) {
        return googleEvent(await api(`${eventPath()}/${encodeURIComponent(id)}`));
      },
      async saveEvent(data, id) {
        let start2, end;
        if (data.time) {
          const begin = /* @__PURE__ */ new Date(`${data.date}T${data.time}:00`);
          const finish = data.endDate && data.endTime ? /* @__PURE__ */ new Date(`${data.endDate}T${data.endTime}:00`) : new Date(begin.getTime() + 36e5);
          if (finish <= begin) throw new Error("종료 시간은 시작 시간보다 뒤여야 합니다.");
          start2 = { dateTime: begin.toISOString() };
          end = { dateTime: finish.toISOString() };
        } else {
          start2 = { date: data.date };
          end = { date: data.endDate ? nextDay(data.endDate) : nextDay(data.date) };
          if (end.date <= data.date) throw new Error("종료 날짜를 확인해 주세요.");
        }
        return api(`${eventPath()}${id ? `/${encodeURIComponent(id)}` : ""}`, { method: id ? "PATCH" : "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ summary: data.title, description: data.text || "", start: start2, end, extendedProperties: { shared: { geonjukongTarget: data.target || "shared" } } }) });
      },
      async deleteEvent(id) {
        await api(`${eventPath()}/${encodeURIComponent(id)}`, { method: "DELETE" });
      },
      async pickFolder() {
        await access();
        if (!config2.googleApiKey || !config2.googleProjectNumber) throw new Error("Google Picker용 API 키와 프로젝트 번호를 config.js에 입력해 주세요.");
        await script("https://apis.google.com/js/api.js");
        await new Promise((resolve2, reject) => window.gapi.load("picker", { callback: resolve2, onerror: () => reject(new Error("폴더 선택기를 불러오지 못했습니다.")) }));
        return new Promise((resolve2, reject) => {
          const pickerApi = window.google.picker;
          const view = new pickerApi.DocsView(pickerApi.ViewId.FOLDERS).setIncludeFolders(true).setSelectFolderEnabled(true);
          new pickerApi.PickerBuilder().addView(view).setOAuthToken(token).setDeveloperKey(config2.googleApiKey).setAppId(config2.googleProjectNumber).setOrigin(location.origin).setCallback((result) => {
            if (result.action === pickerApi.Action.PICKED) resolve2(result.docs[0]);
            if (result.action === pickerApi.Action.CANCEL) reject(new Error("폴더 선택을 취소했습니다."));
          }).build().setVisible(true);
        });
      },
      async pickPhoto(id) {
        await access();
        if (!config2.googleApiKey || !config2.googleProjectNumber) throw new Error("사진 선택을 위해 Google Picker API 키와 프로젝트 번호를 설정해 주세요.");
        await script("https://apis.google.com/js/api.js");
        await new Promise((resolve2, reject) => window.gapi.load("picker", { callback: resolve2, onerror: () => reject(new Error("사진 선택기를 불러오지 못했어요.")) }));
        return new Promise((resolve2, reject) => {
          const pickerApi = window.google.picker;
          const view = new pickerApi.DocsView(pickerApi.ViewId.DOCS).setFileIds(id);
          new pickerApi.PickerBuilder().addView(view).setOAuthToken(token).setDeveloperKey(config2.googleApiKey).setAppId(config2.googleProjectNumber).setOrigin(location.origin).setTitle("미리 볼 사진을 선택해 주세요").setCallback((result) => {
            if (result.action === pickerApi.Action.PICKED) {
              if (result.docs?.some((file) => file.id === id)) resolve2();
              else reject(new Error("해당 사진을 선택해 주세요."));
            }
            if (result.action === pickerApi.Action.CANCEL) reject(new Error("사진 선택을 취소했어요."));
          }).build().setVisible(true);
        });
      },
      async checkFolder() {
        if (!config2.driveFolderId) throw new Error("config.js에 공유 Drive 폴더 ID를 입력해 주세요.");
        const folder = await api(`https://www.googleapis.com/drive/v3/files/${encodeURIComponent(config2.driveFolderId)}?fields=id,name,mimeType,capabilities(canAddChildren)`);
        if (folder.mimeType !== "application/vnd.google-apps.folder" || !folder.capabilities?.canAddChildren) throw new Error("선택한 공유 폴더에 업로드 권한이 없습니다.");
        return folder;
      },
      async image(id, signal) {
        const response = await authorizedFetch(`https://www.googleapis.com/drive/v3/files/${encodeURIComponent(id)}?alt=media`, { signal });
        if (!response.ok) {
          if (response.status === 401) {
            token = "";
            expires = 0;
          }
          const error = new Error("Drive 사진을 불러오지 못했어요. Google 연결과 파일 권한을 확인해 주세요.");
          error.status = response.status;
          if (response.status === 403) {
            const details = await response.json().catch(() => ({}));
            if (details.error?.errors?.some((item) => ["rateLimitExceeded", "userRateLimitExceeded", "dailyLimitExceeded"].includes(item.reason))) error.code = "rate_limit";
          }
          throw error;
        }
        const blob = await response.blob();
        if (!/^image\/(jpeg|png|webp|gif|heic|heif|avif)$/i.test(blob.type) || !blob.size) {
          const error = new Error("미리볼 수 있는 사진이 아니에요. 원본 열기를 이용해 주세요.");
          error.code = "invalid_image";
          throw error;
        }
        return blob;
      },
      async video(id, signal) {
        const response = await authorizedFetch(`https://www.googleapis.com/drive/v3/files/${encodeURIComponent(id)}?alt=media`, { signal });
        if (!response.ok) {
          const error = new Error("영상을 불러오지 못했어요. Google 연결과 Drive 공유 권한을 확인해 주세요.");
          error.status = response.status;
          throw error;
        }
        const blob = await response.blob();
        if (!/^video\/(mp4|quicktime|webm|3gpp|x-m4v)$/i.test(blob.type) || !blob.size) throw new Error("재생할 수 있는 영상이 아니에요. 원본 열기를 이용해 주세요.");
        return blob;
      },
      async upload(file, progress) {
        safeFileType(file);
        await access();
        if (!config2.driveFolderId) throw new Error("공유 Drive 폴더를 먼저 설정해 주세요.");
        const key = `${file.name}:${file.size}:${file.lastModified}`;
        let upload = uploads.get(key);
        if (!upload) {
          const response = await fetch("https://www.googleapis.com/upload/drive/v3/files?uploadType=resumable&fields=id,name,mimeType,size,webViewLink", { method: "POST", headers: { Authorization: `Bearer ${await access()}`, "Content-Type": "application/json", "X-Upload-Content-Type": file.type, "X-Upload-Content-Length": String(file.size) }, body: JSON.stringify({ name: file.name, parents: [config2.driveFolderId] }) });
          if (!response.ok) {
            const err = await response.json().catch(() => ({}));
            throw new Error(err.error?.message || "Drive 업로드를 시작하지 못했습니다.");
          }
          const url = response.headers.get("Location");
          if (!url) throw new Error("업로드 세션을 받지 못했습니다.");
          upload = { url, offset: 0 };
          uploads.set(key, upload);
        } else {
          const status = await fetch(upload.url, { method: "PUT", headers: { Authorization: `Bearer ${await access()}`, "Content-Range": `bytes */${file.size}` } });
          if (status.ok) {
            uploads.delete(key);
            const result = await status.json();
            return { ...result, source: "drive", type: file.type, size: file.size };
          }
          if (status.status !== 308) {
            uploads.delete(key);
            throw new Error("업로드 세션이 만료되었습니다. 다시 저장해 주세요.");
          }
          upload.offset = Number(status.headers.get("Range")?.split("-")[1] ?? -1) + 1;
        }
        while (upload.offset < file.size) {
          const end = Math.min(upload.offset + 4 * 1024 * 1024, file.size);
          const response = await fetch(upload.url, { method: "PUT", headers: { Authorization: `Bearer ${await access()}`, "Content-Type": file.type, "Content-Range": `bytes ${upload.offset}-${end - 1}/${file.size}` }, body: file.slice(upload.offset, end) });
          if (response.status === 308) {
            upload.offset = Number(response.headers.get("Range")?.split("-")[1] ?? end - 1) + 1;
            progress(Math.round(upload.offset / file.size * 100));
            continue;
          }
          if (!response.ok) throw new Error("업로드가 중단되었습니다. 화면을 유지한 채 다시 저장하면 이어서 전송합니다.");
          const result = await response.json();
          uploads.delete(key);
          progress(100);
          return { ...result, source: "drive", type: file.type, size: file.size };
        }
        throw new Error("업로드 완료를 확인하지 못했습니다. 다시 저장해 주세요.");
      },
      async openFile(id) {
        const url = `https://drive.google.com/file/d/${encodeURIComponent(id)}/view`;
        if (native.active) await native.open(url);
        else window.open(url, "_blank", "noopener,noreferrer");
      }
    };
  }
});

// src/editor-media.js
function selectedMediaFile(file) {
  const type = file.type === "image/jpg" ? "image/jpeg" : file.type || types[file.name.split(".").pop().toLowerCase()];
  const selected = type && type !== file.type ? new File([file], file.name, { type, lastModified: file.lastModified }) : file;
  safeFileType(selected);
  return selected;
}
function existingPreview(original) {
  if (original.type.startsWith("video/")) return `<div class="video-preview"><video controls playsinline preload="metadata" ${original.source === "local" ? "data-file" : "data-drive-video"}="${escapeHtml(original.id)}" aria-label="${escapeHtml(original.name)}"></video>${original.source === "drive" ? `<button type="button" class="secondary video-load" data-action="video-load" data-id="${escapeHtml(original.id)}">영상 불러와 재생</button>` : ""}<span class="video-status" role="status"></span></div>`;
  const file = previewFile(original);
  if (file.source === "local") return `<img data-file="${escapeHtml(file.id)}" alt="${escapeHtml(original.name)}">`;
  return `<div class="photo-preview"><div class="file-cover"><span data-preview-status>사진을 불러오는 중…</span><small>${escapeHtml(original.name)}</small></div><img data-drive-file="${escapeHtml(file.id)}"${file.id !== original.id ? ` data-drive-original="${escapeHtml(original.id)}"` : ""} alt="${escapeHtml(original.name)}" hidden></div>`;
}
function createMediaDraft(existingFiles = []) {
  let items = existingFiles.map((metadata) => ({ key: `saved:${metadata.source}:${metadata.id}`, metadata }));
  const inRange = (index) => Number.isInteger(index) && index >= 0 && index < items.length;
  return {
    entries() {
      return items.map((item) => ({ ...item }));
    },
    restore(entries) {
      for (const item of items) if (item.url) URL.revokeObjectURL(item.url);
      items = entries.map((item) => item.file ? { ...item, url: URL.createObjectURL(item.file) } : { ...item });
    },
    addFiles(files) {
      const selected = Array.from(files, selectedMediaFile);
      let added = 0;
      for (const file of selected) {
        const key = `selected:${file.name}:${file.size}:${file.lastModified}:${file.type}`;
        if (items.some((item) => item.key === key)) continue;
        items.push({ key, file, url: URL.createObjectURL(file) });
        added++;
      }
      return added;
    },
    remove(index) {
      if (!inRange(index)) return false;
      const [item] = items.splice(index, 1);
      if (item.url) URL.revokeObjectURL(item.url);
      return true;
    },
    move(index, delta) {
      if (!inRange(index) || ![-1, 1].includes(delta) || !inRange(index + delta)) return false;
      [items[index], items[index + delta]] = [items[index + delta], items[index]];
      return true;
    },
    render() {
      if (!items.length) return '<p class="setting-hint">사진이나 동영상을 선택하면 순서대로 표시돼요.</p>';
      return `<ol class="media-draft-list">${items.map((item, index) => {
        const file = item.file || item.metadata;
        const preview = item.file ? file.type.startsWith("video/") ? `<video src="${escapeHtml(item.url)}" controls playsinline preload="metadata" aria-label="${escapeHtml(file.name)}"></video>` : `<img src="${escapeHtml(item.url)}" alt="${escapeHtml(file.name)}">` : existingPreview(file);
        return `<li class="media-draft-item"><span class="media-order" aria-label="${index + 1}번째 첨부">${index + 1}</span><div class="media-draft-preview">${preview}</div><span class="media-draft-name" title="${escapeHtml(file.name)}">${escapeHtml(file.name)}</span><div class="media-draft-tools"><button type="button" class="text-button" data-action="media-earlier" data-index="${index}" aria-label="${index + 1}번째 첨부 앞으로 이동"${index === 0 ? " disabled" : ""}>앞으로</button><button type="button" class="text-button" data-action="media-later" data-index="${index}" aria-label="${index + 1}번째 첨부 뒤로 이동"${index === items.length - 1 ? " disabled" : ""}>뒤로</button><button type="button" class="text-button danger" data-action="media-remove" data-index="${index}" aria-label="${index + 1}번째 첨부 삭제">삭제</button></div></li>`;
      }).join("")}</ol><p class="setting-hint">번호 순서로 올라가요. 앞으로·뒤로 버튼으로 순서를 바꾸거나 삭제 후 다시 추가할 수 있어요.</p>`;
    },
    dispose() {
      for (const item of items) if (item.url) URL.revokeObjectURL(item.url);
      items = [];
    }
  };
}
var types;
var init_editor_media = __esm({
  "src/editor-media.js"() {
    init_core();
    init_media();
    types = { jpg: "image/jpeg", jpeg: "image/jpeg", png: "image/png", webp: "image/webp", gif: "image/gif", heic: "image/heic", heif: "image/heif", avif: "image/avif", mp4: "video/mp4", mov: "video/quicktime", webm: "video/webm", "3gp": "video/3gpp", m4v: "video/x-m4v" };
  }
});

// src/post-drafts.js
function readPostDraft(scope, storage = localStorage) {
  const key = draftKey(scope);
  if (completed.has(key)) return null;
  const value = JSON.parse(storage.getItem(key) || "null");
  return value && !value.completed ? value : null;
}
function createPostDraft(scope, { storage = localStorage, files = local, onStatus = () => {
} } = {}) {
  const key = draftKey(scope);
  const selected = /* @__PURE__ */ new Map();
  let last = readPostDraft(scope, storage), stopped = false, textSaved = true;
  const writing = /* @__PURE__ */ new Set(), failures = /* @__PURE__ */ new Set();
  const status = () => {
    const ids = (last?.attachments || []).map((item) => item.fileId);
    const message = !textSaved ? "기기 초안을 저장하지 못했어요. 입력은 이 창에 남아 있어요. 닫기 전에 내용을 복사해 주세요." : ids.some((id) => failures.has(id)) ? "텍스트 초안은 기기에 저장됐지만 신규 첨부를 저장하지 못했어요. 첨부를 다시 선택해야 할 수 있어요." : ids.some((id) => writing.has(id)) ? "텍스트 초안은 기기에 저장됐어요. 신규 첨부 저장 중에는 페이지 종료 시 파일이 복원되지 않을 수 있어요." : "이 기기에 초안을 저장했어요. 같은 계정과 모드에서 이어 쓸 수 있어요.";
    onStatus(message);
    return message;
  };
  const removeFiles = (ids) => Promise.all(ids.map(async (id) => {
    try {
      await pendingFiles.get(id);
    } catch {
    }
    await files.removeFile(id);
    pendingFiles.delete(id);
  }));
  return {
    get saved() {
      return last;
    },
    capture(fields, entries, version = "", uploads2 = /* @__PURE__ */ new Map()) {
      if (stopped) return;
      const previous = last;
      const attachments = entries.map((entry) => {
        if (entry.metadata || uploads2.has(entry.key)) return { key: entry.key, metadata: entry.metadata || uploads2.get(entry.key) };
        let item = selected.get(entry.key);
        if (!item) {
          const file = entry.file;
          item = { key: entry.key, fileId: `post-draft:${crypto.randomUUID()}`, name: file.name, type: file.type, lastModified: file.lastModified };
          selected.set(entry.key, item);
        }
        if (!pendingFiles.has(item.fileId)) {
          writing.add(item.fileId);
          const job = files.putFile(item.fileId, entry.file);
          pendingFiles.set(item.fileId, job);
          job.then(() => {
          }, () => {
            failures.add(item.fileId);
            selected.delete(entry.key);
          }).finally(() => {
            writing.delete(item.fileId);
            if (!stopped) status();
          });
        }
        return item;
      });
      const value = { fields, attachments, version, updatedAt: (/* @__PURE__ */ new Date()).toISOString() };
      try {
        storage.setItem(key, JSON.stringify(value));
        completed.delete(key);
        last = value;
        textSaved = true;
        const retained = new Set(attachments.map((item) => item.fileId));
        const unused = (previous?.attachments || []).filter((item) => item.fileId && !retained.has(item.fileId)).map((item) => item.fileId);
        for (const [entryKey, item] of selected) if (!retained.has(item.fileId)) selected.delete(entryKey);
        void removeFiles(unused).catch(() => {
        });
      } catch {
        textSaved = false;
      }
      return status();
    },
    async restore() {
      const value = last;
      const entries = [], missing = [];
      for (const item of value?.attachments || []) {
        if (item.metadata) {
          entries.push(item);
          continue;
        }
        try {
          await pendingFiles.get(item.fileId);
          const stored = await files.file(item.fileId);
          if (!stored?.blob) throw new Error("Missing draft file");
          const file = new File([stored.blob], item.name, { type: item.type, lastModified: item.lastModified });
          entries.push({ key: item.key, file });
          selected.set(item.key, item);
        } catch {
          missing.push(item.name);
        }
      }
      return { ...value, entries, missing };
    },
    async discard(saved = false) {
      stopped = true;
      const ids = new Set([...(last?.attachments || []).map((item) => item.fileId), ...[...selected.values()].map((item) => item.fileId)].filter(Boolean));
      try {
        storage.removeItem(key);
      } catch {
        if (!saved) {
          stopped = false;
          throw new Error("초안을 삭제하지 못했어요. 기기 저장 공간 설정을 확인해 주세요.");
        }
        try {
          storage.setItem(key, JSON.stringify({ completed: true }));
        } catch {
          completed.add(key);
          throw new Error("일기는 저장됐지만 기기 초안 정리에 실패했어요. 페이지를 다시 열면 예전 초안이 보일 수 있으니 삭제해 주세요.");
        }
      }
      completed.delete(key);
      last = null;
      try {
        await removeFiles([...ids]);
      } catch {
        throw new Error(saved ? "일기는 저장됐고 초안 안내도 정리됐지만 기기의 임시 첨부 정리에 실패했어요." : "초안은 삭제됐지만 기기의 임시 첨부 정리에 실패했어요.");
      }
    },
    status
  };
}
var prefix, pendingFiles, completed, draftKey;
var init_post_drafts = __esm({
  "src/post-drafts.js"() {
    init_storage();
    prefix = "geonjukong-post-draft-v1:";
    pendingFiles = /* @__PURE__ */ new Map();
    completed = /* @__PURE__ */ new Set();
    draftKey = ({ mode, user, target = "" }) => prefix + JSON.stringify([mode, user, target]);
  }
});

// src/dialog-behavior.js
function lockPage() {
  if (lockedAt !== null || !document.body?.style) return;
  lockedAt = { y: window.scrollY || 0, position: document.body.style.position, top: document.body.style.top, width: document.body.style.width };
  document.body.style.position = "fixed";
  document.body.style.top = `-${lockedAt.y}px`;
  document.body.style.width = "100%";
  document.documentElement?.classList.add("modal-open");
}
function unlockPage() {
  if (lockedAt === null) return;
  const saved = lockedAt;
  lockedAt = null;
  Object.assign(document.body.style, { position: saved.position, top: saved.top, width: saved.width });
  document.documentElement?.classList.remove("modal-open");
  window.scrollTo({ top: saved.y, behavior: "instant" });
}
function focusReplyInput(editor, input) {
  const viewport = window.visualViewport;
  const form = input.form || null;
  const comment = input.closest?.(".comment") || null;
  let frame = null, showComment = false;
  const updateViewport = () => {
    editor.style.setProperty("--reply-viewport-top", `${viewport?.offsetTop || 0}px`);
    editor.style.setProperty("--reply-viewport-height", `${viewport?.height || window.innerHeight}px`);
  };
  const keepVisible = () => {
    frame = null;
    const withComment = showComment;
    showComment = false;
    if (!editor.open || document.activeElement !== input) return;
    const viewportTop = viewport?.offsetTop || 0;
    const viewportBottom = viewportTop + (viewport?.height || window.innerHeight);
    const bounds = editor.getBoundingClientRect();
    const rect = input.getBoundingClientRect();
    const top = Math.max(viewportTop, bounds.top + editor.clientTop) + 12;
    const bottom = Math.min(viewportBottom, bounds.top + editor.clientTop + editor.clientHeight) - 12;
    if (bottom <= top) return;
    const end = Math.max(rect.bottom, form?.getBoundingClientRect().bottom ?? rect.bottom);
    const start2 = withComment && comment ? Math.min(rect.top, comment.getBoundingClientRect().top) : rect.top;
    let delta = 0;
    if (end - start2 <= bottom - top) delta = start2 < top ? start2 - top : end > bottom ? end - bottom : 0;
    else if (end - rect.top <= bottom - top) delta = rect.top < top || end > bottom ? end - bottom : 0;
    else if (rect.top < top || rect.height > bottom - top) delta = rect.top - top;
    else if (rect.bottom > bottom) delta = rect.bottom - bottom;
    if (delta) editor.scrollTop += delta;
  };
  const schedule = (event) => {
    updateViewport();
    if (event?.type !== "input") showComment = true;
    if (frame === null) frame = window.requestAnimationFrame(keepVisible);
  };
  editor.classList.add("reply-composing");
  updateViewport();
  input.focus({ preventScroll: true });
  schedule();
  input.addEventListener("focus", schedule);
  input.addEventListener("input", schedule);
  viewport?.addEventListener("resize", schedule);
  viewport?.addEventListener("scroll", schedule);
  window.addEventListener("resize", schedule);
  return () => {
    if (frame !== null) window.cancelAnimationFrame(frame);
    input.removeEventListener("focus", schedule);
    input.removeEventListener("input", schedule);
    viewport?.removeEventListener("resize", schedule);
    viewport?.removeEventListener("scroll", schedule);
    window.removeEventListener("resize", schedule);
    editor.classList.remove("reply-composing");
    editor.style.removeProperty("--reply-viewport-top");
    editor.style.removeProperty("--reply-viewport-height");
  };
}
function installDialogDismissal(editor, back) {
  let startedOutside = false;
  const outside = (event) => {
    if (event.target !== editor) return false;
    const rect = editor.getBoundingClientRect();
    return event.clientX < rect.left || event.clientX > rect.right || event.clientY < rect.top || event.clientY > rect.bottom;
  };
  editor.addEventListener("pointerdown", (event) => {
    startedOutside = outside(event);
  });
  editor.addEventListener("click", (event) => {
    if (startedOutside && outside(event)) {
      event.preventDefault();
      back();
    }
    startedOutside = false;
  });
  editor.addEventListener("cancel", (event) => {
    event.preventDefault();
    back();
  });
  editor.addEventListener("close", () => {
    if (!editor.open) unlockPage();
  });
}
var lockedAt;
var init_dialog_behavior = __esm({
  "src/dialog-behavior.js"() {
    lockedAt = null;
  }
});

// src/gallery.js
function installGalleryDrag(root = document) {
  let drag = null, suppressClick = false;
  root.addEventListener("pointerdown", (event) => {
    if (event.pointerType !== "mouse" || event.button !== 0 || event.target.closest('video, .attachment-navigation, .memory-arrow, [data-action="open-file"]')) return;
    const track = event.target.closest(".attachments, .memory-slides");
    if (!track || track.scrollWidth <= track.clientWidth) return;
    drag = { track, x: event.clientX, left: track.scrollLeft, moved: false, snap: track.style.scrollSnapType };
    suppressClick = false;
  });
  root.addEventListener("pointermove", (event) => {
    if (!drag) return;
    const distance = event.clientX - drag.x;
    if (!drag.moved && Math.abs(distance) < 6) return;
    drag.moved = true;
    drag.track.style.scrollSnapType = "none";
    drag.track.scrollLeft = drag.left - distance;
    event.preventDefault();
  }, { passive: false });
  const finish = () => {
    if (!drag) return;
    const { track, moved, snap } = drag;
    track.style.scrollSnapType = snap;
    if (moved) {
      suppressClick = true;
      track.scrollTo({ left: Math.round(track.scrollLeft / track.clientWidth) * track.clientWidth, behavior: "smooth" });
      setTimeout(() => {
        suppressClick = false;
      }, 0);
    }
    drag = null;
  };
  root.addEventListener("pointerup", finish);
  root.addEventListener("pointercancel", finish);
  root.addEventListener("dragstart", (event) => {
    if (event.target.closest(".attachments, .memory-slides")) event.preventDefault();
  });
  root.addEventListener("click", (event) => {
    if (suppressClick) {
      suppressClick = false;
      event.preventDefault();
      event.stopImmediatePropagation();
    }
  }, true);
}
var init_gallery = __esm({
  "src/gallery.js"() {
  }
});

// src/drive-video.js
function createDriveVideoPlayer(google2) {
  const urls2 = /* @__PURE__ */ new Map(), jobs = /* @__PURE__ */ new Map();
  function clear() {
    for (const job of jobs.values()) job.controller.abort();
    jobs.clear();
    for (const url of urls2.values()) URL.revokeObjectURL(url);
    urls2.clear();
  }
  function prune(videos) {
    const visible = new Set([...videos].map((video) => video.dataset.driveVideo));
    for (const [id, url] of urls2) if (!visible.has(id)) {
      URL.revokeObjectURL(url);
      urls2.delete(id);
    }
    for (const [id, job] of jobs) if (!visible.has(id)) {
      job.controller.abort();
      jobs.delete(id);
    }
  }
  async function load2(video, autoplay = false) {
    const id = video.dataset.driveVideo;
    const wrapper = video.parentElement;
    const button = wrapper.querySelector(".video-load");
    const status = wrapper.querySelector(".video-status");
    if (button) button.disabled = true;
    if (status) status.textContent = "영상을 불러오는 중이에요…";
    try {
      if (!urls2.has(id)) {
        let job = jobs.get(id);
        if (!job) {
          job = { controller: new AbortController() };
          jobs.set(id, job);
          job.promise = google2.video(id, job.controller.signal).then((blob) => {
            if (jobs.get(id) !== job) throw new DOMException("영상 요청이 취소됐어요.", "AbortError");
            const url = URL.createObjectURL(blob);
            urls2.set(id, url);
            return url;
          }).finally(() => {
            if (jobs.get(id) === job) jobs.delete(id);
          });
        }
        await job.promise;
      }
      if (!video.isConnected) return;
      video.src = urls2.get(id);
      video.onerror = () => {
        if (status) status.textContent = "이 기기에서 재생할 수 없는 형식이에요. 원본 열기로 확인해 주세요.";
      };
      if (button) button.hidden = true;
      if (status) status.textContent = "";
      if (autoplay) {
        try {
          await video.play();
        } catch {
          if (status) status.textContent = "재생 버튼을 눌러 주세요.";
        }
      }
    } catch (error) {
      if (video.isConnected && error.name !== "AbortError") {
        if (status) status.textContent = error.message;
        if (button) {
          button.hidden = false;
          button.textContent = "영상 다시 불러오기";
        }
      }
    } finally {
      if (button) button.disabled = false;
    }
  }
  return { load: load2, clear, prune };
}
var init_drive_video = __esm({
  "src/drive-video.js"() {
  }
});

// src/app.js
var app_exports = {};
function syncNotificationBadge() {
  const hasUnread = state.mode === "live" && notices().some((r) => !noticeRead(r.id));
  badgeUpdate = badgeUpdate.then(() => native.setBadge(hasUnread)).catch(() => {
  });
}
function queueCalendarNotice(user, event, data) {
  const key = pendingKey(user), pending = JSON.parse(localStorage.getItem(key) || "[]");
  pending.push({ id: crypto.randomUUID(), eventId: event.id, title: data.title, date: data.date });
  localStorage.setItem(key, JSON.stringify(pending));
}
async function flushCalendarNotices(user) {
  if (pendingNotices.has(user)) return pendingNotices.get(user);
  const job = (async () => {
    const key = pendingKey(user);
    for (const notice of JSON.parse(localStorage.getItem(key) || "[]")) {
      await repository.saveCalendarNotice(user, notice);
      const remaining = JSON.parse(localStorage.getItem(key) || "[]").filter((item) => item.id !== notice.id);
      if (remaining.length) localStorage.setItem(key, JSON.stringify(remaining));
      else localStorage.removeItem(key);
    }
  })().finally(() => pendingNotices.delete(user));
  pendingNotices.set(user, job);
  return job;
}
async function updatePendingNotices(user) {
  try {
    await flushCalendarNotices(user);
    if (state.mode === "live" && state.user === user) state.noticeError = "";
  } catch {
    if (state.mode === "live" && state.user === user) state.noticeError = "일정은 저장됐지만 상대방에게 알림을 전달하지 못했어요. 연결을 확인하면 다시 시도해요.";
  }
}
function eventTargets() {
  return [{ value: "shared", label: "공용 일정", tone: "shared" }, ...[1, 2].map((slot) => {
    const member = state.members.find((item) => Number(item.slot) === slot);
    const profile = state.profiles.find((item) => item.email === member?.email);
    const id = state.mode === "demo" ? slot === 1 ? "demo-me" : "demo-partner" : profile?.user_id;
    const name = id ? nameOf(id) : member?.display_name || (slot === 1 ? "남자쪽" : "여자쪽");
    return { value: `member-${slot}`, label: `${name} 일정`, tone: slot === 1 ? "male" : "female" };
  })];
}
function eventTargetPicker(data) {
  const selected = eventTarget(data).value;
  return `<fieldset class="event-target-picker"><legend>누구의 일정인가요?</legend>${eventTargets().map((item) => `<label class="event-target-option"><input type="radio" name="target" value="${item.value}" ${selected === item.value ? "checked" : ""} required><span class="event-target-label event-tone-${item.tone}"><i aria-hidden="true"></i>${escapeHtml(item.label)}</span></label>`).join("")}</fieldset>`;
}
function postDraftPanel() {
  const diary = state.view === "memories";
  return `<aside class="post-draft-notice" aria-label="${diary ? "일기 기기 초안" : "기기 초안"}"><p id="post-draft-status" role="status" aria-live="polite">${diary ? "일기 내용" : "작성 내용"}은 이 계정의 기기 초안으로 자동 저장돼요. 브라우저 데이터를 지우면 삭제돼요.</p><div class="post-draft-actions"><button type="button" class="secondary" data-action="draft-restore" hidden>${diary ? "일기 이어 쓰기" : "이어서 쓰기"}</button><button type="button" class="text-button danger" data-action="draft-discard">${diary ? "일기 초안 삭제" : "초안 삭제"}</button></div></aside>`;
}
function capturePostDraft() {
  const session2 = postDraftSession;
  if (!session2 || session2.waiting || session2.scope.user !== state.user || session2.scope.mode !== state.mode) return;
  const form = session2.form;
  const values = Object.fromEntries(new FormData(form));
  session2.dirty = true;
  return session2.store.capture({ date: values.date, title: values.title, text: values.text }, editorDraft?.entries() || [], form.dataset.version, form.uploadedFiles);
}
function leavePostDraft() {
  if (!postDraftSession) return;
  if (postDraftSession.dirty) {
    const message = capturePostDraft();
    if (message && /못했|저장 중/.test(message)) toast(message);
  }
  postDraftSession = null;
}
function beginPostDraft(row) {
  const form = $("#record-form");
  if (!form) return;
  const scope = postDraftScope(row?.id);
  try {
    const session2 = { form, row, scope, dirty: false, waiting: false };
    session2.store = createPostDraft(scope, { onStatus: (message) => {
      if (postDraftSession === session2 && $("#post-draft-status")) $("#post-draft-status").textContent = message;
    } });
    postDraftSession = session2;
    if (session2.store.saved) {
      session2.waiting = true;
      form.hidden = true;
      $("#post-draft-status").textContent = "이 기기에 저장한 일기 초안이 있어요. 이어 쓰거나 삭제할 수 있어요.";
      $('[data-action="draft-restore"]').hidden = false;
    }
  } catch {
    $("#post-draft-status").textContent = "기기 초안을 읽거나 저장할 수 없어요. 닫기 전에 내용을 복사해 주세요.";
  }
}
async function restorePostDraft() {
  const session2 = postDraftSession;
  if (!session2?.waiting) return;
  const restored = await session2.store.restore();
  if (postDraftSession !== session2 || state.user !== session2.scope.user || state.mode !== session2.scope.mode) return;
  for (const name of ["date", "title", "text"]) session2.form.elements[name].value = restored.fields[name] || "";
  session2.form.dataset.version = restored.version || "";
  editorDraft?.dispose();
  editorDraft = createMediaDraft();
  editorDraft.restore(restored.entries);
  session2.waiting = false;
  session2.dirty = true;
  session2.form.hidden = false;
  $('[data-action="draft-restore"]').hidden = true;
  updateMediaDraft();
  $("#post-draft-status").textContent = restored.missing.length ? `텍스트와 보관된 첨부를 복원했어요. 저장되지 않은 파일을 다시 선택해 주세요: ${restored.missing.join(", ")}` : "날짜·제목·본문과 첨부를 복원했어요. 이어서 작성해 주세요.";
}
async function discardPostDraft() {
  const session2 = postDraftSession;
  if (!session2) return;
  try {
    await session2.store.discard();
  } finally {
    if (!session2.store.saved && postDraftSession === session2) {
      postDraftSession = null;
      openEditor("post", session2.row);
    }
  }
  render();
  toast("기기 초안을 삭제했어요.");
}
function postDraftReminder() {
  try {
    const drafts = [{ id: "", title: "새 일기" }, ...memoriesRows().filter(canEdit).map((row) => ({ id: row.id, title: postTitle(row) }))].filter((item) => readPostDraft(postDraftScope(item.id)));
    return drafts.length ? `<aside class="post-draft-notice" aria-label="저장한 기기 초안"><p>이 계정으로 이 기기에 저장한 일기 초안이 있어요.</p>${drafts.map((item) => `<button type="button" class="text-button" data-action="draft-open" data-id="${escapeHtml(item.id)}">${escapeHtml(item.title)} 이어 쓰기</button>`).join("")}</aside>` : "";
  } catch {
    return "";
  }
}
async function loadFeatures() {
  const mode = state.mode, user = state.user;
  const results = await Promise.allSettled([bucket.load(), profiles.load()]);
  if (state.mode !== mode || state.user !== user) return;
  state.featureErrors = results.filter((result) => result.status === "rejected").map((result) => result.reason.message);
}
function toast(message) {
  $("#toast").textContent = message;
  $("#toast").classList.add("visible");
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => $("#toast").classList.remove("visible"), 4200);
}
function report(error) {
  console.error(error.message);
  toast(error.message || "작업을 완료하지 못했습니다.");
}
function empty(title, text, action = "") {
  return `<div class="empty">${icon("heart")}<h3>${title}</h3><p>${text}</p>${action}</div>`;
}
function render() {
  today = dateKey();
  syncNotificationBadge();
  $("#app").innerHTML = `<aside class="sidebar"><a class="brand" href="#home" data-view="home" aria-label="GeonJuKong 홈">${icon("heart")}<span>GeonJuKong<small>JUST THE TWO OF US</small></span></a><div class="sidebar-caption">우리의 작은 공간</div><nav aria-label="주 메뉴">${Object.entries(navigation).map(([view, glyph]) => `<button class="nav-item ${state.view === view ? "active" : ""}" data-view="${view}" ${state.view === view ? 'aria-current="page"' : ""}>${icon(glyph)}<span>${labels[view]}</span></button>`).join("")}</nav><div class="sidebar-bottom"><div class="pair-avatars">${avatar(state.user)}${avatar(state.user === "demo-me" ? "demo-partner" : "other")}</div><strong>우리 둘이면 충분해</strong><span>작은 순간도 오래도록.</span><div class="tiny-flower">✳</div></div></aside>
  <main><header class="topbar home-topbar"><div class="topbar-right"><button class="icon-button notification-button" data-action="notice-list" aria-label="알림${notices().some((r) => !noticeRead(r.id)) ? ", 읽지 않은 알림 있음" : ", 모두 읽음"}">${icon("bell")}${notices().some((r) => !noticeRead(r.id)) ? '<i class="notification-dot"></i>' : ""}</button></div></header><div class="page ${state.view === "home" ? "home-page" : state.view === "calendar" ? "calendar-page" : ""}">${["home", "memories", "calendar"].includes(state.view) ? "" : demoBanner()}${state.error ? `<div class="error-banner" role="alert">${escapeHtml(state.error)} <button data-action="refresh">다시 시도</button></div>` : ""}${state.noticeError ? `<div class="error-banner" role="alert">${escapeHtml(state.noticeError)} <button data-action="refresh">다시 시도</button></div>` : ""}${state.mode === "live" && auth.googleWarning ? `<div class="error-banner" role="alert">${escapeHtml(auth.googleWarning)} <button data-view="settings">연결 설정</button></div>` : ""}${state.featureErrors?.length ? `<div class="error-banner" role="alert">버킷리스트 또는 프로필을 불러오지 못했어요. 연결 상태와 새 기능의 서버 설정을 확인해 주세요. <button data-action="refresh">다시 시도</button></div>` : ""}${views[state.view]()}</div><footer class="footer">GeonJuKong <span>소중한 건, 함께한 시간.</span><span class="footer-heart">♡</span></footer></main>`;
  hydrateMedia();
}
function pageTitle(eyebrow, title, description, action = "") {
  return `<div class="page-heading"><div><p class="eyebrow">${eyebrow}</p><h1>${title}</h1><p class="subtitle">${description}</p></div>${action}</div>`;
}
function eventRows(list) {
  return list.map((row) => `<div class="event-row event-tone-${eventTarget(row.data).tone}"><span class="event-time">${escapeHtml(row.data.time || "하루 종일")}</span><span class="event-line"></span><div><strong>${escapeHtml(postTitle(row))}</strong><p class="event-target-name">${escapeHtml(eventTarget(row.data).label)}</p>${row.data.text ? `<p>${escapeHtml(row.data.text)}</p>` : ""}</div>${row.data.automatic ? '<span class="tag">자동 기념일</span>' : `<button class="icon-button" data-action="edit-event" data-id="${escapeHtml(row.id)}" aria-label="${escapeHtml(postTitle(row))} 일정 보기">${icon("right")}</button>`}</div>`).join("");
}
function disposeHomePhotoDraft() {
  for (const item of homePhotoDraft) if (item.url) URL.revokeObjectURL(item.url);
  homePhotoDraft = [];
}
function resolveHomePhotos(selections, recentPosts = sortRecords(memoriesRows())) {
  return selections.map((selection) => {
    if (selection.file?.type?.startsWith("image/")) return { file: selection.file, selection };
    const row = recentPosts.find((item) => item.id === selection.recordId);
    const file = row?.data.files?.find((item) => item.id === selection.fileId && item.type.startsWith("image/"));
    return file ? { row, file, selection } : null;
  }).filter(Boolean);
}
function home() {
  const anniversary = coupleDaySummary(state.couple, today);
  const year = Number(today.slice(0, 4));
  const upcoming = [...state.mode === "demo" ? records("event") : state.upcomingEvents, ...coupleEvents(year, state.couple), ...coupleEvents(year + 1, state.couple)].filter((r) => r.data.date >= today).sort((a, b) => `${a.data.date}${a.data.time || ""}`.localeCompare(`${b.data.date}${b.data.time || ""}`)).slice(0, 1);
  const recentPosts = sortRecords(memoriesRows());
  const selectedPhotos = selectedHomePhotos(recentPosts);
  if (selectedPhotos.length && homePhotoIndex === null) homePhotoIndex = Math.floor(Math.random() * selectedPhotos.length);
  if (selectedPhotos.length) homePhotoIndex %= selectedPhotos.length;
  const selected = selectedPhotos[homePhotoIndex];
  const heroPhoto = selected ? homePhotoPreview(selected.file, true) : '<div class="museum-photo-empty"></div>';
  const next = upcoming[0];
  const daysUntil = next ? Math.round((Date.parse(`${next.data.date}T00:00:00Z`) - Date.parse(`${today}T00:00:00Z`)) / 864e5) : 0;
  return `<div class="museum-masthead"><div><h1>GeonJuKong<span>♡</span></h1><p>오늘도, 우리라는 하루</p></div></div>
  ${state.mode === "demo" ? demoBanner() : ""}${state.mode === "live" && state.upcomingError ? `<div class="error-banner" role="alert">다가오는 일정 읽기 실패: ${escapeHtml(state.upcomingError)} <button data-action="calendar-retry">다시 시도</button></div>` : ""}
  <section class="museum-photo" aria-label="우리의 사진">${heroPhoto}<div class="home-hero-copy"><p>Together for</p><strong>${anniversary.elapsed === null ? "—" : escapeHtml(anniversary.label)}</strong><span>지금처럼,<br>늘 함께</span></div><button type="button" class="home-photo-button" data-action="choose-home-photo">홈 사진 선택</button>${selectedPhotos.length > 1 ? `<div class="home-photo-navigation"><button type="button" class="memory-arrow" data-action="home-photo-prev" aria-label="이전 사진">${icon("left")}</button><span aria-live="polite">${homePhotoIndex + 1} / ${selectedPhotos.length}</span><button type="button" class="memory-arrow" data-action="home-photo-next" aria-label="다음 사진">${icon("right")}</button></div>` : ""}</section>
  <section class="home-section schedule-card"><div class="section-heading"><h2>NEXT EVENT</h2><button class="text-button" data-view="calendar">더보기 ${icon("right")}</button></div>${state.mode === "live" && !google.connected && !next ? empty("일정을 연결해 볼까요?", "설정에서 Google을 연결하면 공유 일정이 보여요.") : next ? `<div class="home-event event-tone-${eventTarget(next.data).tone}"><div class="home-event-date"><strong>${daysUntil === 0 ? "D-DAY" : `D-${daysUntil}`}</strong><span>${formatDate(next.data.date)}</span></div><span class="home-event-icon">${icon("calendar")}</span><div class="home-event-detail"><div><strong>${escapeHtml(postTitle(next))}</strong><span class="event-target-name">${escapeHtml(eventTarget(next.data).label)}</span><p>${escapeHtml(next.data.text || next.data.time || "함께하는 날")}</p></div>${next.data.automatic ? "" : `<button class="icon-button" data-action="edit-event" data-id="${escapeHtml(next.id)}" aria-label="${escapeHtml(postTitle(next))} 일정 보기">${icon("right")}</button>`}</div></div>` : empty("아직 정해진 약속이 없어요", "함께하고 싶은 하루를 남겨 보세요.", addButton("event", "약속 추가", "secondary"))}</section>
  <section class="home-section memories-section museum-memories"><div class="section-heading"><h2>RECENT MEMORY</h2><button class="text-button" data-view="memories">모두 보기 ${icon("right")}</button></div><div class="memory-grid">${recentPosts.length ? postCard(recentPosts[0]) : empty("첫 번째 추억을 기다려요", "사진과 짧은 이야기로 시작해 보세요.", addButton("post", "추억 남기기"))}</div></section>`;
}
function calendar() {
  const grid = monthGrid(state.year, state.month);
  const items = events();
  const holidays = [...new Set(grid.map((d) => Number(d.key.slice(0, 4))))].flatMap(koreaHolidays);
  const dayEvents = items.filter((r) => eventOnDate(r, state.day)).sort((a, b) => (a.data.time || "").localeCompare(b.data.time || ""));
  const dayPosts = records("post").filter((r) => r.data.date === state.day);
  const syncStatus = state.mode === "live" && state.calendarError ? `<div class="error-banner" role="alert">Google 캘린더 동기화 실패: ${escapeHtml(state.calendarError)} <button data-action="calendar-retry">다시 시도</button> <button data-view="settings">연결 설정</button></div>` : "";
  return `${syncStatus}${pageTitle("OUR SHARED DAYS", "함께 채우는 달력", "약속도, 마음도. 같은 날짜에 나란히.", addButton("event", "약속 추가"))}<div class="calendar-layout"><section class="card calendar-card"><div class="month-heading"><h2>${state.year}년 <strong>${state.month + 1}월</strong></h2><div><button class="text-button" data-action="today">오늘</button><button class="icon-button" data-action="month" data-offset="-1" aria-label="이전 달">${icon("left")}</button><button class="icon-button" data-action="month" data-offset="1" aria-label="다음 달">${icon("right")}</button></div></div><div class="calendar-week">${["일", "월", "화", "수", "목", "금", "토"].map((d) => `<span>${d}</span>`).join("")}</div><div class="calendar-grid">${grid.map((d) => {
    const ev = items.filter((r) => eventOnDate(r, d.key));
    const holiday = holidays.filter((h) => h.date === d.key).map((h) => h.title).join(", ");
    const red = (/* @__PURE__ */ new Date(`${d.key}T12:00:00`)).getDay() === 0 || holiday;
    const photo = sortRecords(memoriesRows().filter((r) => r.data.date === d.key)).flatMap((r) => r.data.files || []).find((f2) => f2.type.startsWith("image/") || f2.thumbnail?.type.startsWith("image/"));
    const thumb = photo && previewFile(photo);
    return `<button class="calendar-day ${red ? "holiday" : ""} ${d.current ? "" : "outside"} ${d.key === state.day ? "selected" : ""} ${d.key === today ? "today" : ""}" data-action="day" data-date="${d.key}" title="${escapeHtml(holiday)}" aria-label="${formatDate(d.key)} ${escapeHtml(holiday)} 일정 ${ev.length}개" aria-pressed="${d.key === state.day}"><span>${d.day}</span><div class="day-markers">${holiday ? `<small class="holiday-name">${escapeHtml(holiday)}</small>` : ""}${ev.slice(0, 2).map((r) => `<small class="event-marker event-tone-${eventTarget(r.data).tone}" title="${escapeHtml(eventTarget(r.data).label)}">${escapeHtml(r.data.title)}</small>`).join("")}${ev.length > 2 ? `<small>+${ev.length - 2}</small>` : ""}</div>${thumb ? `<div class="calendar-preview" aria-hidden="true">${thumb.source === "local" ? `<img data-file="${escapeHtml(thumb.id)}" alt="">` : drivePhoto(thumb, "")}</div>` : ""}</button>`;
  }).join("")}</div><p class="setting-hint">${state.year === 2028 ? "2028년 공휴일은 사전 자료로 변경될 수 있어요." : HOLIDAY_YEARS.includes(state.year) ? "대한민국 공휴일 · 임시공휴일 추가 지정은 자료 업데이트가 필요해요." : "공휴일 자료는 2023~2028년 제공해요."}</p><div class="calendar-legend">${eventTargets().map((item) => `<span class="event-tone-${item.tone}"><i aria-hidden="true"></i>${escapeHtml(item.label)}</span>`).join("")}${state.mode === "live" ? "<span>Google Calendar</span>" : "<span>체험 캘린더</span>"}</div></section><aside class="card date-detail"><p class="eyebrow">ON THIS DAY</p><h2>${formatDate(state.day)}</h2><p class="holiday-name">${escapeHtml(holidays.filter((h) => h.date === state.day).map((h) => h.title).join(", "))}</p><h3>우리의 약속 <span>${dayEvents.length}</span></h3>${dayEvents.length ? eventRows(dayEvents) : '<p class="muted">아직 약속이 없는 날이에요.</p>'}<button class="full-width secondary" data-action="new" data-kind="event">${icon("plus")}이날 약속 추가</button>${dayPosts.length ? `<div class="divider"></div><h3>이날의 추억</h3>${dayPosts.map((r) => `<button class="text-button" data-action="open-post" data-id="${r.id}">${escapeHtml(r.data.title)} ${icon("right")}</button>`).join("")}` : ""}</aside></div>`;
}
function drivePhoto(file, alt, allowAccess = false, priority = false) {
  const original = file;
  file = previewFile(file);
  if (!cachedPhotoUrl(file) && cachedPhotoUrl(original)) file = original;
  const readyUrl = cachedPhotoUrl(file);
  return `<div class="photo-preview"><div class="file-cover"${readyUrl ? " hidden" : ""}>${icon("photo")}<span data-preview-status>${google.connected ? "사진을 불러오는 중…" : "Google 연결 후 사진을 볼 수 있어요."}</span><small>${escapeHtml(original.name)}</small>${allowAccess ? `<button class="secondary" data-action="photo-access" data-id="${escapeHtml(original.id)}" data-photo-access hidden>사진 접근 허용</button>` : ""}</div><img ${priority ? 'data-priority="high" ' : ""}data-drive-file="${escapeHtml(file.id)}"${file.id !== original.id ? ` data-drive-original="${escapeHtml(original.id)}"` : ""} alt="${escapeHtml(alt)}" decoding="async"${readyUrl ? ` src="${escapeHtml(readyUrl)}"` : " hidden"}></div>`;
}
function videoPreview(file) {
  return `<div class="video-preview"><video controls playsinline preload="metadata" ${file.source === "local" ? "data-file" : "data-drive-video"}="${escapeHtml(file.id)}" aria-label="${escapeHtml(file.name)}"></video>${file.source === "drive" ? `<button type="button" class="secondary video-load" data-action="video-load" data-id="${escapeHtml(file.id)}">영상 불러와 재생</button>` : ""}<span class="video-status" role="status"></span></div>`;
}
function postCard(row, priority = false) {
  const files = row.data.files || [];
  const cover = files.length ? `<div class="memory-cover memory-gallery"><div class="memory-slides" aria-label="첨부 파일 미리보기" tabindex="0">${files.map((originalFile, index) => {
    let file = previewFile(originalFile);
    if (file && !cachedPhotoUrl(file) && cachedPhotoUrl(originalFile)) file = originalFile;
    return originalFile.type.startsWith("video/") ? `<div class="memory-slide">${videoPreview(originalFile)}</div>` : `<button class="memory-slide" data-action="open-post" data-id="${row.id}" aria-label="${escapeHtml(postTitle(row))} ${state.view === "memories" ? "일기" : "게시글"} 열기">${file.type.startsWith("image/") ? file.source === "local" ? `<img data-file="${escapeHtml(file.id)}"${cachedLocalPhoto(file.id)} alt="${escapeHtml(file.name)}" loading="${priority && index === 0 ? "eager" : "lazy"}">` : drivePhoto(originalFile, file.name, false, priority && index === 0) : `<div class="file-cover">${icon("cloud")}<span>Drive에 보관한 순간</span><small>${escapeHtml(file.name)}</small></div>`}</button>`;
  }).join("")}</div>${files.length > 1 ? `<button type="button" class="memory-arrow memory-prev" data-action="attachment-prev" aria-label="이전 사진 또는 동영상" disabled>${icon("left")}</button><button type="button" class="memory-arrow memory-next" data-action="attachment-next" aria-label="다음 사진 또는 동영상">${icon("right")}</button><span class="file-count attachment-position" aria-live="polite">1 / ${files.length}</span>` : ""}</div>` : "";
  const commentCount = records("comment").filter((c) => c.data.postId === row.id).length;
  return `<article class="memory-card${files.length ? "" : " memory-text-only"}">${cover}<div class="memory-info" data-action="open-post" data-id="${row.id}"><p class="memory-date">${formatDate(row.data.date, { year: "numeric", month: "2-digit", day: "2-digit" })}</p><button class="title-button" data-action="open-post" data-id="${row.id}"><h3>${escapeHtml(postTitle(row))}</h3></button><button type="button" class="memory-excerpt" data-action="open-post" data-id="${row.id}" aria-haspopup="dialog">${escapeHtml(row.data.text || "함께한 순간을 간직해요.")}</button><div class="memory-meta"><span>${avatar(row.author_id, true)}${escapeHtml(nameOf(row.author_id))}</span><button type="button" class="memory-comments" data-action="open-comments" data-id="${row.id}" aria-label="${escapeHtml(postTitle(row))} 댓글 ${commentCount}개 보기" aria-haspopup="dialog">${icon("chat")}${commentCount}</button></div></div></article>`;
}
function memories() {
  const list = sortRecords(memoriesRows(), "date").filter((row) => `${row.data.title} ${row.data.text}`.toLowerCase().includes(state.filter.toLowerCase()));
  return `${pageTitle("COLLECTING LITTLE MOMENTS", "일기", "우리의 일기를 날짜별로 함께 보관해요.", addButton("post", "일기 쓰기"))}${postDraftReminder()}<div class="list-toolbar"><span>일기 <strong>${memoriesRows().length}</strong></span><form id="search-form" class="search">${icon("search")}<input name="search" aria-label="일기 검색" placeholder="어떤 일기를 찾고 있나요?" value="${escapeHtml(state.filter)}"><button type="submit" class="text-button">검색</button></form></div><div class="memory-grid all-memories">${list.length ? list.map((row) => postCard(row)).join("") : empty(state.filter ? "찾는 일기가 없어요" : "첫 일기를 써 보세요", state.filter ? "다른 단어로 찾아보세요." : "사진, 동영상과 함께 우리의 일기를 보관해요.", state.filter ? "" : addButton("post", "일기 쓰기"))}</div>`;
}
function coupleDateFields(name, label, value = "") {
  return `<label>${label}<input type="date" name="${name}" value="${escapeHtml(value)}" required></label>`;
}
function coupleDateValue(values, name, label) {
  const value = values[name] || "";
  const parsed = /* @__PURE__ */ new Date(`${value}T12:00:00Z`);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value) || !Number.isFinite(parsed.getTime()) || parsed.toISOString().slice(0, 10) !== value || value.startsWith("0000")) throw new Error(`${label}에 올바른 날짜를 선택해 주세요.`);
  return value;
}
function openCoupleSetup() {
  dialog("우리의 기념일을 알려 주세요", `<p class="setting-hint">연애 시작일을 달력에서 선택해 주세요. 생일은 각자 로그인한 뒤 설정에서 Google 계정으로 가져올 수 있어요.</p><form id="couple-setup-form">${coupleDateFields("startDate", "연애 시작일")}<p class="setting-hint">100일은 시작일을 포함해 계산해요.</p><p class="form-error" role="alert"></p><div class="modal-actions"><button type="button" class="secondary" data-action="close">나중에 설정</button><button type="submit" class="primary">저장하고 시작</button></div></form>`);
}
function settings() {
  const metrics = previewMeasurements();
  const birthday = (index) => state.couple.birthdays?.[index] || {};
  const cfg = window.APP_CONFIG;
  return `${pageTitle("MAKE OURSELVES AT HOME", "우리의 공간 설정", "연결은 간단하게, 소중한 기록은 안전하게.")}<div class="settings-grid"><section class="card settings-card"><div class="section-heading"><h2>우리의 프로필</h2></div><div class="pair-avatars">${avatar(state.user)}${avatar(state.user === "demo-me" ? "demo-partner" : "other")}</div><p>프로필 사진을 누르면 서로의 소개와 상태메시지를 볼 수 있어요.</p><button class="secondary" data-action="profile-edit">내 프로필 수정</button></section><section class="card settings-card"><h2>생일과 기념일</h2><form id="couple-form">${coupleDateFields("startDate", "연애 시작일", state.couple.startDate)}<p class="setting-hint">100일은 시작일을 포함해 계산해요. 2월 29일 생일은 평년에 2월 28일로 표시해요.</p><p class="form-error" role="alert"></p><button class="primary" type="submit">연애 시작일 저장</button></form><div class="divider"></div>${[0, 1].map((i) => {
    const item = birthday(i);
    return `<p>${escapeHtml(item.name || state.members.find((m) => m.slot === i + 1)?.display_name || (i === 0 ? "나" : "짝꿍"))}: ${item.date ? escapeHtml(item.date) : "아직 가져오지 않았어요"}</p>`;
  }).join("")}${state.mode === "live" ? '<button class="secondary" data-action="sync-birthday">내 Google 생일 가져오기</button><p class="setting-hint">두 사람 각각 로그인해 자신의 생일을 가져와 주세요. 생일은 두 사람에게 공유돼요.</p>' : '<p class="setting-hint">Google 생일은 로그인 후 가져올 수 있어요.</p>'}</section><section class="card settings-card"><h2>사진 미리보기 사용량</h2><p>이번 실행: ${metrics.downloads}회 · ${(metrics.bytes / 1024).toFixed(1)} KiB · ${(metrics.milliseconds / 1e3).toFixed(2)}초</p><p>메모리 캐시 재사용 ${metrics.cacheHits}회</p><p class="setting-hint">새 사진은 원본과 작은 미리보기를 함께 보관해요. 기존 사진은 원본을 사용해요. 전송량은 내려받은 이미지 본문 크기이며 통신 헤더는 제외해요.</p></section><section class="card settings-card"><div class="section-heading"><h2>${icon("heart")}우리의 계정</h2><span class="tag">${state.mode === "demo" ? "체험 중" : "연결됨"}</span></div><p>${state.mode === "demo" ? "지금은 이 브라우저에서 기능을 체험하고 있어요. 체험 기록과 실제 공유 기록은 따로 보관해요." : `${escapeHtml(auth.user?.email)} 계정으로 로그인했어요. 서버에서 허용한 두 계정만 기록을 볼 수 있어요.`}</p>${state.mode === "demo" ? `<button class="primary" data-action="login">Google로 로그인</button><p class="setting-hint">${configured ? "설정된 Supabase에 로그인합니다." : "먼저 README의 안내에 따라 config.js와 서버를 설정해 주세요."}</p><div class="divider"></div><label for="demo-person">체험할 사람</label><select id="demo-person"><option value="demo-me" ${state.user === "demo-me" ? "selected" : ""}>나</option><option value="demo-partner" ${state.user === "demo-partner" ? "selected" : ""}>짝꿍</option></select><p class="setting-hint">상대방으로 바꿔 댓글과 메시지, 작성자 권한을 확인할 수 있어요.</p>` : `<button class="secondary" data-action="logout">${icon("logout")}로그아웃</button>`}</section>
  <section class="card settings-card"><div class="section-heading"><h2>${icon("calendar")}Google 연결</h2><span class="tag">${google.connected ? "연결됨" : "연결 전"}</span></div><p>Google 로그인 시 캘린더와 Drive도 함께 연결돼요.</p><button class="primary" data-action="${google.connected ? "calendar-retry" : "google-connect"}">${icon("cloud")}${google.connected ? "캘린더 새로고침" : "Google 다시 연결"}</button><div class="status-list"><span>공유 캘린더 ID <b>${cfg.calendarId ? "설정됨" : "설정 필요"}</b></span><span>공유 Drive 폴더 <b>${cfg.driveFolderId ? "설정됨" : "설정 필요"}</b></span><span>폴더 접근 확인 <button class="text-button" data-action="pick-folder">폴더 선택</button></span></div><p class="setting-hint">사진을 자동으로 보려면 두 사람 모두 로그인할 때 Drive 읽기 권한을 허용하고, 공유 폴더를 두 계정에 공유해 주세요. Drive 읽기 권한은 각자 Drive 전체 파일에 적용돼요.</p></section>
  <section class="card settings-card"><div class="section-heading"><h2>${icon("home")}${native.active ? "설치형 GeonJuKong 앱" : "홈 화면에 설치"}</h2></div>${native.active ? '<p>휴대폰에 설치한 GeonJuKong 앱을 사용 중이에요. 앱 화면은 기기에 포함되어 있어 별도 웹페이지를 열지 않아도 돼요.</p><p class="setting-hint">공유 기록과 Google 연동에는 인터넷 연결이 필요해요. 새 버전은 새 설치 파일로 업데이트해 주세요.</p>' : '<p><strong>아이폰 14</strong><br>Safari에서 열기 → 공유 메뉴 → 홈 화면에 추가</p><p><strong>갤럭시 S23 울트라</strong><br>Chrome 메뉴 → 홈 화면에 추가 또는 앱 설치</p><p class="setting-hint">휴대폰 웹앱에서는 HTTPS 주소가 필요해요. 설치형 버전은 Android·iOS 빌드로 만들 수 있어요.</p><button class="secondary" data-action="install">설치 안내</button>'}</section>
  <section class="card settings-card wide"><div class="section-heading"><h2>${icon("download")}기록 보관과 백업</h2></div><p>글·일정·댓글·메시지와 파일 목록을 JSON으로 내려받아요. 사진·영상 원본은 포함되지 않으므로 ${state.mode === "demo" ? "체험 파일을 원본 열기로 따로 저장해 주세요." : "Google Drive에서도 별도로 백업해 주세요."}</p><div class="button-row"><button class="secondary" data-action="export">${icon("download")}기록 내보내기</button>${state.mode === "demo" ? '<button class="text-button danger" data-action="reset">체험 데이터 초기화</button>' : '<button class="text-button" data-action="refresh">지금 동기화</button>'}</div><p class="setting-hint">원본은 게시글을 삭제해도 유지해요. Drive에서 파일을 직접 삭제하면 게시글에서도 열 수 없어요.</p></section></div>`;
}
function clearDriveImages() {
  driveVideoPlayer.clear();
  driveObserver?.disconnect();
  for (const job of driveLoads.values()) job.controller.abort();
  driveLoads.clear();
  for (const url of driveUrls.values()) URL.revokeObjectURL(url);
  driveUrls.clear();
  decodedImages.clear();
}
function cachedPhotoUrl(file) {
  const url = (file.source === "local" ? urls : driveUrls).get(file.id);
  return decodedImages.has(url) ? url : "";
}
function cachedLocalPhoto(id) {
  const url = cachedPhotoUrl({ id, source: "local" });
  return url ? ` src="${escapeHtml(url)}"` : "";
}
async function localImageUrl(id) {
  if (!urls.has(id)) {
    const file = await local.file(id);
    if (file && !urls.has(id)) urls.set(id, URL.createObjectURL(file.blob));
  }
  return urls.get(id);
}
async function preloadHomePhotos() {
  const recentPosts = sortRecords(memoriesRows()), selected = selectedHomePhotos(recentPosts);
  const heroFiles = selected.map((item) => item.file);
  const files = [...heroFiles, ...recentPosts[0]?.data.files || []].filter((file) => file?.type.startsWith("image/"));
  const unique = new Map(files.map((file) => [`${file.source}:${previewFile(file).id}`, file]));
  const pending = /* @__PURE__ */ new Map();
  let expired = false, timer;
  const jobs = [...unique.values()].map(async (original) => {
    if (original.source !== "local" && state.mode !== "live") return;
    const prepare = async (file) => {
      if (expired) return;
      let url;
      if (file.source === "local") url = await localImageUrl(file.id);
      else {
        const request = driveImageUrl(file.id);
        const job = driveLoads.get(file.id);
        if (job) pending.set(file.id, job);
        url = await request;
      }
      if (!url) throw new Error("Image preview unavailable");
      if (expired || decodedImages.has(url)) return;
      if (typeof Image === "function") {
        const image = new Image();
        image.src = url;
        await image.decode();
      }
      if (!expired && (file.source === "local" ? urls : driveUrls).get(file.id) === url) decodedImages.add(url);
    };
    try {
      await prepare(previewFile(original));
    } catch {
      if (previewFile(original).id !== original.id) await prepare(original);
    }
  });
  try {
    await Promise.race([Promise.allSettled(jobs), new Promise((resolve2) => {
      timer = setTimeout(() => {
        expired = true;
        for (const [id, job] of pending) if (driveLoads.get(id) === job) {
          job.controller.abort();
          driveLoads.delete(id);
        }
        resolve2();
      }, 8e3);
    })]);
  } finally {
    clearTimeout(timer);
  }
}
async function driveImageUrl(id) {
  if (driveUrls.has(id)) {
    recordPreviewCacheHit();
    return driveUrls.get(id);
  }
  let job = driveLoads.get(id);
  if (!job) {
    job = { controller: new AbortController() };
    driveLoads.set(id, job);
    const started = performance.now();
    job.promise = google.image(id, job.controller.signal).then((blob) => {
      if (driveLoads.get(id) !== job) throw new DOMException("사진 요청이 취소됐어요.", "AbortError");
      recordPreviewDownload(blob.size, performance.now() - started);
      const url = URL.createObjectURL(blob);
      driveUrls.set(id, url);
      return url;
    }).finally(() => {
      if (driveLoads.get(id) === job) driveLoads.delete(id);
    });
  }
  return job.promise;
}
async function loadDriveImage(img) {
  const fallback = img.parentElement.querySelector(".file-cover");
  const status = img.parentElement.querySelector("[data-preview-status]");
  const tryOriginal = () => {
    if (!img.isConnected || !img.dataset.driveOriginal) return false;
    img.dataset.driveFile = img.dataset.driveOriginal;
    delete img.dataset.driveOriginal;
    loadDriveImage(img);
    return true;
  };
  const accessButton = img.parentElement.querySelector("[data-photo-access]");
  img.onload = () => {
    if (img.isConnected) {
      img.hidden = false;
      fallback.hidden = true;
      if (accessButton) accessButton.hidden = true;
    }
  };
  img.onerror = () => {
    img.hidden = true;
    fallback.hidden = false;
    if (!tryOriginal()) status.textContent = "이 사진은 원본 열기로 확인해 주세요.";
  };
  try {
    const url = await driveImageUrl(img.dataset.driveFile);
    if (img.isConnected && driveUrls.get(img.dataset.driveFile) === url) img.src = url;
  } catch (error) {
    if (img.isConnected && !tryOriginal()) {
      if (error.code === "rate_limit" || error.status === 429) status.textContent = "사진 요청이 많아 잠시 후 다시 시도해 주세요.";
      else if (error.status === 403 || error.status === 404) {
        status.textContent = "사진을 찾지 못했거나 접근이 거부됐어요. 사진 접근을 허용하거나 Drive 공유 권한을 확인해 주세요.";
        if (accessButton) accessButton.hidden = false;
      } else if (error.status === 401 || !google.connected) status.textContent = "설정에서 Google을 다시 연결해 주세요.";
      else if (error.code === "invalid_image") status.textContent = "미리볼 수 없는 사진이에요. 원본 열기를 이용해 주세요.";
      else status.textContent = "사진을 불러오지 못했어요. 네트워크를 확인한 뒤 다시 시도해 주세요.";
    }
  }
}
async function hydrateMedia() {
  driveVideoPlayer.prune(document.querySelectorAll("video[data-drive-video]"));
  for (const img of document.querySelectorAll("img[data-file], video[data-file]")) {
    (async () => {
      try {
        const url = await localImageUrl(img.dataset.file);
        if (img.isConnected && url) img.src = url;
      } catch {
      }
    })();
  }
  driveObserver?.disconnect();
  const images = [...document.querySelectorAll("img[data-drive-file]")];
  const visible = new Set(images.map((img) => img.dataset.driveFile));
  const homeIds = new Set(selectedHomePhotos().flatMap(({ file }) => [file.id, previewFile(file).id]));
  for (const [id, url] of driveUrls) if (driveUrls.size > 32 && !visible.has(id) && !homeIds.has(id)) {
    URL.revokeObjectURL(url);
    decodedImages.delete(url);
    driveUrls.delete(id);
  }
  for (const [id, job] of driveLoads) if (!visible.has(id)) {
    job.controller.abort();
    driveLoads.delete(id);
  }
  for (const img of images) if (!img.src) {
    if (driveObserver && img.dataset.priority !== "high" && !driveUrls.has(img.dataset.driveFile)) driveObserver.observe(img.parentElement);
    else loadDriveImage(img);
  }
}
function closeDialog() {
  const hadPostDraft = Boolean(postDraftSession);
  leavePostDraft();
  replyFocusCleanup?.();
  replyFocusCleanup = null;
  editorDraft?.dispose();
  editorDraft = null;
  disposeHomePhotoDraft();
  $("#editor").querySelectorAll?.("video").forEach((video) => video.pause());
  state.activePost = null;
  state.replyTo = "";
  postCommentsOnly = false;
  $("#editor").close();
  unlockPage();
  $("#editor").innerHTML = "";
  if (hadPostDraft) render();
  hydrateMedia();
}
function dialog(title, content) {
  leavePostDraft();
  replyFocusCleanup?.();
  replyFocusCleanup = null;
  editorDraft?.dispose();
  editorDraft = null;
  const el = $("#editor");
  el.querySelectorAll?.("video").forEach((video) => video.pause());
  el.innerHTML = `<div class="modal-heading"><h2 id="dialog-title">${title}</h2><button class="icon-button" data-action="close" aria-label="닫기">${icon("close")}</button></div>${content}`;
  if (!el.open) {
    lockPage();
    el.showModal();
  }
}
function chooseHomePhoto() {
  disposeHomePhotoDraft();
  homePhotoShowPosts = false;
  homePhotoDraft = resolveHomePhotos(homePhotoLibrary()).map(({ file, selection }) => ({ key: crypto.randomUUID(), metadata: file, reference: selection.recordId && selection.fileId ? { recordId: selection.recordId, fileId: selection.fileId } : void 0, used: true, selected: selection.selected !== false }));
  homePhotoDraft.sort((a, b) => Number(b.selected) - Number(a.selected));
  const included = new Set(homePhotoDraft.map((item) => JSON.stringify([item.metadata.source, item.metadata.id])));
  for (const row of sortRecords(memoriesRows())) {
    for (const file of row.data.files || []) {
      const key = JSON.stringify([file.source, file.id]);
      if (!file.type.startsWith("image/")) continue;
      const reference = { recordId: row.id, fileId: file.id };
      if (included.has(key)) {
        const item = homePhotoDraft.find((item2) => item2.metadata.source === file.source && item2.metadata.id === file.id);
        item.reference ||= reference;
        continue;
      }
      included.add(key);
      homePhotoDraft.push({ key: crypto.randomUUID(), metadata: file, reference, selected: false });
    }
  }
  renderHomePhotoPicker();
}
function homePhotoPreview(original, priority = false) {
  let file = previewFile(original);
  if (!cachedPhotoUrl(file) && cachedPhotoUrl(original)) file = original;
  return file.source === "local" ? `<img data-file="${escapeHtml(file.id)}"${cachedLocalPhoto(file.id)} alt="${escapeHtml(original.name)}">` : drivePhoto(original, original.name, false, priority);
}
function renderHomePhotoPicker(focusKey) {
  const photos = homePhotoDraft.filter((item) => homePhotoShowPosts || item.used || item.added || item.file);
  const listScroll = $(".home-photo-options")?.scrollTop || 0, dialogScroll = $("#editor").scrollTop || 0;
  dialog("홈 사진 선택", `<p class="setting-hint">홈에 사용했던 사진을 모아뒀어요. 선택을 해제해도 보관함에 남아요. 선택한 사진은 이 창을 열 때만 맨 위에 정렬돼요.</p><label class="secondary home-photo-add">갤러리에서 추가<input id="home-photo-files" type="file" accept="image/*" multiple></label><button type="button" class="secondary" data-action="show-home-post-photos" aria-pressed="${homePhotoShowPosts}">${homePhotoShowPosts ? "홈 사진 보관함만 보기" : "게시글 사진도 보기"}</button><p role="status">선택한 사진 ${homePhotoDraft.filter((item) => item.selected).length}장</p><div class="home-photo-options">${photos.map((item) => {
    const file = item.file || item.metadata;
    return `<button type="button" class="home-photo-option" data-action="toggle-home-photo" data-key="${escapeHtml(item.key)}" aria-pressed="${item.selected}" aria-label="${escapeHtml(file.name)} ${item.selected ? "선택 해제" : "선택"}">${item.url ? `<img src="${escapeHtml(item.url)}" alt="">` : homePhotoPreview(file)}<span>${escapeHtml(file.name)}</span><span>${item.selected ? "✓ 선택됨 · 선택 해제" : "선택하기"}</span></button>`;
  }).join("") || "<p>아직 홈에 사용한 사진이 없어요. 갤러리에서 추가하거나 게시글 사진을 골라 주세요.</p>"}</div><p class="form-error" role="alert"></p><div class="modal-actions"><button type="button" class="secondary" data-action="clear-home-photos">모두 선택 해제</button><button type="button" class="primary" data-action="set-home-photo">선택 저장</button></div>`);
  const list = $(".home-photo-options");
  if (list) list.scrollTop = listScroll;
  $("#editor").scrollTop = dialogScroll;
  if (focusKey) $(`[data-key="${focusKey}"]`)?.focus?.({ preventScroll: true });
  hydrateMedia();
}
function addHomePhotos(files) {
  const selected = Array.from(files, selectedMediaFile);
  if (selected.some((file) => !file.type.startsWith("image/"))) throw new Error("홈 사진에는 사진만 추가할 수 있어요.");
  for (const file of selected) {
    const existing = homePhotoDraft.find((item) => item.file && item.file.name === file.name && item.file.size === file.size && item.file.lastModified === file.lastModified && item.file.type === file.type);
    if (existing) {
      existing.selected = true;
      continue;
    }
    homePhotoDraft.push({ key: crypto.randomUUID(), file, url: URL.createObjectURL(file), selected: true });
  }
  renderHomePhotoPicker();
}
async function saveHomePhotos(button) {
  const selected = homePhotoDraft.filter((item) => item.selected);
  state.busy = true;
  button.disabled = true;
  const original = button.textContent;
  try {
    for (const [index, item] of selected.entries()) {
      if (!item.metadata) {
        const file = item.file;
        const progress = (percent) => {
          button.textContent = `${index + 1}/${selected.length} · ${percent}%`;
        };
        if (state.mode === "demo") {
          const id = crypto.randomUUID();
          await local.putFile(id, file);
          item.metadata = { id, name: file.name, type: file.type, size: file.size, source: "local" };
        } else item.metadata = await google.upload(file, progress);
      }
      if (item.file && !item.thumbnailAttempted) {
        item.thumbnailAttempted = true;
        const thumbnail = await createThumbnail(item.file);
        if (thumbnail) {
          try {
            if (state.mode === "demo") {
              const id = crypto.randomUUID();
              await local.putFile(id, thumbnail);
              item.metadata.thumbnail = { id, name: thumbnail.name, type: thumbnail.type, size: thumbnail.size, source: "local" };
            } else item.metadata.thumbnail = await google.upload(thumbnail, () => {
            });
          } catch {
          }
        }
      }
    }
    const photos = homePhotoDraft.filter((item) => item.used || item.selected).map((item) => ({ ...item.reference, file: item.metadata, selected: item.selected }));
    if (state.mode === "demo") {
      const couple = { ...state.couple, homePhoto: photos };
      localStorage.setItem("geonjukong-demo-couple", JSON.stringify(couple));
      state.couple = couple;
    } else state.couple = await repository.updateHomePhoto(photos);
    homePhotoIndex = null;
    closeDialog();
    render();
    toast("홈 사진을 저장했어요.");
  } catch (error) {
    const box = $("#editor .form-error");
    if (box) box.textContent = error.message;
    throw error;
  } finally {
    state.busy = false;
    button.disabled = false;
    button.textContent = original;
  }
}
function updateMediaDraft() {
  const container = $("#media-draft");
  if (container && editorDraft) {
    container.innerHTML = editorDraft.render();
    hydrateMedia();
  }
  if (postDraftSession && !postDraftSession.waiting) capturePostDraft();
}
function openEditor(kind, row) {
  if (!["event", "post", "comment"].includes(kind)) throw new Error("지원하지 않는 기록입니다.");
  if (kind === "event" && state.mode === "live" && !google.connected) {
    toast("설정에서 Google을 먼저 연결해 주세요.");
    state.view = "settings";
    render();
    return;
  }
  if (kind === "comment") state.postScroll = $("#editor").scrollTop || 0;
  const diary = kind === "post" && state.view === "memories";
  const data = row?.data || {};
  const title = { event: "우리의 약속", post: diary ? row ? "일기 수정" : "일기 쓰기" : "추억 남기기", comment: "댓글 수정" }[kind];
  let end = data.end?.dateTime ? new Date(data.end.dateTime) : null;
  let endDate = data.end?.date ? /* @__PURE__ */ new Date(`${data.end.date}T12:00:00`) : null;
  if (endDate) endDate.setDate(endDate.getDate() - 1);
  dialog(title, `${kind === "post" ? postDraftPanel() : ""}<form id="record-form" data-kind="${kind}" data-id="${row?.id || ""}" data-version="${escapeHtml(row?.updated_at || row?.created_at || "")}">${kind !== "comment" ? `<label>날짜<input type="date" name="date" value="${escapeHtml(data.date || (state.view === "calendar" ? state.day : today))}" required></label>` : `<input type="hidden" name="postId" value="${escapeHtml(data.postId)}">`}${["event", "post"].includes(kind) ? `<label>${diary ? "일기 제목" : "제목"}<input name="title" value="${escapeHtml(data.title || "")}" maxlength="120" placeholder="${diary ? "어떤 하루였나요?" : "어떤 순간인가요?"}" required></label>` : ""}${kind === "event" ? `${eventTargetPicker(data)}<div class="form-row"><label>시작 시간 <span class="optional">비우면 하루 종일</span><input name="time" type="time" value="${escapeHtml(data.time || "")}"></label><label>종료 날짜<input name="endDate" type="date" value="${end ? dateKey(end) : endDate ? dateKey(endDate) : data.date || (state.view === "calendar" ? state.day : today)}"></label><label>종료 시간<input name="endTime" type="time" value="${end ? `${String(end.getHours()).padStart(2, "0")}:${String(end.getMinutes()).padStart(2, "0")}` : ""}"></label></div>` : ""}<label>${kind === "event" ? "메모" : diary ? "일기 내용" : "이야기"}<textarea name="text" rows="${kind === "event" ? 3 : 6}" maxlength="10000" placeholder="${diary ? "오늘의 일기를 남겨 보세요…" : "오늘을 기억할 작은 이야기…"}" ${kind === "comment" ? "required" : ""}>${escapeHtml(data.text || "")}</textarea></label>${kind === "post" ? `<label class="file-input">${icon("photo")}사진·동영상 원본 추가<input type="file" name="files" accept="image/jpeg,image/png,image/webp,image/gif,image/heic,image/heif,image/avif,video/mp4,video/quicktime,video/webm,video/3gpp" multiple></label><div id="media-draft"></div><p id="file-summary" class="setting-hint">${data.files?.length ? `기존 파일 ${data.files.length}개 · 아래에서 순서와 첨부를 변경할 수 있어요. ` : ""}${state.mode === "demo" ? "원본은 이 브라우저에 저장돼요. 브라우저 데이터를 지우면 삭제돼요." : "원본을 공유 Drive 폴더에 보관해요. 전송 중 이 화면을 열어 두세요."}</p>` : ""}<p id="form-error" class="form-error" role="alert"></p><div class="modal-actions">${kind === "event" && row ? `<button class="text-button danger" type="button" data-action="delete-event" data-id="${row.id}">일정 삭제</button>` : ""}<button type="button" class="secondary" data-action="close">취소</button><button type="submit" class="primary">${diary ? row ? "일기 수정 저장" : "일기 저장" : row ? "수정 저장" : "기록하기"}</button></div></form>`);
  if (kind === "post") {
    editorDraft = createMediaDraft(data.files || []);
    updateMediaDraft();
    beginPostDraft(row);
  }
}
function openPost(row, scroll = 0, commentsOnly = postCommentsOnly) {
  if (!row || row.kind !== "post") return;
  state.activePost = row.id;
  if (!records("comment").some((c) => c.id === state.replyTo && c.data.postId === row.id)) state.replyTo = "";
  postCommentsOnly = commentsOnly;
  if (commentsOnly) {
    dialog("댓글", `<article class="post-detail"><p class="comments-post-title">${escapeHtml(postTitle(row))}</p>${commentSection(row)}</article>`);
    $("#editor").scrollTop = scroll;
    hydrateMedia();
    return;
  }
  dialog(escapeHtml(postTitle(row)), `<article class="post-detail"><div class="byline">${avatar(row.author_id, true)}<span>${escapeHtml(nameOf(row.author_id))} · ${formatDate(row.data.date)}</span></div><p class="record-times">작성 ${escapeHtml(new Date(row.created_at).toLocaleString("ko-KR"))}${row.updated_at && row.updated_at !== row.created_at ? ` · 수정 ${escapeHtml(new Date(row.updated_at).toLocaleString("ko-KR"))}` : ""}</p><p class="post-text">${escapeHtml(row.data.text || "")}</p>${row.data.files?.length ? `<div class="attachment-gallery"><div class="attachments" aria-label="첨부 파일" tabindex="0">${(row.data.files || []).map((file, index) => `<div class="attachment" role="group" aria-label="${index + 1} / ${row.data.files.length}">${file.type.startsWith("video/") ? videoPreview(file) : file.source === "local" ? `<img data-file="${escapeHtml(file.id)}" alt="${escapeHtml(file.name)}">` : drivePhoto(file, file.name, true)}<button class="secondary" data-action="open-file" data-id="${escapeHtml(file.id)}" data-source="${file.source}">${icon("download")}원본 열기</button></div>`).join("")}</div>${row.data.files?.length > 1 ? `<div class="attachment-navigation"><button type="button" class="icon-button" data-action="attachment-prev" aria-label="이전 사진 또는 동영상" disabled>${icon("left")}</button><span class="attachment-position" aria-live="polite">1 / ${row.data.files.length}</span><button type="button" class="icon-button" data-action="attachment-next" aria-label="다음 사진 또는 동영상">${icon("right")}</button></div>` : ""}</div>` : ""}${canEdit(row) ? `<div class="post-tools"><button class="text-button" data-action="edit" data-id="${row.id}">${state.view === "memories" ? "일기 수정" : "게시글 수정"}</button>${row.author_id === state.user ? `<button class="text-button danger" data-action="delete" data-id="${row.id}">${state.view === "memories" ? "일기 삭제" : "삭제"}</button>` : ""}</div>` : ""}<div class="divider"></div>${commentSection(row)}</article>`);
  $("#editor").scrollTop = scroll;
  hydrateMedia();
}
function commentSection(row) {
  return `<h3>둘이 나누는 이야기 <span class="muted">${records("comment").filter((c) => c.data.postId === row.id).length}</span></h3><div class="comments">${commentList(row)}</div>${state.replyTo ? "" : commentForm(row)}`;
}
function commentForm(row, comment = null) {
  const reply = comment ? comment.data.replyTo || comment.id : "";
  return `<form id="comment-form" data-post="${row.id}" data-reply="${escapeHtml(reply)}" class="comment-form${comment ? " reply-form" : ""}"><label class="sr-only" for="comment-text">${comment ? "답글" : "댓글"}</label><textarea id="comment-text" name="text" rows="2" maxlength="10000" required placeholder="${comment ? "답글을 입력해 주세요…" : "이 순간에 마음 한 줄…"}"></textarea>${comment ? '<button type="button" class="text-button" data-action="cancel-reply">취소</button>' : ""}<button type="submit" class="primary">${comment ? "답글 남기기" : "댓글 남기기"}</button><p class="form-error" role="alert"></p></form>`;
}
function commentList(row) {
  const comments = sortRecords(records("comment").filter((c) => c.data.postId === row.id), "oldest");
  const renderComment = (c, reply = false) => `<div class="comment ${reply ? "reply" : ""}" id="comment-${escapeHtml(c.id)}">${avatar(c.author_id, true)}<div class="comment-body"><strong>${escapeHtml(nameOf(c.author_id))}</strong><p>${escapeHtml(c.data.text)}</p><small>${timeOf(c.created_at)}${c.updated_at && c.updated_at !== c.created_at ? " · 수정됨" : ""}</small><button class="text-button" data-action="reply" data-id="${c.id}">답글</button>${c.author_id === state.user ? `<button class="text-button" data-action="edit" data-id="${c.id}">수정</button><button class="text-button danger" data-action="delete-comment" data-id="${c.id}" data-post="${row.id}">삭제</button>` : ""}${state.replyTo === c.id ? commentForm(row, c) : ""}</div></div>`;
  return comments.filter((c) => !c.data.replyTo || !comments.some((p) => p.id === c.data.replyTo)).map((c) => renderComment(c) + comments.filter((r) => r.data.replyTo === c.id).map((r) => renderComment(r, true)).join("")).join("") || '<p class="muted">첫 댓글로 마음을 전해 보세요.</p>';
}
function openNotices() {
  state.activePost = null;
  dialog("알림", (notices().some((r) => !noticeRead(r.id)) ? '<div class="notification-actions"><button class="text-button" data-action="notice-read-all">모두 읽음</button></div>' : "") + '<div class="notification-list">' + notices().map((r) => {
    const isEvent = r.kind === "event" || r.kind === "event_notice";
    const parent = r.kind === "comment" ? state.records.find((item) => item.id === r.data.postId) : null;
    const title = isEvent ? r.data.title : postTitle(parent || r);
    const action = isEvent ? "새 일정" : r.kind === "comment" ? r.data.replyTo ? "새 답글" : "새 댓글" : "새 기록";
    return `<button class="notification-item ${noticeRead(r.id) ? "" : "unread"}" data-action="notice-open" data-id="${escapeHtml(r.id)}"><strong>${escapeHtml(title)}</strong><span>${escapeHtml(nameOf(r.author_id))}님의 ${action} · ${escapeHtml(new Date(r.created_at).toLocaleString("ko-KR"))}</span></button>`;
  }).join("") + (notices().length ? "" : '<p class="muted">새 알림이 없어요.</p>') + "</div>");
}
async function syncCalendar(shouldApply = () => true) {
  const sequence = ++calendarSyncSequence;
  const year = state.year, month = state.month;
  try {
    if (!google.connected) await google.restore();
    const rows = await google.events(year, month);
    if (sequence === calendarSyncSequence && state.mode === "live" && shouldApply()) {
      state.events = rows;
      state.calendarError = "";
    }
  } catch (error) {
    if (sequence === calendarSyncSequence && state.mode === "live" && shouldApply()) {
      state.calendarError = error.message || "Google 캘린더를 동기화하지 못했어요.";
    }
  }
}
async function syncUpcoming(shouldApply = () => true) {
  const sequence = ++upcomingSyncSequence, day = dateKey();
  try {
    if (!google.connected) await google.restore();
    const rows = await google.upcomingEvents(day);
    if (sequence === upcomingSyncSequence && state.mode === "live" && day === dateKey() && shouldApply()) {
      state.upcomingEvents = rows;
      state.upcomingError = "";
      upcomingDate = day;
    }
  } catch (error) {
    if (sequence === upcomingSyncSequence && state.mode === "live" && shouldApply()) {
      state.upcomingError = error.message || "다가오는 일정을 불러오지 못했어요.";
      upcomingDate = day;
    }
  }
}
async function load(refreshGoogle = false, preloadPhotos = false) {
  if (state.mode === "demo") {
    const user = state.user, rows = await local.list();
    if (state.mode !== "demo" || state.user !== user) return;
    state.records = rows;
    try {
      state.notificationReads = JSON.parse(localStorage.getItem("geonjukong-demo-notification-reads") || "[]");
      state.couple = JSON.parse(localStorage.getItem("geonjukong-demo-couple") || "{}");
    } catch {
      state.notificationReads = [];
      state.couple = {};
    }
  } else {
    const user = state.user;
    const current = () => state.mode === "live" && state.user === user && auth.user?.id === user;
    await updatePendingNotices(user);
    if (!current()) return;
    const [rows, noticeReads, couple] = await Promise.all([repository.list(), repository.notificationReads(), repository.coupleSettings()]);
    if (!current()) return;
    state.records = rows;
    state.notificationReads = noticeReads.map((r) => ({ ...r, user_id: user }));
    state.couple = couple;
    const photos = preloadPhotos ? preloadHomePhotos() : Promise.resolve();
    if (refreshGoogle) await Promise.all([photos, syncCalendar(current), syncUpcoming(current)]);
    else await photos;
    if (!current()) return;
  }
  if (preloadPhotos && state.mode === "demo") await preloadHomePhotos();
  await loadFeatures();
  state.error = "";
  state.lastSync = (/* @__PURE__ */ new Date()).toISOString();
}
async function navigate(view, back = false) {
  if (!views[view]) return;
  if (view === "home" && state.view !== "home") homePhotoIndex = null;
  if (!back && view !== state.view) viewHistory.push(state.view);
  state.view = view;
  history.replaceState({ view }, "", `#${view}`);
  render();
  window.scrollTo({ top: 0, behavior: "instant" });
}
function requireLive() {
  if (state.mode !== "live") throw new Error("실제 연동은 Google 로그인과 서버 설정 후 사용할 수 있어요. 체험 모드에서는 외부 데이터를 변경하지 않아요.");
}
async function seed() {
  if (localStorage.getItem("geonjukong-seeded")) return;
  const shifted = (offset) => {
    const d = /* @__PURE__ */ new Date();
    d.setDate(d.getDate() + offset);
    return dateKey(d);
  };
  const sample = [
    ["event", "demo-me", { title: "같이 저녁 먹기", date: today, time: "19:00", text: "오늘은 서로 좋아하는 메뉴로." }],
    ["event", "demo-partner", { title: "느긋한 산책", date: shifted(2), time: "16:00", text: "커피 한 잔, 그리고 우리 둘." }],
    ["post", "demo-me", { title: "별일 없이도 좋은 하루", date: shifted(-1), text: "걷다가 나눈 시시한 이야기까지, 오래 기억하고 싶어서.", art: "walk", files: [] }],
    ["post", "demo-partner", { title: "우리의 첫 번째 페이지", date: shifted(-3), text: "여기에 우리만의 순간들을 하나씩 모아 보자.", files: [] }]
  ];
  for (let i = 0; i < sample.length; i++) {
    const [kind, author_id, data] = sample[i];
    await local.put({ id: crypto.randomUUID(), kind, author_id, data, created_at: new Date(Date.now() - (sample.length - i) * 6e4).toISOString() });
  }
  localStorage.setItem("geonjukong-seeded", "1");
}
async function start(callbackUrl) {
  startupPending = true;
  if ($("#editor").open) closeDialog();
  try {
    await auth.callback(callbackUrl);
    if (configured && auth.user) {
      const members = await repository.members();
      if (members.length !== 2) throw new Error("허용된 두 계정의 서버 설정을 확인해 주세요.");
      state.mode = "live";
      state.user = auth.user.id;
      state.members = members;
      google.setTokenProvider((force) => auth.googleToken(force));
      const providerToken2 = auth.takeProviderToken();
      if (providerToken2) {
        try {
          await google.acceptNativeToken(providerToken2, auth.user.email);
        } catch (error) {
          console.error(error.message);
        }
      }
    } else {
      await seed();
      state.user = localStorage.getItem("geonjukong-demo-person") === "demo-partner" ? "demo-partner" : "demo-me";
    }
    state.view = views[location.hash.slice(1)] ? location.hash.slice(1) : "home";
    await load(state.mode === "live", true);
    render();
    if (state.mode === "live" && !Object.keys(state.couple).length) openCoupleSetup();
    google.prepare().catch(report);
    if (!native.active && "serviceWorker" in navigator) navigator.serviceWorker.register("./sw.js").catch(() => toast("오프라인 설치 기능을 준비하지 못했어요. HTTPS 주소에서 다시 확인해 주세요."));
  } catch (error) {
    state.mode = "demo";
    state.user = "demo-me";
    state.members = [];
    state.records = [];
    state.events = [];
    syncNotificationBadge();
    $("#app").innerHTML = `<div class="access-error">${icon("heart")}<h1>우리 둘의 공간이에요</h1><p>${escapeHtml(error.message)}</p><button class="primary" data-action="logout">로그아웃하고 다시 시작</button><button class="secondary" data-action="reload">다시 시도</button></div>`;
  } finally {
    startupPending = false;
  }
}
async function handleBack() {
  if (state.busy) {
    toast("저장이 끝날 때까지 기다려 주세요.");
    return;
  }
  if ($("#editor").open) {
    if ($("#record-form")?.dataset.kind === "comment" && state.activePost) openPost(state.records.find((r) => r.id === state.activePost), state.postScroll);
    else closeDialog();
    return;
  }
  if (viewHistory.length) {
    await navigate(viewHistory.pop(), true);
    return;
  }
  if (state.view !== "home") {
    await navigate("home", true);
    return;
  }
  if (confirm("앱을 종료할까요?")) {
    if (native.active) await native.exit();
    else {
      toast("브라우저 메뉴에서 창을 닫을 수 있어요.");
    }
  }
}
async function boot() {
  installDialogDismissal($("#editor"), () => handleBack().catch(report));
  await native.onBack(handleBack);
  const launchUrl = await native.listen(async (url) => {
    if (!isAuthCallback(url) || processingLink) return;
    processingLink = true;
    try {
      await start(url);
    } finally {
      processingLink = false;
    }
  });
  await start(isAuthCallback(launchUrl) ? launchUrl : void 0);
  if (!native.active && history.pushState) history.pushState({ view: state.view }, "", `#${state.view}`);
}
var $, today, now, state, paths, icon, labels, navigation, formatDate, timeOf, records, events, memoriesRows, postTitle, postCommentsOnly, replyFocusCleanup, canEdit, notices, noticeRead, badgeUpdate, pendingNotices, pendingKey, profiles, bucket, nameOf, avatar, eventTarget, editorDraft, postDraftSession, postDraftScope, startupPending, addButton, demoBanner, homePhotoIndex, homePhotoDraft, homePhotoShowPosts, homePhotoLibrary, homePhotoSelections, selectedHomePhotos, views, urls, driveUrls, driveLoads, decodedImages, driveVideoPlayer, loadDriveVideo, driveObserver, calendarSyncSequence, upcomingSyncSequence, upcomingDate, viewHistory, installPrompt, polling, pendingRender, pendingCommentPost, nextCalendarRefresh, processingLink;
var init_app = __esm({
  "src/app.js"() {
    init_core();
    init_media();
    init_storage();
    init_backend();
    init_google();
    init_platform();
    init_bucket_list();
    init_profiles();
    init_editor_media();
    init_post_drafts();
    init_dialog_behavior();
    init_gallery();
    init_drive_video();
    installGalleryDrag();
    $ = (selector) => document.querySelector(selector);
    today = dateKey();
    now = /* @__PURE__ */ new Date();
    state = { mode: "demo", user: "demo-me", view: "home", year: now.getFullYear(), month: now.getMonth(), day: today, records: [], events: [], upcomingEvents: [], upcomingError: "", bucketItems: [], profiles: [], members: [], busy: false, filter: "", error: "", noticeError: "", calendarError: "", lastSync: null, notificationReads: [], couple: {}, activePost: null, postScroll: 0, replyTo: "" };
    paths = {
      heart: '<path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1.1-1.1a5.5 5.5 0 0 0-7.8 7.8L12 21l8.8-8.6a5.5 5.5 0 0 0 0-7.8Z"/>',
      home: '<path d="m3 10 9-7 9 7v10a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1Z"/>',
      calendar: '<rect x="3" y="5" width="18" height="16" rx="3"/><path d="M16 3v4M8 3v4M3 11h18m-12 4h.01M12 15h.01M16 15h.01"/>',
      photo: '<rect x="3" y="3" width="18" height="18" rx="3"/><circle cx="8" cy="8" r="1.5"/><path d="m21 15-5-5L5 21"/>',
      book: '<path d="M12 5v16M3 3c4-1 7 0 9 2 2-2 5-3 9-2v16c-4-1-7 0-9 2-2-2-5-3-9-2Z"/>',
      chat: '<path d="M21 11.5a8.5 8.5 0 0 1-8.5 8.5H4l-3 2 2-7a8.5 8.5 0 1 1 18-3.5Z"/><path d="M7 11h.01M12 11h.01M17 11h.01"/>',
      settings: '<circle cx="12" cy="12" r="3"/><path d="m9 3-1 3-3 1-2 3 2 3v4l4 1 3 3 3-3 4-1v-4l2-3-2-3-3-1-1-3Z"/>',
      plus: '<path d="M12 5v14M5 12h14"/>',
      arrow: '<path d="M5 12h14m-6-6 6 6-6 6"/>',
      left: '<path d="m15 6-6 6 6 6"/>',
      right: '<path d="m9 6 6 6-6 6"/>',
      cloud: '<path d="M7 18a5 5 0 1 1 1-10 6 6 0 0 1 12 2 4 4 0 0 1-1 8Z"/>',
      close: '<path d="m6 6 12 12M6 18 18 6"/>',
      send: '<path d="m22 2-7 20-4-9L2 9Zm0 0L11 13"/>',
      check: '<path d="m5 12 4 4L19 6"/>',
      download: '<path d="M12 3v12m-5-5 5 5 5-5M4 16v5h16v-5"/>',
      logout: '<path d="M9 3H4v18h5M9 12h13m-5-5 5 5-5 5"/>',
      search: '<circle cx="10" cy="10" r="6"/><path d="m15 15 6 6"/>'
    };
    icon = (name, extra = "") => `<svg class="icon ${extra}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${paths[name] || paths.heart}</svg>`;
    labels = { home: "우리의 오늘", calendar: "캘린더", memories: "일기", settings: "설정" };
    navigation = { home: "home", calendar: "calendar", memories: "photo", bucket: "check", settings: "settings" };
    labels.home = "홈";
    labels.bucket = "버킷리스트";
    labels.memories = "일기";
    paths.bell = '<path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9M10 21h4"/>';
    formatDate = (key, options = { month: "long", day: "numeric", weekday: "short" }) => (/* @__PURE__ */ new Date(`${key}T12:00:00`)).toLocaleDateString("ko-KR", options);
    timeOf = (iso) => new Date(iso).toLocaleTimeString("ko-KR", { hour: "2-digit", minute: "2-digit" });
    records = (kind) => state.records.filter((r) => r.kind === kind);
    events = () => [...state.mode === "demo" ? records("event") : state.events, ...coupleEvents(state.year, state.couple)];
    memoriesRows = () => records("post");
    postTitle = (row) => row.data.title || "제목 없음";
    postCommentsOnly = false;
    replyFocusCleanup = null;
    canEdit = (row) => row.author_id === state.user || row.kind === "post" && row.data.space === "board";
    notices = () => sortRecords(state.records.filter((r) => (["post", "event_notice"].includes(r.kind) || r.kind === "comment" && memoriesRows().some((post) => post.id === r.data.postId) || state.mode === "demo" && r.kind === "event") && r.author_id !== state.user));
    noticeRead = (id) => state.notificationReads.some((r) => r.record_id === id && r.user_id === state.user);
    badgeUpdate = Promise.resolve();
    pendingNotices = /* @__PURE__ */ new Map();
    pendingKey = (user) => `geonjukong-pending-calendar-notices:${user}`;
    profiles = createProfiles({ state, repository, dialog, closeDialog, render, toast, currentEmail: () => auth.user?.email });
    bucket = createBucketList({ state, repository, local, dialog, closeDialog, render, toast });
    nameOf = (id) => profiles.nameOf(id);
    avatar = (id, small = false) => profiles.avatar(id, small);
    eventTarget = (data) => eventTargets().find((item) => item.value === data.target) || eventTargets()[0];
    editorDraft = null;
    postDraftSession = null;
    postDraftScope = (target) => ({ mode: state.mode, user: state.user, target: target || "" });
    startupPending = true;
    addButton = (kind, label, cls = "primary") => `<button class="${cls}" data-action="new" data-kind="${kind}">${icon("plus")}${label}</button>`;
    demoBanner = () => `<div class="demo-banner ${state.mode === "live" ? "live-banner" : ""}">${icon(state.mode === "demo" ? "cloud" : "check")}<span>${state.mode === "demo" ? "체험 기록은 이 브라우저에만 저장돼요. 두 기기에서 함께 쓰려면 계정을 연결해 주세요." : `두 사람에게만 공개되는 공간이에요.${state.lastSync ? ` · ${timeOf(state.lastSync)} 동기화` : ""}`}</span><button data-view="settings">${state.mode === "demo" ? "연결 설정" : "관리"} ${icon("right")}</button></div>`;
    homePhotoIndex = null;
    homePhotoDraft = [];
    homePhotoShowPosts = false;
    homePhotoLibrary = () => Array.isArray(state.couple.homePhoto) ? state.couple.homePhoto : state.couple.homePhoto ? [state.couple.homePhoto] : [];
    homePhotoSelections = () => homePhotoLibrary().filter((item) => item.selected !== false);
    selectedHomePhotos = (recentPosts) => resolveHomePhotos(homePhotoSelections(), recentPosts);
    views = { home, calendar, memories, bucket: () => bucket.render(), settings };
    urls = /* @__PURE__ */ new Map();
    driveUrls = /* @__PURE__ */ new Map();
    driveLoads = /* @__PURE__ */ new Map();
    decodedImages = /* @__PURE__ */ new Set();
    driveVideoPlayer = createDriveVideoPlayer(google);
    loadDriveVideo = (video, autoplay) => driveVideoPlayer.load(video, autoplay);
    driveObserver = typeof IntersectionObserver === "function" ? new IntersectionObserver((entries) => {
      for (const entry of entries) if (entry.isIntersecting) {
        driveObserver.unobserve(entry.target);
        loadDriveImage(entry.target.querySelector("img"));
      }
    }, { rootMargin: "200px" }) : null;
    calendarSyncSequence = 0;
    upcomingSyncSequence = 0;
    upcomingDate = "";
    viewHistory = [];
    window.addEventListener("beforeinstallprompt", (event) => {
      event.preventDefault();
      installPrompt = event;
    });
    document.addEventListener("click", async (event) => {
      if (event.target.type === "file" && event.target.name === "files" && editorDraft && native.canPickMedia) {
        event.preventDefault();
        if (state.busy) return;
        const draft = editorDraft;
        state.busy = true;
        try {
          const files = await native.pickMedia();
          if (editorDraft === draft) {
            draft.addFiles(files);
            updateMediaDraft();
          }
        } catch (error) {
          report(error);
        } finally {
          state.busy = false;
        }
        return;
      }
      const button = event.target.closest('[data-action="profile-open"], button, a[data-action], a[data-view], .memory-info[data-action="open-post"]');
      if (!button) return;
      try {
        if (button.dataset.view) {
          if (button.tagName === "A") event.preventDefault();
          await navigate(button.dataset.view);
          return;
        }
        const action = button.dataset.action;
        const row = state.records.find((r) => r.id === button.dataset.id);
        if (state.busy) {
          toast("저장이 끝날 때까지 기다려 주세요.");
          return;
        }
        if (action === "draft-open") {
          if (!button.dataset.id || row?.kind === "post" && canEdit(row)) openEditor("post", row);
          return;
        }
        if (action === "draft-restore") {
          await restorePostDraft();
          return;
        }
        if (action === "draft-discard") {
          await discardPostDraft();
          return;
        }
        if (await profiles.action(action, button) || await bucket.action(action, button)) return;
        if (action?.startsWith("media-") && editorDraft) {
          const index = Number(button.dataset.index);
          if (action === "media-remove") editorDraft.remove(index);
          else editorDraft.move(index, action === "media-earlier" ? -1 : 1);
          updateMediaDraft();
          return;
        }
        if (action === "video-load") {
          await loadDriveVideo(button.parentElement.querySelector("video"), true);
          return;
        }
        if (action === "choose-home-photo") chooseHomePhoto();
        if (action === "show-home-post-photos") {
          homePhotoShowPosts = !homePhotoShowPosts;
          renderHomePhotoPicker();
        }
        if (action === "toggle-home-photo") {
          const item = homePhotoDraft.find((item2) => item2.key === button.dataset.key);
          if (!item) throw new Error("선택한 사진을 찾을 수 없어요.");
          item.selected = !item.selected;
          if (item.selected) item.added = true;
          renderHomePhotoPicker(item.key);
        }
        if (action === "clear-home-photos") {
          homePhotoDraft.forEach((item) => {
            item.selected = false;
          });
          renderHomePhotoPicker();
        }
        if (action === "home-photo-prev" || action === "home-photo-next") {
          const count = selectedHomePhotos().length;
          if (count) {
            homePhotoIndex = ((homePhotoIndex || 0) + (action === "home-photo-next" ? 1 : -1) + count) % count;
            render();
          }
        }
        if (action === "set-home-photo") await saveHomePhotos(button);
        if (action === "new") openEditor(button.dataset.kind);
        if (action === "close" && $("#record-form")?.dataset.kind === "comment" && state.activePost) {
          openPost(state.records.find((r) => r.id === state.activePost), state.postScroll);
          return;
        }
        if (action === "close") {
          if (state.busy) throw new Error("저장이 끝날 때까지 기다려 주세요.");
          closeDialog();
        }
        if (action === "reload") location.reload();
        if (action === "edit") {
          if (!row || !canEdit(row)) throw new Error("작성자만 수정할 수 있어요.");
          openEditor(row.kind, row);
        }
        if (action === "day") {
          const repeat = state.day === button.dataset.date;
          state.day = button.dataset.date;
          render();
          if (repeat) {
            const list = events().filter((r) => eventOnDate(r, state.day) && !r.data.automatic);
            if (list.length === 1) openEditor("event", list[0]);
            else if (list.length > 1) dialog("수정할 일정 선택", eventRows(list));
            else openEditor("event");
          }
        }
        if (action === "month" || action === "today") {
          const target = action === "today" ? /* @__PURE__ */ new Date() : new Date(state.year, state.month + Number(button.dataset.offset), 1);
          state.year = target.getFullYear();
          state.month = target.getMonth();
          state.day = action === "today" ? today : dateKey(target);
          if (state.mode === "live") {
            render();
            await syncCalendar();
          }
          render();
        }
        if (action === "edit-event") {
          const record = events().find((r) => r.id === button.dataset.id);
          if (record && !record.data.automatic) openEditor("event", record);
        }
        if (action === "delete-event") {
          const record = events().find((r) => r.id === button.dataset.id);
          if (!record) return;
          if (!confirm("이 약속을 삭제할까요? Google 연동 중이면 공유 캘린더에서도 삭제돼요.")) return;
          if (state.mode === "demo") await repository.remove("demo", state.user, record);
          else await google.deleteEvent(record.id);
          closeDialog();
          await load(true);
          render();
          toast("약속을 삭제했어요.");
        }
        if (action === "notice-list") openNotices();
        if (action === "notice-read-all") {
          const user = state.user, mode = state.mode, ids = notices().filter((r) => !noticeRead(r.id)).map((r) => r.id);
          if (!ids.length) return;
          button.disabled = true;
          try {
            if (mode === "live") await repository.markNotificationsRead(user, ids);
            if (state.user !== user || state.mode !== mode) return;
            const reads = [...state.notificationReads, ...ids.filter((id) => !noticeRead(id)).map((record_id) => ({ user_id: user, record_id }))];
            if (mode === "demo") localStorage.setItem("geonjukong-demo-notification-reads", JSON.stringify(reads));
            state.notificationReads = reads;
            render();
            openNotices();
          } finally {
            button.disabled = false;
          }
        }
        if (action === "notice-open" && notices().some((notice) => notice.id === row?.id)) {
          const target = row.kind === "comment" ? state.records.find((r) => r.id === row.data.postId) : row;
          if (!target) throw new Error("해당 게시물을 찾을 수 없어요.");
          const isEvent = row.kind === "event" || row.kind === "event_notice";
          if (isEvent && !/^\d{4}-\d{2}-\d{2}$/.test(row.data.date || "")) throw new Error("일정 날짜를 확인할 수 없어요.");
          if (state.mode === "live") await repository.markNotificationRead(state.user, row.id);
          state.notificationReads.push({ user_id: state.user, record_id: row.id });
          if (state.mode === "demo") localStorage.setItem("geonjukong-demo-notification-reads", JSON.stringify(state.notificationReads));
          if (isEvent) {
            let date = row.data.date;
            if (state.mode === "live" && row.data.eventId) {
              try {
                date = (await google.event(row.data.eventId))?.data.date || date;
              } catch {
                toast("현재 일정을 확인하지 못해 처음 등록된 날짜로 이동해요.");
              }
            }
            closeDialog();
            state.day = date;
            state.year = Number(date.slice(0, 4));
            state.month = Number(date.slice(5, 7)) - 1;
            await navigate("calendar");
            if (state.mode === "live") {
              await syncCalendar();
              render();
            }
          } else {
            render();
            state.replyTo = "";
            openPost(target, 0, false);
            if (row.kind === "comment") document.getElementById?.(`comment-${row.id}`)?.scrollIntoView?.({ block: "nearest" });
          }
        }
        if (action === "reply" && row) {
          state.replyTo = row.id;
          openPost(state.records.find((r) => r.id === row.data.postId), $("#editor").scrollTop);
          replyFocusCleanup = focusReplyInput($("#editor"), $("#comment-text"));
        }
        if (action === "cancel-reply") {
          state.replyTo = "";
          openPost(state.records.find((r) => r.id === state.activePost), $("#editor").scrollTop);
        }
        if (action === "attachment-prev" || action === "attachment-next") {
          const gallery = button.closest(".attachment-gallery, .memory-gallery");
          const track = gallery.querySelector(".attachments, .memory-slides");
          const index = Math.round(track.scrollLeft / track.clientWidth);
          track.scrollTo({ left: (index + (action === "attachment-next" ? 1 : -1)) * track.clientWidth, behavior: "smooth" });
        }
        if (action === "open-post" || action === "open-comments") {
          if (row) {
            state.replyTo = "";
            openPost(row, 0, action === "open-comments");
          }
        }
        if (action === "delete" || action === "delete-comment") {
          if (!row || !confirm(row.kind === "post" ? `${state.view === "memories" ? "일기와" : "게시글과"} 댓글을 삭제할까요? 사진·영상 원본은 유지돼요.` : "이 기록을 삭제할까요?")) return;
          const scroll = $("#editor").scrollTop || 0;
          await repository.remove(state.mode, state.user, row);
          await load();
          if (action !== "delete-comment") closeDialog();
          render();
          if (action === "delete-comment") {
            const post = state.records.find((r) => r.id === button.dataset.post);
            if (post) openPost(post, scroll);
          }
          toast("기록을 삭제했어요.");
        }
        if (action === "open-file") {
          if (button.dataset.source === "drive") await google.openFile(button.dataset.id);
          else {
            const stored = await local.file(button.dataset.id);
            if (!stored) throw new Error("이 기기에서 원본을 찾을 수 없어요.");
            if (native.active) {
              await native.saveFile(stored.blob, stored.blob.name || "original");
              return;
            }
            const link = document.createElement("a");
            link.href = URL.createObjectURL(stored.blob);
            link.download = stored.blob.name || "original";
            link.click();
            setTimeout(() => URL.revokeObjectURL(link.href), 1e4);
          }
        }
        if (action === "photo-access") {
          requireLive();
          const postId = state.activePost, user = state.user;
          const post = state.records.find((record) => record.id === postId);
          if (!post?.data.files?.some((file) => file.source === "drive" && file.id === button.dataset.id && file.type.startsWith("image/"))) throw new Error("해당 사진을 찾을 수 없어요.");
          const editor = $("#editor"), scroll = editor.scrollTop || 0;
          button.disabled = true;
          editor.close();
          try {
            await google.pickPhoto(button.dataset.id);
            if (state.mode !== "live" || state.user !== user || state.activePost !== postId) return;
            openPost(state.records.find((record) => record.id === postId), scroll);
            toast("사진을 다시 불러오고 있어요.");
          } finally {
            if (state.mode === "live" && state.user === user && state.activePost === postId && !editor.open) {
              lockPage();
              editor.showModal();
            }
            button.disabled = false;
          }
        }
        if (action === "login") {
          button.disabled = true;
          try {
            await auth.login();
          } finally {
            button.disabled = false;
          }
        }
        if (action === "logout") {
          let pushCleanupFailed = false;
          if (state.mode === "live" && "serviceWorker" in navigator) {
            try {
              const registration = await navigator.serviceWorker.getRegistration();
              const subscription = await registration?.pushManager?.getSubscription();
              if (subscription) {
                try {
                  await repository.unsubscribe(subscription.endpoint);
                } catch {
                  pushCleanupFailed = true;
                }
                try {
                  if (!await subscription.unsubscribe()) pushCleanupFailed = true;
                } catch {
                  pushCleanupFailed = true;
                }
              }
            } catch {
              pushCleanupFailed = true;
            }
          }
          calendarSyncSequence++;
          upcomingSyncSequence++;
          const remoteLogout = auth.logout();
          badgeUpdate = badgeUpdate.then(() => native.setBadge(false)).catch(() => {
          });
          google.disconnect();
          clearDriveImages();
          state.records = [];
          state.events = [];
          state.upcomingEvents = [];
          state.upcomingError = "";
          upcomingDate = "";
          state.calendarError = "";
          state.noticeError = "";
          state.members = [];
          state.bucketItems = [];
          state.profiles = [];
          if ($("#editor").open) closeDialog();
          state.mode = "demo";
          state.user = "demo-me";
          await seed();
          await load();
          render();
          const result = await remoteLogout;
          if (pushCleanupFailed || result?.remote === false) toast("이 기기에서는 로그아웃했지만 서버 로그아웃 또는 알림 해제를 완료하지 못했어요. 연결을 확인해 주세요.");
        }
        if (action === "google-connect") {
          requireLive();
          await auth.login();
        }
        if (action === "sync-birthday") {
          requireLive();
          button.disabled = true;
          try {
            const user = state.user, birthday = await google.birthday();
            if (state.mode !== "live" || state.user !== user) return;
            state.couple = await repository.updateCoupleDate("birthday", birthday);
            render();
            toast("내 Google 생일을 가져왔어요.");
          } finally {
            button.disabled = false;
          }
        }
        if (action === "pick-folder") {
          requireLive();
          const folder = await google.pickFolder();
          if (folder.id !== window.APP_CONFIG.driveFolderId) throw new Error(`선택한 폴더 ID: ${folder.id}. 공용 폴더가 맞다면 config.js의 driveFolderId를 이 값으로 설정해 주세요.`);
          await google.checkFolder();
          toast("공유 Drive 폴더 접근을 확인했어요.");
        }
        if (action === "calendar-retry") {
          button.disabled = true;
          try {
            await Promise.all([syncCalendar(), syncUpcoming()]);
            render();
            if (!state.calendarError && !state.upcomingError) toast("캘린더를 동기화했어요.");
          } finally {
            button.disabled = false;
          }
        }
        if (action === "refresh") {
          button.disabled = true;
          try {
            await load(true);
            render();
            toast(state.calendarError || state.upcomingError ? "공유 기록을 불러왔지만 캘린더 동기화에 실패했어요." : "최신 기록을 불러왔어요.");
          } finally {
            button.disabled = false;
          }
        }
        if (action === "export") {
          const payload = { app: "GeonJuKong", version: 1, exportedAt: (/* @__PURE__ */ new Date()).toISOString(), mode: state.mode, records: state.records, bucketItems: state.bucketItems, profiles: state.profiles, calendar: events(), notice: "파일 목록만 포함됩니다. 원본 파일은 별도로 백업해 주세요." };
          if (native.active) {
            await native.saveFile(new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" }), `GeonJuKong-${today}.json`);
            return;
          }
          const url = URL.createObjectURL(new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" }));
          const link = document.createElement("a");
          link.href = url;
          link.download = `GeonJuKong-기록-${today}.json`;
          link.click();
          setTimeout(() => URL.revokeObjectURL(url), 1e4);
        }
        if (action === "reset") {
          if (!confirm("이 브라우저의 체험 기록과 원본 파일을 모두 지우고 예시 기록으로 초기화할까요? 실제 공유 데이터에는 영향이 없어요.")) return;
          await local.clear();
          localStorage.removeItem("geonjukong-seeded");
          localStorage.removeItem("geonjukong-demo-profiles");
          for (const url of urls.values()) URL.revokeObjectURL(url);
          urls.clear();
          await seed();
          await load();
          render();
          toast("체험 데이터를 초기화했어요.");
        }
        if (action === "install") {
          if (native.active) {
            toast("설치형 GeonJuKong 앱을 사용하고 있어요.");
            return;
          }
          if (installPrompt) {
            await installPrompt.prompt();
            installPrompt = null;
          } else toast("아이폰: Safari 공유 → 홈 화면에 추가 / 갤럭시: Chrome 메뉴 → 앱 설치");
        }
      } catch (error) {
        report(error);
      }
    });
    document.addEventListener("scroll", (event) => {
      const track = event.target;
      if (!(track.classList?.contains("attachments") || track.classList?.contains("memory-slides")) || !track.clientWidth) return;
      const gallery = track.closest(".attachment-gallery, .memory-gallery");
      const count = track.children.length;
      const index = Math.max(0, Math.min(count - 1, Math.round(track.scrollLeft / track.clientWidth)));
      const position = gallery.querySelector(".attachment-position");
      if (!position) return;
      position.textContent = `${index + 1} / ${count}`;
      gallery.querySelector('[data-action="attachment-prev"]').disabled = index === 0;
      gallery.querySelector('[data-action="attachment-next"]').disabled = index === count - 1;
    }, true);
    $("#editor").addEventListener("cancel", (event) => {
      if (state.busy) event.preventDefault();
    });
    document.addEventListener("change", (event) => {
      if (event.target.id === "home-photo-files" && !state.busy) {
        try {
          addHomePhotos(event.target.files);
        } catch (error) {
          report(error);
        } finally {
          event.target.value = "";
        }
        return;
      }
      if (event.target.id === "demo-person" && state.mode === "demo") {
        if (state.busy) {
          event.target.value = state.user;
          return;
        }
        if ($("#editor").open) closeDialog();
        state.user = event.target.value;
        localStorage.setItem("geonjukong-demo-person", state.user);
        render();
      }
      if (event.target.id === "profile-photo") {
        profiles.change(event);
        return;
      }
      if (event.target.name === "files" && editorDraft && !state.busy) {
        try {
          editorDraft.addFiles(event.target.files);
          event.target.value = "";
          updateMediaDraft();
        } catch (error) {
          report(error);
        }
      }
    });
    document.addEventListener("input", (event) => {
      if (postDraftSession && event.target.form === postDraftSession.form && ["date", "title", "text"].includes(event.target.name)) capturePostDraft();
    });
    window.addEventListener("pagehide", () => {
      if (postDraftSession?.dirty) capturePostDraft();
    });
    window.addEventListener("beforeunload", () => {
      if (postDraftSession?.dirty) capturePostDraft();
    });
    document.addEventListener("visibilitychange", () => {
      if (document.hidden && postDraftSession?.dirty) capturePostDraft();
    });
    document.addEventListener("submit", async (event) => {
      const form = event.target;
      if (!["record-form", "comment-form", "search-form", "couple-form", "couple-setup-form", "bucket-form", "profile-form"].includes(form.id)) return;
      event.preventDefault();
      if (state.busy) return;
      if (form.id === "search-form") {
        state.filter = new FormData(form).get("search").trim();
        render();
        return;
      }
      const submit = form.querySelector('[type="submit"]');
      const original = submit.textContent;
      state.busy = true;
      submit.disabled = true;
      const errorBox = form.querySelector(".form-error");
      if (errorBox) errorBox.textContent = "";
      try {
        if (form.id === "profile-form") {
          await profiles.submit(form);
          return;
        }
        if (form.id === "bucket-form") {
          await bucket.submit(form);
          return;
        }
        if (form.id === "couple-form" || form.id === "couple-setup-form") {
          const values = Object.fromEntries(new FormData(form));
          const startDate = coupleDateValue(values, "startDate", "연애 시작일");
          if (form.id === "couple-setup-form") {
            const data = { startDate, birthdays: [] };
            const created = await repository.createCoupleSettings(data);
            if (!created.length) {
              state.couple = await repository.coupleSettings();
              render();
              throw new Error("이미 공유 설정이 있어요. 설정 화면에서 확인해 주세요.");
            }
            state.couple = data;
            closeDialog();
          } else if (state.mode === "demo") {
            state.couple = { ...state.couple, startDate };
            localStorage.setItem("geonjukong-demo-couple", JSON.stringify(state.couple));
          } else {
            const created = await repository.createCoupleSettings({ startDate, birthdays: [] });
            state.couple = created.length ? created[0].data : await repository.updateCoupleDate("startDate", startDate);
          }
          render();
          toast(form.id === "couple-setup-form" ? "시작일을 저장했어요. 설정에서 각자 Google 생일을 가져와 주세요." : "연애 시작일을 저장했어요.");
        }
        if (form.id === "record-form") {
          const draftSession = postDraftSession?.form === form ? postDraftSession : null;
          const mode = state.mode, user = state.user;
          const current = () => state.mode === mode && state.user === user && (mode !== "live" || auth.user?.id === user);
          const checkPostAccount = () => {
            if (form.dataset.kind === "post" && !current()) throw new Error("계정이 바뀌어 저장을 중단했어요. 이전 계정에서 기기 초안을 이어 써 주세요.");
          };
          if (postDraftSession?.form === form) {
            if (postDraftSession.waiting || postDraftSession.scope.user !== state.user || postDraftSession.scope.mode !== state.mode) throw new Error("초안을 이어 쓰거나 삭제한 뒤 저장해 주세요.");
            capturePostDraft();
            form.inert = true;
          }
          const kind = form.dataset.kind;
          const data = Object.fromEntries(new FormData(form));
          delete data.files;
          validateRecord(kind, data);
          let noticeQueueError = "";
          const old = state.records.find((r) => r.id === form.dataset.id);
          if (old) Object.assign(data, { ...old.data, ...data });
          if (kind === "post") {
            data.files = [];
            const entries = editorDraft ? editorDraft.entries() : [...(old?.data.files || []).map((metadata) => ({ metadata })), ...[...form.elements.files.files].map((file) => ({ file, key: `${file.name}:${file.size}:${file.lastModified}` }))];
            const files = entries.filter((entry) => entry.file).map((entry) => entry.file);
            files.forEach(safeFileType);
            form.uploadedFiles ||= /* @__PURE__ */ new Map();
            for (let i = 0; i < entries.length; i++) {
              checkPostAccount();
              const entry = entries[i];
              if (entry.metadata) {
                data.files.push(entry.metadata);
                continue;
              }
              const file = entry.file;
              const key = entry.key;
              let metadata = form.uploadedFiles.get(key);
              if (!metadata) {
                if (state.mode === "demo") {
                  const id = crypto.randomUUID();
                  await local.putFile(id, file);
                  metadata = { id, name: file.name, type: file.type, size: file.size, source: "local" };
                } else metadata = await google.upload(file, (p) => {
                  submit.textContent = `${i + 1}/${entries.length} · ${p}%`;
                });
                const thumbnail = await createThumbnail(file);
                checkPostAccount();
                if (thumbnail) {
                  if (state.mode === "demo") {
                    const id = crypto.randomUUID();
                    await local.putFile(id, thumbnail);
                    metadata.thumbnail = { id, name: thumbnail.name, type: thumbnail.type, size: thumbnail.size, source: "local" };
                  } else {
                    try {
                      metadata.thumbnail = await google.upload(thumbnail, () => {
                      });
                    } catch {
                      toast("썸네일 업로드에 실패하여 원본 미리보기를 사용해요.");
                    }
                  }
                }
                form.uploadedFiles.set(key, metadata);
                if (postDraftSession?.form === form) capturePostDraft();
              }
              data.files.push(metadata);
            }
          }
          let saved;
          checkPostAccount();
          if (kind === "event" && state.mode === "live") {
            const event2 = await google.saveEvent(data, form.dataset.id || void 0);
            if (!form.dataset.id) {
              try {
                if (!event2?.id) throw new Error("Missing event ID");
                queueCalendarNotice(state.user, event2, data);
              } catch {
                noticeQueueError = "일정은 저장됐지만 알림을 준비하지 못했어요. 저장 공간을 확인해 주세요.";
              }
            }
          } else saved = await repository.save(mode, user, kind, data, form.dataset.id || void 0, form.dataset.version || void 0);
          if (saved && kind === "post" && draftSession) {
            if (postDraftSession === draftSession) postDraftSession = null;
            try {
              await draftSession.store.discard(true);
            } catch (error) {
              noticeQueueError = error.message;
            }
          }
          if (kind === "post" && !current()) return;
          if (saved) state.records = state.records.filter((r) => r.id !== saved.id).concat(saved);
          if (kind !== "comment") closeDialog();
          let refreshFailed = false;
          try {
            await load(kind === "event");
          } catch {
            refreshFailed = true;
            state.error = "기록은 저장됐지만 최신 기록을 불러오지 못했어요. 다시 동기화해 주세요.";
          }
          if (kind === "post" && !current()) return;
          if (!refreshFailed && kind === "event" && state.mode === "live" && (state.calendarError || state.upcomingError)) {
            refreshFailed = true;
            state.error = "일정은 저장됐지만 캘린더를 갱신하지 못했어요. 다시 동기화해 주세요.";
          }
          if (noticeQueueError) state.noticeError = noticeQueueError;
          render();
          if (kind === "comment") openPost(state.records.find((r) => r.id === data.postId), state.postScroll);
          toast(refreshFailed ? "기록은 저장됐어요. 최신 기록은 다시 동기화해 주세요." : "우리의 기록을 저장했어요.");
        }
        if (form.id === "comment-form") {
          const scroll = $("#editor").scrollTop || 0;
          const saved = await repository.save(state.mode, state.user, "comment", { text: form.elements.text.value.trim(), postId: form.dataset.post, ...form.dataset.reply ? { replyTo: form.dataset.reply } : {} });
          form.elements.text.value = "";
          state.replyTo = "";
          state.records = state.records.filter((r) => r.id !== saved.id).concat(saved);
          try {
            await load();
          } catch {
            state.error = "댓글은 저장됐지만 최신 기록을 불러오지 못했어요. 다시 동기화해 주세요.";
          }
          render();
          openPost(state.records.find((r) => r.id === form.dataset.post), scroll);
          toast("댓글을 남겼어요.");
        }
      } catch (error) {
        if (errorBox) errorBox.textContent = error.message;
        else report(error);
      } finally {
        state.busy = false;
        form.inert = false;
        if (submit.isConnected) {
          submit.disabled = false;
          submit.textContent = original;
        }
      }
    });
    document.addEventListener("keydown", (event) => {
      if (["Enter", " "].includes(event.key) && event.target.matches('[data-action="profile-open"]')) {
        event.preventDefault();
        event.target.click();
      }
    });
    polling = false;
    pendingRender = false;
    pendingCommentPost = "";
    nextCalendarRefresh = Date.now() + 6e4;
    setInterval(async () => {
      if (startupPending) return;
      if (!document.hidden && dateKey() !== today && !$("#editor").open && !document.activeElement.matches("input,textarea,select")) render();
      if (state.mode !== "live" || document.hidden || state.busy || polling) return;
      polling = true;
      const user = state.user, sessionUser = auth.user;
      const current = () => state.mode === "live" && state.user === user && auth.user === sessionUser && !state.busy;
      try {
        const before = JSON.stringify([state.records, state.notificationReads, state.couple, state.bucketItems, state.profiles, state.featureErrors, state.events, state.upcomingEvents, state.upcomingError, state.calendarError, state.error, state.noticeError]);
        const postId = state.activePost;
        const oldComments = JSON.stringify(records("comment").filter((c) => c.data.postId === postId));
        await updatePendingNotices(user);
        if (!current()) return;
        let [rows, noticeReads, couple] = await Promise.all([repository.list(), repository.notificationReads(), repository.coupleSettings()]);
        if (!current()) return;
        await loadFeatures();
        if (!current()) return;
        state.records = rows;
        state.notificationReads = noticeReads.map((r) => ({ ...r, user_id: user }));
        state.couple = couple;
        syncNotificationBadge();
        state.error = "";
        state.lastSync = (/* @__PURE__ */ new Date()).toISOString();
        if (before !== JSON.stringify([state.records, state.notificationReads, state.couple, state.bucketItems, state.profiles, state.featureErrors, state.events, state.upcomingEvents, state.upcomingError, state.calendarError, state.error, state.noticeError])) pendingRender = true;
        if (state.activePost === postId && oldComments !== JSON.stringify(records("comment").filter((c) => c.data.postId === postId))) pendingCommentPost = postId;
        if (state.mode === "live" && (Date.now() >= nextCalendarRefresh || upcomingDate !== dateKey())) {
          nextCalendarRefresh = Date.now() + 6e4;
          await Promise.all([syncCalendar(current), syncUpcoming(current)]);
        }
        if (!current()) {
          nextCalendarRefresh = 0;
          return;
        }
        if (before !== JSON.stringify([state.records, state.notificationReads, state.couple, state.bucketItems, state.profiles, state.featureErrors, state.events, state.upcomingEvents, state.upcomingError, state.calendarError, state.error, state.noticeError])) pendingRender = true;
        const editor = $("#editor");
        if (editor.open && state.activePost && state.activePost === postId && $("#comment-form")) {
          if (oldComments !== JSON.stringify(records("comment").filter((c) => c.data.postId === postId))) pendingCommentPost = postId;
          const comments = editor.querySelector(".comments");
          const row = state.records.find((r) => r.id === postId);
          if (pendingCommentPost === postId && row && comments && !state.replyTo && !comments.contains(document.activeElement)) {
            const scroll = editor.scrollTop;
            comments.innerHTML = commentList(row);
            const count = comments.previousElementSibling?.querySelector("span");
            if (count) count.textContent = String(records("comment").filter((c) => c.data.postId === postId).length);
            editor.scrollTop = scroll;
            pendingCommentPost = "";
          }
          if (!row) {
            const error = $("#comment-form").querySelector(".form-error");
            if (error) error.textContent = "상대방이 이 게시물을 삭제했어요. 작성 중인 내용은 복사할 수 있어요.";
          }
        } else pendingCommentPost = "";
        if (pendingRender && !editor.open && !state.busy) {
          const focused = document.activeElement;
          if (!focused.matches("input,textarea,select")) {
            render();
            pendingRender = false;
          }
        }
      } catch (error) {
        if (current()) {
          state.error = "공유 기록을 갱신하지 못했어요. 네트워크와 로그인을 확인해 주세요.";
          pendingRender = true;
          if (!$("#editor").open && !document.activeElement.matches("input,textarea,select")) {
            render();
            pendingRender = false;
          }
        }
      } finally {
        polling = false;
      }
    }, 5e3);
    window.addEventListener("popstate", () => {
      if (!native.active && history.pushState) history.pushState({ view: state.view }, "", `#${state.view}`);
      handleBack().catch(report);
    });
    window.addEventListener("hashchange", () => {
      const view = location.hash.slice(1);
      if (views[view] && view !== state.view) navigate(view, true).catch(report);
    });
    processingLink = false;
    boot().catch(report);
  }
});

// src/native-entry.js
init_dist();

// node_modules/@capacitor/app/dist/esm/index.js
init_dist();
var App = registerPlugin("App", {
  web: () => Promise.resolve().then(() => (init_web(), web_exports)).then((m) => new m.AppWeb())
});

// node_modules/@capacitor/browser/dist/esm/index.js
init_dist();
var Browser2 = registerPlugin("Browser", {
  web: () => Promise.resolve().then(() => (init_web2(), web_exports2)).then((m) => new m.BrowserWeb())
});

// node_modules/@capacitor/filesystem/dist/esm/index.js
init_dist();

// node_modules/@capacitor/synapse/dist/synapse.mjs
function s(t) {
  t.CapacitorUtils.Synapse = new Proxy(
    {},
    {
      get(e, n) {
        return new Proxy({}, {
          get(w, o) {
            return (c, p, r) => {
              const i = t.Capacitor.Plugins[n];
              if (i === void 0) {
                r(new Error(`Capacitor plugin ${n} not found`));
                return;
              }
              if (typeof i[o] != "function") {
                r(new Error(`Method ${o} not found in Capacitor plugin ${n}`));
                return;
              }
              (async () => {
                try {
                  const a = await i[o](c);
                  p(a);
                } catch (a) {
                  r(a);
                }
              })();
            };
          }
        });
      }
    }
  );
}
function u(t) {
  t.CapacitorUtils.Synapse = new Proxy(
    {},
    {
      get(e, n) {
        return t.cordova.plugins[n];
      }
    }
  );
}
function f(t = false) {
  typeof window > "u" || (window.CapacitorUtils = window.CapacitorUtils || {}, window.Capacitor !== void 0 && !t ? s(window) : window.cordova !== void 0 && u(window));
}

// node_modules/@capacitor/filesystem/dist/esm/index.js
init_definitions();
var Filesystem = registerPlugin("Filesystem", {
  web: () => Promise.resolve().then(() => (init_web3(), web_exports3)).then((m) => new m.FilesystemWeb())
});
f();

// node_modules/@capacitor/share/dist/esm/index.js
init_dist();
var Share = registerPlugin("Share", {
  web: () => Promise.resolve().then(() => (init_web4(), web_exports4)).then((m) => new m.ShareWeb())
});

// src/native-media.js
async function pickOrderedMedia(picker, convertFileSrc) {
  const selection = await picker.pick();
  if (!selection.files.length) return [];
  try {
    const files = [];
    for (const item of selection.files) {
      const response = await fetch(convertFileSrc(item.path));
      if (!response.ok) throw new Error("선택한 사진·동영상을 읽지 못했어요. 다시 선택해 주세요.");
      files.push(new File([await response.blob()], item.name, { type: item.type, lastModified: item.lastModified }));
    }
    return files;
  } finally {
    await picker.release({ selectionId: selection.selectionId });
  }
}

// src/native-entry.js
var mediaPicker = registerPlugin("OrderedMediaPicker");
var appBadge = registerPlugin("AppBadge");
window.GEONJUKONG_NATIVE = {
  active: Capacitor.isNativePlatform(),
  setBadge: (hasUnread) => appBadge.set({ count: hasUnread ? 1 : 0 }),
  pickMedia: Capacitor.getPlatform() === "ios" ? () => pickOrderedMedia(mediaPicker, (path) => Capacitor.convertFileSrc(path)) : void 0,
  onBack: (handler) => Capacitor.getPlatform() === "android" ? App.addListener("backButton", handler) : void 0,
  exit: () => App.exitApp(),
  open: (url) => Browser2.open({ url }),
  closeBrowser: () => Browser2.close(),
  async saveFile(blob, name) {
    const base64 = await new Promise((resolve2, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve2(String(reader.result).split(",")[1]);
      reader.onerror = () => reject(new Error("파일을 읽지 못했습니다."));
      reader.readAsDataURL(blob);
    });
    const filename = name.replace(/[\\/\u0000-\u001f]/g, "_").slice(-160) || "original";
    const path = `exports/${Date.now()}-${filename}`;
    const saved = await Filesystem.writeFile({ path, data: base64, directory: Directory.Cache, recursive: true });
    await Share.share({ title: filename, url: saved.uri, dialogTitle: "원본 파일 저장 또는 공유" });
  },
  async listen(handler) {
    await App.addListener("appUrlOpen", ({ url }) => handler(url));
    const launch = await App.getLaunchUrl();
    return launch?.url;
  }
};
await Promise.resolve().then(() => (init_app(), app_exports));
/*! Bundled license information:

@capacitor/core/dist/index.js:
  (*! Capacitor: https://capacitorjs.com/ - MIT License *)
*/
